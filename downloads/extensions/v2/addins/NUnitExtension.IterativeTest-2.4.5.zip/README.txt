= IterativeTest Extension for NUnit

Many thanks due to Andreas Schlapsi for the RowTest project that served as an example 
and template for this project. Super extension Andreas! 
Also thanks to Charlie Poole for his help in reviewing and hosting this extension.

== Installing

Install the IterativeTest Extension by copying the files NUnitExtension.IterativeTest and
NUnitExtension.IterativeTest.AddIn to the NUnit Addin directory (e.g.
C:\Program Files\NUnit 2.4.2\bin\addins). When you start NUnit you, click
Tools > Addins... You should see the line "Iterative Test Extension" under Addin.


== Usage

In order to use the extension reference the assembly NUnitExtension.IterativeTest in
your unit test project. See the sample project for further information.


== License

IterativeTest Extension for NUnit is released under the MIT license.


== Homepage

http://www.nunit.org/index.php?p=addins
