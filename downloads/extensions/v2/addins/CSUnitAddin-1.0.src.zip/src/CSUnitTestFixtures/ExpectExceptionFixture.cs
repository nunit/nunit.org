// *********************************************************
// Copyright 2008, Charlie Poole
//
// Licensed under the Academic Free License version 3.0
// *********************************************************

using System;
using System.Runtime.Serialization;
using csUnit;

namespace NUnit.Core.Extensions.CSUnit.Tests
{
	[TestFixture]
	public class ExpectedExceptionFixture
	{
		[Test]
		[ExpectedException(typeof(ArgumentException))]
		public void ThrowsCorrectException()
		{
			throw new ArgumentException("argument exception");
		}

		[Test]
		[ExpectedException(typeof(ArgumentException))]
		public void ThrowsBaseException()
		{
			throw new Exception();
		}

		[Test]
		[ExpectedException(typeof(Exception))]
		public void ThrowsDerivedException()
		{
			throw new ArgumentException();
		}

		[Test]
		[ExpectedException(typeof(ArgumentException))]
		public void ThrowsUnrelatedException()
		{
			throw new ArgumentOutOfRangeException();
		}

		[Test, ExpectedException( typeof( System.ArgumentException ) )]
		public void DoesNotThrowException()
		{
		}

		[Test]
		public void ThrowsUnexpectedException()
		{
			throw new Exception();
		}

		[Test]
		[ExpectedException(typeof(Exception))]
		public void AssertsBeforeThrowingException()
		{
			Assert.Fail( "private message" );
		}

		[Test, ExpectedException(typeof(MyAppException))] 
		public void ThrowsCustomException() 
		{ 
			throw new MyAppException("my app");
		}

		[Test, ExpectedException(typeof(ApplicationException), false)]
		public void ThrowsOptionalException()
		{
			throw new ApplicationException();
		}

		[Test, ExpectedException(typeof(ApplicationException), false)]
		public void DoesNotThrowOptionalException()
		{
		}

		[Test, ExpectedException(typeof(ApplicationException), true)]
		public void ThrowsRequiredException()
		{
			throw new ApplicationException();
		}

		[Test, ExpectedException(typeof(ApplicationException), true)]
		public void DoesNotThrowRequiredException()
		{
		}
	}

	[TestFixture]
	public class SetUpExceptionTests  
	{
		[SetUp]
		public void Init()
		{
			throw new ArgumentException("SetUp Exception");
		}

		[Test]
		[ExpectedException(typeof(ArgumentException))]
		public void Test() 
		{
		}
	}

	[TestFixture]
	public class TearDownExceptionTests
	{
		[TearDown]
		public void CleanUp()
		{
			throw new ArgumentException("TearDown Exception");
		}

		[Test]
		[ExpectedException(typeof(ArgumentException))]
		public void Test() 
		{}
	}

	class MyAppException : System.Exception
	{
		public MyAppException (string message) : base(message) 
		{}

		public MyAppException(string message, Exception inner) :
			base(message, inner) 
		{}

		protected MyAppException(SerializationInfo info, 
			StreamingContext context) : base(info,context)
		{}
	}
}
