// *********************************************************
// Copyright 2008, Charlie Poole
//
// Licensed under the Academic Free License version 3.0
// *********************************************************

using System;
using System.Reflection;
using System.Runtime.Serialization;
using NUnit.Framework;

namespace NUnit.Core.Extensions.CSUnit.Tests
{
	/// <summary>
	/// 
	/// </summary>
	[TestFixture]
	public class ExpectedExceptionTests 
	{
		private static CSUnitTestCaseBuilder testBuilder = new CSUnitTestCaseBuilder();

		private CSUnitTestMethod MakeTestCase( Type type, string methodName )
		{
			return (CSUnitTestMethod)testBuilder.BuildFrom( Reflect.GetNamedMethod( 
				type,
				methodName,
				BindingFlags.Public | BindingFlags.Instance ) );
		}

		private TestResult RunTestCase( Type type, string methodName )
		{
			return MakeTestCase( type, methodName ).Run( NullListener.NULL );
		}

		private TestResult RunTestCase( string method )
		{
			return RunTestCase( typeof( ExpectedExceptionFixture ), method );
		}

		[Test]
		public void TestSucceedsWhenCorrectExceptionIsThrown()
		{
			Assert.That( RunTestCase( "ThrowsCorrectException" ).IsSuccess );
		}

		[Test]
		public void TestFailsWhenBaseExceptionIsThrown()
		{
			TestResult result = RunTestCase( "ThrowsBaseException" );
			Assert.That(result.IsFailure);
			StringAssert.StartsWith(
				"An unexpected exception type was thrown" + Environment.NewLine +
				"Expected: System.ArgumentException" + Environment.NewLine +
				" but was: System.Exception",
				result.Message);
		}

		[Test]
		public void TestFailsWhenDerivedExceptionIsThrown()
		{
			TestResult result = RunTestCase( "ThrowsDerivedException" );
			Assert.That(result.IsFailure);
			StringAssert.StartsWith( 
				"An unexpected exception type was thrown" + Environment.NewLine +
				"Expected: System.Exception" + Environment.NewLine +
				" but was: System.ArgumentException",
				result.Message);
		}

		[Test]
		public void TestFailsWhenUnrelatedExceptionIsThrown()
		{
			TestResult result = RunTestCase( "ThrowsUnrelatedException" );
			Assert.That(result.IsFailure);
			StringAssert.StartsWith(
				"An unexpected exception type was thrown" + Environment.NewLine +
				"Expected: System.ArgumentException" + Environment.NewLine +
				" but was: System.ArgumentOutOfRangeException", 
				result.Message);
		}

		[Test]
		public void TestFailsWhenNoExceptionIsThrown()
		{
			TestResult result = RunTestCase( "DoesNotThrowException" );
			Assert.That(result.IsFailure);
			Assert.AreEqual("System.ArgumentException was expected", result.Message);
		}

		[Test] 
		public void TestFailsWhenUnexpectedExceptionIsThrown()
		{
			Assert.That( RunTestCase( "ThrowsUnexpectedException" ).IsFailure );
		}

		[Test]
		public void TestFailsWhenExceptionIsThrownInSetUp()
		{
			Assert.That( RunTestCase( typeof( SetUpExceptionTests ), "Test" ).IsFailure );
		}

		[Test]
		public void TestFailsWhenExceptionIsThrownInTearDown()
		{
			Assert.That( RunTestCase( typeof( TearDownExceptionTests ), "Test" ).IsFailure );
		}

		[Test]
		public void TestFailsWhenAssertFailsBeforeExceptionIsThrown() 
		{ 
			TestResult result = RunTestCase( "AssertsBeforeThrowingException" );
			Assert.That( result.IsFailure );
			Assert.AreEqual( "private message", result.Message );
		} 

		[Test]
		public void TestSucceedsWhenCustomExceptionIsThrown() 
		{ 
			Assert.That( RunTestCase( "ThrowsCustomException" ).IsSuccess );
		}

		[Test]
		public void TestSucceedsWhenOptionalExceptionIsThrown()
		{
			Assert.That( RunTestCase( "ThrowsOptionalException" ).IsSuccess );
		}

		[Test]
		public void TestSucceedsWhenOptionalExceptionIsNotThrown()
		{
			Assert.That( RunTestCase( "DoesNotThrowOptionalException" ).IsSuccess );
		}

		[Test]
		public void TestSucceedsWhenRequiredExceptionIsThrown()
		{
			Assert.That( RunTestCase( "ThrowsRequiredException" ).IsSuccess );
		}

		[Test]
		public void TestFailsWhenRequiredExceptionIsNotThrown()
		{
			Assert.That( RunTestCase( "DoesNotThrowRequiredException" ).IsFailure );
		}
	}
}
