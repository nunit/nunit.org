// *********************************************************
// Copyright 2008, Charlie Poole
//
// Licensed under the Academic Free License version 3.0
// *********************************************************

using System;
using System.Reflection;

namespace NUnit.Core.Extensions.CSUnit
{
	/// <summary>
	/// Summary description for CSUnitTestMethod.
	/// </summary>
	public class CSUnitTestMethod : TestMethod
	{
		#region Fields
		public bool ExceptionRequired;
		#endregion

		#region Constructor
		public CSUnitTestMethod( MethodInfo method ) : base(method) 
		{ 
			this.setUpMethod = CSUnitFramework.GetSetUpMethod(this.FixtureType);
			this.tearDownMethod = CSUnitFramework.GetTearDownMethod(this.FixtureType);
		}
		#endregion

		#region TestMethod Overrides
		protected override bool IsAssertException(Exception ex)
		{
			return ex.GetType().FullName == CSUnitFramework.AssertException;
		}

		protected override bool IsIgnoreException(Exception ex)
		{
			return false;
		}

		protected override void ProcessNoException(TestCaseResult testResult)
		{
			if (this.ExceptionRequired)
				base.ProcessNoException (testResult);
			else
				testResult.Success();
		}

		#endregion
	}
}
