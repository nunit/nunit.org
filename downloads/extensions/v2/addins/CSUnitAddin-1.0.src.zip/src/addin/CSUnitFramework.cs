// *********************************************************
// Copyright 2008, Charlie Poole
//
// Licensed under the Academic Free License version 3.0
// *********************************************************

using System;
using System.Reflection;

namespace NUnit.Core.Extensions.CSUnit
{
	/// <summary>
	/// Summary description for CSUnitFramework.
	/// </summary>
	public class CSUnitFramework
	{
		#region Constants

		#region Attribute Names
		// NOTE: Attributes used in switch statements must be const

		// Attributes that apply to classes or methods
		public const string IgnoreAttribute = "csUnit.IgnoreAttribute";
		public const string DescriptionAttribute = "csUnit.DescriptionAttribute";

		// Attributes that apply only to Classes
		public const string TestFixtureAttribute = "csUnit.TestFixtureAttribute";

		// Attributes that apply only to Methods
		public const string TestAttribute = "csUnit.TestAttribute";
		public static readonly string SetUpAttribute = "csUnit.SetUpAttribute";
		public static readonly string TearDownAttribute = "csUnit.TearDownAttribute";
		public static readonly string FixtureSetUpAttribute = "csUnit.TestFixtureSetUpAttribute";
		public static readonly string FixtureTearDownAttribute = "csUnit.TestFixtureTearDownAttribute";
		public static readonly string ExpectedExceptionAttribute = "csUnit.ExpectedExceptionAttribute";
		#endregion

		#region Other Framework Types
		public static readonly string AssertException = "csUnit.TestFailed";
		#endregion

		#endregion

		#region Locate SetUp and TearDown Methods
		public static MethodInfo GetSetUpMethod(Type fixtureType)
		{
			MethodInfo method = Reflect.GetMethodWithAttribute(fixtureType, "csUnit.SetUpAttribute",
				BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance,
				true);

			if ( method == null )
				method = Reflect.GetNamedMethod( fixtureType, "SetUp", 
					BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance );
			
			return method;
		}

		public static MethodInfo GetTearDownMethod(Type fixtureType)
		{
			MethodInfo method = Reflect.GetMethodWithAttribute(fixtureType, "csUnit.TearDownAttribute",
				BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance,
				true);

			if ( method == null )
				method = Reflect.GetNamedMethod( fixtureType, "TearDown", 
					BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance );
			
			return method;
		}

		public static MethodInfo GetFixtureSetUpMethod(Type fixtureType)
		{
			return Reflect.GetMethodWithAttribute(fixtureType, "csUnit.FixtureSetUpAttribute",
				BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance,
				true);
		}

		public static MethodInfo GetFixtureTearDownMethod(Type fixtureType)
		{
			return Reflect.GetMethodWithAttribute(fixtureType, "csUnit.FixtureTearDownAttribute",
				BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance,
				true);
		}
		#endregion
	}
}
