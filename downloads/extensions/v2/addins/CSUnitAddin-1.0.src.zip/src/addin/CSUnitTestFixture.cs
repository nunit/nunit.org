// *********************************************************
// Copyright 2008, Charlie Poole
//
// Licensed under the Academic Free License version 3.0
// *********************************************************

using System;
using System.Reflection;

namespace NUnit.Core.Extensions.CSUnit
{
	/// <summary>
	/// A TestSuite that wraps a csUnit test fixture
	/// </summary>
	public class CSUnitTestFixture : TestFixture
	{
		#region Constructor
		public CSUnitTestFixture( Type fixtureType ) : base( fixtureType )
		{
            this.fixtureSetUp = CSUnitFramework.GetFixtureSetUpMethod(fixtureType);
            this.fixtureTearDown = CSUnitFramework.GetFixtureTearDownMethod(fixtureType);
        }
		#endregion
	}
}
