// *********************************************************
// Copyright 2008, Charlie Poole
//
// Licensed under the Academic Free License version 3.0
// *********************************************************

using System;
using System.Collections;
using System.Collections.Specialized;
using System.Reflection;
using System.Text.RegularExpressions;
using NUnit.Core.Builders;

namespace NUnit.Core.Extensions.CSUnit
{
	// NO TestCaseBuilderAttribute - only valid inside a CSUnitTestFixture
	public class CSUnitTestCaseBuilder : AbstractTestCaseBuilder
	{
        #region AbstractTestCaseBuilder Overrides
		/// <summary>
		/// Determine if the method is an csUnit test method.
		/// The method must either be marked with the test
		/// attribute or begin "test..." (case-insensitive)
		/// for this to be true.
		/// </summary>
		/// <param name="method">A MethodInfo for the method being used as a test method</param>
		/// <returns>True if the builder can create a test case from this method</returns>
		public override bool CanBuildFrom(MethodInfo method)
        {
            if (Reflect.HasAttribute(method, "csUnit.TestAttribute", true))
                    return true;

            Regex regex = new Regex("^(?i)test");
            return regex.Match(method.Name).Success && !IsSpecialMethod(method);
        }

		/// <summary>
		/// Create an CSUnitTestMethod
		/// </summary>
		/// <param name="method">A MethodInfo for the method being used as a test method</param>
		/// <returns>A new CSUnitTestMethod</returns>
		protected override TestCase MakeTestCase(MethodInfo method)
        {
            return new CSUnitTestMethod( method );
        }

		/// <summary>
		/// Set additional properties of the newly created test case based
		/// on its attributes. As implemented, the method sets the test's
		/// RunState and Category.
		/// </summary>
		/// <param name="method">A MethodInfo for the method being used as a test method</param>
		/// <param name="testCase">The test case being constructed</param>
		protected override void SetTestProperties(MethodInfo method, TestCase testCase)
		{
			ArrayList categories = new ArrayList();

			Attribute ignoreAttribute =
				Reflect.GetAttribute(method, "csUnit.IgnoreAttribute", false);
			if (ignoreAttribute != null)
			{
				string reason = (string)Reflect.GetPropertyValue(
					ignoreAttribute,
					"Reason",
					BindingFlags.Public | BindingFlags.Instance);
				
				testCase.RunState = RunState.Ignored;
				testCase.IgnoreReason = reason;
			}

			Attribute testAttribute =
				Reflect.GetAttribute(method, "csUnit.TestAttribute", true);
			if (testAttribute != null)
			{
				string category = (string)Reflect.GetPropertyValue(
					testAttribute,
					"Category",
					BindingFlags.Public | BindingFlags.Instance);

				if ( category != null )
					categories.Add( category );
			}

			Attribute expectedExceptionAttribute = Reflect.GetAttribute( method, "csUnit.ExpectedExceptionAttribute", false );
			if ( expectedExceptionAttribute != null )
			{
				CSUnitTestMethod testMethod = (CSUnitTestMethod)testCase;

				testMethod.ExpectedExceptionType = (Type)Reflect.GetPropertyValue(
					expectedExceptionAttribute,
					"ExceptionType",
					BindingFlags.Public | BindingFlags.Instance );

				testMethod.ExceptionExpected = true;
				testMethod.ExceptionRequired = (bool)Reflect.GetPropertyValue(
					expectedExceptionAttribute,
					"IsRequired",
					BindingFlags.Public | BindingFlags.Instance );

			}

			testCase.Categories = categories;
			testCase.Properties = new ListDictionary();
		}
        #endregion

        #region Virtual Methods
        protected virtual bool IsSpecialMethod(MethodInfo method)
        {
            return IsSetUpMethod(method)
                || IsTearDownMethod(method)
                || IsFixtureSetUpMethod(method)
                || IsFixtureTearDownMethod(method);
        }

        protected virtual bool IsSetUpMethod(MethodInfo method)
        {
            return Reflect.HasAttribute(method, "csUnit.SetUpAttribute", false);
        }
        protected virtual bool IsTearDownMethod(MethodInfo method)
        {
            return Reflect.HasAttribute(method, "csUnit.TearDownAttribute", false);
        }
        protected virtual bool IsFixtureSetUpMethod(MethodInfo method)
        {
            return Reflect.HasAttribute(method, "csUnit.FixtureSetUpAttribute", false);
        }
        protected virtual bool IsFixtureTearDownMethod(MethodInfo method)
        {
            return Reflect.HasAttribute(method, "csUnit.FixtureTearDownAttribute", false);
        }
        #endregion
    }
}
