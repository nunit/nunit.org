// *********************************************************
// Copyright 2008, Charlie Poole
//
// Licensed under the Academic Free License version 3.0
// *********************************************************

using System;
using System.Collections;
using System.Collections.Specialized;
using System.Reflection;
using NUnit.Core.Builders;
using NUnit.Core.Extensibility;

namespace NUnit.Core.Extensions.CSUnit
{
	/// <summary>
	/// Builder for csunit test fixtures
	/// </summary>
	[NUnitAddin(Name="CSUnit Addin",Description="Runs CsUnit tests under NUnit")]
	public class CSUnitTestFixtureBuilder : AbstractFixtureBuilder, IAddin
	{
		private IExtensionHost host;

		#region IAddin Members
		public bool Install( IExtensionHost host )
		{
			this.host = host;
			IExtensionPoint suiteBuilders = host.GetExtensionPoint( "SuiteBuilders" );
			IExtensionPoint testBuilders = host.GetExtensionPoint( "TestCaseBuilders" );

			host.FrameworkRegistry.Register( "csUnit", "csUnit" );
			
			if ( suiteBuilders == null || testBuilders == null )
				return false;

			suiteBuilders.Install( this );

			System.Diagnostics.Trace.WriteLine( "Installed CSUnitAddin" );


			return true;
		}
		#endregion

		#region AbstractFixtureBuilder Overrides
		/// <summary>
		/// Returns a CSUnitTestFixture
		/// </summary>
		/// <param name="type">The type to use in making the fixture</param>
		/// <returns>A TestSuite or null</returns>
		protected override TestSuite MakeSuite( Type type )
		{
			return new CSUnitTestFixture( type );
		}
		
		/// <summary>
		/// Method that sets properties of the test suite based on the
		/// information in the provided Type.
		/// </summary>
		/// <param name="type">The type to examine</param>
		/// <param name="suite">The test suite being constructed</param>
		protected override void SetTestSuiteProperties( Type type, TestSuite suite )
		{
			base.SetTestSuiteProperties( type, suite );

			Attribute ignoreAttribute =
				Reflect.GetAttribute(type, "csUnit.IgnoreAttribute", false);
			if (ignoreAttribute != null)
			{
				string reason = (string)Reflect.GetPropertyValue(
					ignoreAttribute,
					"Reason",
					BindingFlags.Public | BindingFlags.Instance);

				suite.RunState = RunState.Ignored;
				suite.IgnoreReason = reason;
			}

			ArrayList categories = new ArrayList();

			Attribute testFixtureAttribute =
				Reflect.GetAttribute(type, "csUnit.TestFixtureAttribute", true);
			if (testFixtureAttribute != null)
			{
				string category = (string)Reflect.GetPropertyValue(
					testFixtureAttribute,
					"Category",
					BindingFlags.Public | BindingFlags.Instance );

				if ( category != null )
					categories.Add( category );
			}

			suite.Categories = categories;
			suite.Properties = new ListDictionary();
		}

		/// <summary>
		/// Adds test cases to the fixture. Overrides the base class 
		/// to install a CSUnitTestCaseBuilder while the tests are
		/// being added.
		/// </summary>
		/// <param name="fixtureType">The type of the fixture</param>
		protected override void AddTestCases(Type fixtureType)
		{
			IExtensionPoint testBuilders = host.GetExtensionPoint( "TestCaseBuilders" );
			ITestCaseBuilder builder = new CSUnitTestCaseBuilder();
			testBuilders.Install( builder );
			try
			{
				base.AddTestCases (fixtureType);
			}
			finally
			{
				testBuilders.Remove( builder );
			}
		}

        /// <summary>
        /// Checks to see if the fixture type has the test fixture
        /// attribute type specified in the parameters. Override
        /// to allow additional types - based on name, for example.
        /// </summary>
        /// <param name="type">The fixture type to check</param>
        /// <returns>True if the fixture can be built, false if not</returns>
        public override bool CanBuildFrom(Type type)
        {
            return Reflect.HasAttribute(type, "csUnit.TestFixtureAttribute", true);
        }

        /// <summary>
        /// Check that the fixture is valid. In addition to the base class
        /// check for a valid constructor, this method ensures that there 
        /// is no more than one of each setup or teardown method and that
        /// their signatures are correct.
        /// </summary>
        /// <param name="fixtureType">The type of the fixture to check</param>
        /// <param name="reason">A message indicating why the fixture is invalid</param>
        /// <returns>True if the fixture is valid, false if not</returns>
        protected override bool IsValidFixtureType(Type fixtureType, ref string reason)
        {
            if (!base.IsValidFixtureType(fixtureType, ref reason))
                return false;

            if (!CheckSetUpTearDownMethod(fixtureType, "csUnit.SetUpAttribute"))
            {
                reason = "Invalid SetUp method signature";
                return false;
            }

            if (!CheckSetUpTearDownMethod(fixtureType, "csUnit.TearDownAttribute"))
            {
                reason = "Invalid TearDown method signature";
                return false;
            }

            if (!CheckSetUpTearDownMethod(fixtureType, "csUnit.FixtureSetUpAttribute"))
            {
                reason = "Invalid TestFixtureSetUp method signature";
                return false;
            }

            if (!CheckSetUpTearDownMethod(fixtureType, "csUnit.FixtureTearDownAttribute"))
            {
                reason = "Invalid TestFixtureTearDown method signature";
                return false;
            }

            return true;
        }

        /// <summary>
        /// Internal helper to check a single setup or teardown method
        /// </summary>
        /// <param name="fixtureType">The type to be checked</param>
        /// <param name="attributeName">The attribute name to be checked</param>
        /// <returns>True if the method is present no more than once and has a valid signature</returns>
        private bool CheckSetUpTearDownMethod(Type fixtureType, string attributeName)
        {
            int count = Reflect.CountMethodsWithAttribute(
                fixtureType, attributeName,
                BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance | BindingFlags.Static | BindingFlags.DeclaredOnly,
                true);

            if (count == 0) return true;

            if (count > 1) return false;

            MethodInfo theMethod = Reflect.GetMethodWithAttribute(
                fixtureType, attributeName,
                BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance | BindingFlags.Static | BindingFlags.DeclaredOnly,
                true);

            if (theMethod != null)
            {
                if (theMethod.IsStatic ||
                    theMethod.IsAbstract ||
                    !theMethod.IsPublic && !theMethod.IsFamily ||
                    theMethod.GetParameters().Length != 0 ||
                    !theMethod.ReturnType.Equals(typeof(void)))
                {
                    return false;
                }
            }

            return true;
        }

        /// <summary>
        /// Method to return the description for a fixture
        /// </summary>
        /// <param name="fixtureType">The fixture to check</param>
        /// <returns>The description, if any, or null</returns>
        protected string GetFixtureDescription(Type fixtureType)
        {
            Attribute fixtureAttribute =
                Reflect.GetAttribute(fixtureType, "csUnit.TestFixtureAttribute", true);

            // Some of our tests create a fixture without the attribute
            if (fixtureAttribute != null)
                return (string)Reflect.GetPropertyValue(
                    fixtureAttribute,
                    "Description",
                    BindingFlags.Public | BindingFlags.Instance);

            return null;
        }
        #endregion
    }
}
