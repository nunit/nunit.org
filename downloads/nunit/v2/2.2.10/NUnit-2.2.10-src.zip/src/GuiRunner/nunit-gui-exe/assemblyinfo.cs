using System;
using System.Reflection;

[assembly: AssemblyTitle("NUnit-Gui")]
[assembly: AssemblyDescription("")]