// ****************************************************************
// This is free software licensed under the NUnit license. You may
// obtain a copy of the license at http://nunit.org.
// ****************************************************************

using System;

namespace TestLibraries
{

    public class Cmp
    {
        public static int Add(int a, int b)
        {
            int result;
            result = a + b;
            return result;
        }
    }
}
