using System;
using System.Reflection;

namespace NUnit.Core.Extensions
{
	/// <summary>
	/// Summary description for NUnitLiteTestMethod.
	/// </summary>
	public class NUnitLiteTestMethod : TestMethod
	{
		public NUnitLiteTestMethod( MethodInfo method ) : base( method ) 
		{
			//
			// TODO: Add constructor logic here
			//
		}

		protected override bool IsAssertException(Exception ex)
		{
			return ex.GetType().FullName == "NUnitLite.Framework.AssertionException";
		}

		protected override bool IsIgnoreException(Exception ex)
		{
			return ex.GetType().FullName == "NUnitLite.Framework.IgnoreException";
		}
	}
}
