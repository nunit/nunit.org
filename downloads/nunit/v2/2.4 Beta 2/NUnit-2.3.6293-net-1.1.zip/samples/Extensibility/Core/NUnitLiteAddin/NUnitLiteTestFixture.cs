using System;

namespace NUnit.Core.Extensions
{
	/// <summary>
	/// Summary description for NUnitLiteTestFixture.
	/// </summary>
	public class NUnitLiteTestFixture : TestFixture
	{
		public NUnitLiteTestFixture( Type type ) : base( type ) { }
	}
}
