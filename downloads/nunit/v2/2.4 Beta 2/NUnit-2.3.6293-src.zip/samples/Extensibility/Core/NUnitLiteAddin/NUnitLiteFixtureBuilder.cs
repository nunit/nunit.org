using System;
using NUnit.Core.Extensibility;
using NUnit.Core.Builders;

namespace NUnit.Core.Extensions
{
	/// <summary>
	/// Summary description for NUnitLiteFixtureBuilder.
	/// </summary>
	public class NUnitLiteFixtureBuilder : AbstractFixtureBuilder
	{
		private IExtensionHost host;

		public NUnitLiteFixtureBuilder( IExtensionHost host )
		{
			this.host = host;
		}

		protected override TestSuite MakeSuite(Type type)
		{
			return new NUnitLiteTestFixture( type );
		}

		public override bool CanBuildFrom(Type type)
		{
			return Reflect.HasAttribute( type, NUnitLite.TestFixtureAttribute, false );
		}

		protected override void AddTestCases(Type fixtureType)
		{
			IExtensionPoint testBuilders = host.GetExtensionPoint( "TestCaseBuilders" );
			testBuilders.Install( new NUnitLiteTestCaseBuilder() );
			base.AddTestCases (fixtureType);
		}


	}
}
