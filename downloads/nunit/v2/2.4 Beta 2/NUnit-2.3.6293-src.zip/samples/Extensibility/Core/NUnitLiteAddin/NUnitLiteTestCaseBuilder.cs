using System;
using NUnit.Core.Builders;

namespace NUnit.Core.Extensions
{
	/// <summary>
	/// Summary description for NUnitLiteTestCaseBuilder.
	/// </summary>
	public class NUnitLiteTestCaseBuilder : AbstractTestCaseBuilder
	{
		protected override TestCase MakeTestCase(System.Reflection.MethodInfo method)
		{
			return new NUnitLiteTestMethod( method );
		}

		public override bool CanBuildFrom(System.Reflection.MethodInfo method)
		{
			return true;
		//	return Reflect.HasAttribute( method, NUnitLite.TestAttribute, false );
		}

		protected override void SetTestProperties(System.Reflection.MethodInfo method, TestCase testCase)
		{

		}

		public override Test BuildFrom(System.Reflection.MethodInfo method)
		{
			return new NUnitLiteTestMethod( method );
		}


	}
}
