// This is the main DLL file.

#include "stdafx.h"

#include "TestProj.h"

void TestProj::Class1::TestIsTrue(void) 
{
	Assert::IsTrue( true );
}

void TestProj::Class1::TestIntsEqual(void) 
{
	Assert::AreEqual( 4, 2+2 );
}

void TestProj::Class1::TestIntsEqual_Message(void)
{
	Assert::AreEqual( 4, 2+2, "2+2=4" );
}

void TestProj::Class1::TestIntsEqual_MessageWithArgs(void)
{ 
//	Assert::AreEqual( 4, 2+2, "{0}+{1}={2}", new object[] { 2, 2, 4 } );
}

void TestProj::Class1::TestDoublesEqual(void) 
{
	Assert::AreEqual( 4.0, 2.0 + 2.0, 0.0001 );
}