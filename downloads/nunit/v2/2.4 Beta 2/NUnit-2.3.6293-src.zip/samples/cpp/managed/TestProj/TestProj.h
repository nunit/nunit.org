// TestProj.h

#pragma once

using namespace System;
using namespace NUnit::Framework;

namespace TestProj
{
	[TestFixtureAttribute]public __gc class Class1
	{
	public:
		[TestAttribute] void TestIsTrue(void);
		[TestAttribute] void TestIntsEqual(void);
		[TestAttribute] void TestIntsEqual_Message(void);
		[Test] void TestIntsEqual_MessageWithArgs(void);
		[TestAttribute] void TestDoublesEqual(void);
	};
}
