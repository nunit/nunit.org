using System;
using NUnit.Core.Extensibility;

namespace NUnit.Core.Extensions
{
	/// <summary>
	/// Summary description for Class1.
	/// </summary>
	[NUnitAddin(Description="Runs NUnitLite tests under NUnit")]
	public class NUnitLiteAddin : IAddin
	{
		#region IAddin Members
		public bool Install(IExtensionHost host)
		{
			IExtensionPoint suiteBuilders = host.GetExtensionPoint( "SuiteBuilders" );
			IExtensionPoint testBuilders = host.GetExtensionPoint( "TestCaseBuilders" );

			if ( suiteBuilders == null || testBuilders == null )
				return false;

			host.FrameworkRegistry.Register( "NUnitLite", "NUnitLite" );

			suiteBuilders.Install( new NUnitLiteFixtureBuilder( host ) );
			return true;
		}
		#endregion
	}
}
