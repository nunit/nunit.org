using System;

namespace NUnit.Core.Extensions
{
	/// <summary>
	/// Summary description for NUnitLite.
	/// </summary>
	public class NUnitLite
	{
		#region Constants
		public static readonly string TestFixtureAttribute = "NUnitLite.Framework.TestFixtureAttribute";
		public static readonly string TestAttribute = "NUnitLite.Framework.TestAttribute";
		#endregion
	}
}
