using System;
using System.Collections;
using System.Text;
using NUnit.Framework;

namespace NUnit.Util.Tests
{
    [TestFixture]
    public class RecentFileEntryTests
    {
        private RecentFileEntry entry;
        private static readonly string entryPath = "a/b/c";
        private static Version entryVersion = new Version("1.2");

        [SetUp]
        public void CreateEntry()
        {
            entry = new RecentFileEntry(entryPath, entryVersion);
        }

        [Test]
        public void EntryHasCorrectPath()
        {
            Assert.AreEqual(entryPath, entry.Path);
        }

        [Test]
        public void EntryHasCorrectVersion()
        {
            Assert.AreEqual(entryVersion, entry.CLRVersion);
        }

        [Test]
        public void EntryCanDisplayItself()
        {
            Assert.AreEqual(
                entryPath + RecentFileEntry.Separator + entryVersion.ToString(),
                entry.ToString());
        }

        [Test]
        public void CanParseSimpleFileName()
        {
            RecentFileEntry newEntry = RecentFileEntry.Parse(entryPath);
            Assert.AreEqual(entryPath, newEntry.Path);
            Assert.AreEqual(new Version(0, 0), newEntry.CLRVersion);
        }

        [Test]
        public void CanParseFileNamePlusVersionString()
        {
            string text = entryPath + RecentFileEntry.Separator + entryVersion.ToString();
            RecentFileEntry newEntry = RecentFileEntry.Parse(text);
            Assert.AreEqual(entryPath, newEntry.Path);
            Assert.AreEqual(entryVersion, newEntry.CLRVersion);
        }
    }
}
