#region Copyright (c) 2002-2003, James W. Newkirk, Michael C. Two, Alexei A. Vorontsov, Charlie Poole, Philip A. Craig
/************************************************************************************
'
' Copyright  2002-2003 James W. Newkirk, Michael C. Two, Alexei A. Vorontsov, Charlie Poole
' Copyright  2000-2002 Philip A. Craig
'
' This software is provided 'as-is', without any express or implied warranty. In no 
' event will the authors be held liable for any damages arising from the use of this 
' software.
' 
' Permission is granted to anyone to use this software for any purpose, including 
' commercial applications, and to alter it and redistribute it freely, subject to the 
' following restrictions:
'
' 1. The origin of this software must not be misrepresented; you must not claim that 
' you wrote the original software. If you use this software in a product, an 
' acknowledgment (see the following) in the product documentation is required.
'
' Portions Copyright  2002-2003 James W. Newkirk, Michael C. Two, Alexei A. Vorontsov, Charlie Poole
' or Copyright  2000-2002 Philip A. Craig
'
' 2. Altered source versions must be plainly marked as such, and must not be 
' misrepresented as being the original software.
'
' 3. This notice may not be removed or altered from any source distribution.
'
'***********************************************************************************/
#endregion

namespace NUnit.Gui.Tests
{
	using System;
	using System.Collections;
	using Microsoft.Win32;

	using NUnit.Framework;
	using NUnit.Util;
	
	/// <summary>
	/// This fixture is used to test both RecentProjects and
	/// its base class RecentFiles.  If we add any other derived
	/// classes, the tests should be refactored.
	/// </summary>
	[TestFixture]
	public class RecentProjectsFixture
	{
		static readonly int MAX = RecentFileSettings.MaxSize;
		static readonly int MIN = RecentFileSettings.MinSize;

		RecentProjectSettings projects;

		[SetUp]
		public void SetUp()
		{
			projects = new RecentProjectSettings( new MemorySettingsStorage() );
		}

		[TearDown]
		public void TearDown()
		{
			projects.Dispose();
		}

		// Set RecentFiles to a list of known values up
		// to a maximum. Most recent will be "1", next 
		// "2", and so on...
		private void SetMockValues( int count )
		{
			for( int num = count; num > 0; --num )
				projects.RecentFile = num.ToString();			
		}

		// Check that the list is set right: 1, 2, ...
		private void CheckMockValues( int count )
		{
			IList files = projects.GetFiles();
			Assert.AreEqual( count, files.Count, "Count" );
			
			for( int index = 0; index < count; index++ )
				Assert.AreEqual( (index + 1).ToString(), files[index], "Item" ); 
		}

		// Check that we can add count items correctly
		private void CheckAddItems( int count )
		{
			SetMockValues( count );
			Assert.AreEqual( "1", projects.RecentFile, "RecentFile" );

			//TODO: CHeck this logic
			if ( count > projects.MaxFiles )
				count = projects.MaxFiles;

			CheckMockValues( Math.Min( count, projects.MaxFiles ) );
		}

		// Check that the list contains a set of entries
		// in the order given and nothing else.
		private void CheckListContains( params int[] item )
		{
			IList files = projects.GetFiles();
			Assert.AreEqual( item.Length, files.Count, "Count" );

			for( int index = 0; index < files.Count; index++ )
				Assert.AreEqual( item[index].ToString(), files[index], "Item" );
		}

		[Test]
		public void RetrieveSubKey()
		{
			Assert.IsNotNull(projects);
		}

		[Test]
		public void DefaultRecentFilesCount()
		{
			Assert.AreEqual( RecentProjectSettings.DefaultSize, projects.MaxFiles );
		}

		[Test]
		public void RecentFilesCount()
		{
			projects.MaxFiles = 12;
			Assert.AreEqual( 12, projects.MaxFiles );
		}

		[Test]
		public void RecentFilesCountOverMax()
		{
			projects.MaxFiles = MAX + 1;
			Assert.AreEqual( MAX, projects.MaxFiles );
		}

		[Test]
		public void RecentFilesCountUnderMin()
		{
			projects.MaxFiles = MIN - 1;
			Assert.AreEqual( MIN, projects.MaxFiles );
		}

		[Test]
		public void RecentFilesCountAtMax()
		{
			projects.MaxFiles = MAX;
			Assert.AreEqual( MAX, projects.MaxFiles );
		}

		[Test]
		public void RecentFilesCountAtMin()
		{
			projects.MaxFiles = MIN;
			Assert.AreEqual( MIN, projects.MaxFiles );
		}

		[Test]
		public void EmptyList()
		{
			Assert.IsNotNull(  projects.GetFiles(), "GetFiles() returned null" );
			Assert.AreEqual( 0, projects.GetFiles().Count );
			Assert.IsNull( projects.RecentFile, "No RecentFile should return null" );
		}

		[Test]
		public void AddSingleItem()
		{
			CheckAddItems( 1 );
		}

		[Test]
		public void AddMaxItems()
		{
			CheckAddItems( 5 );
		}

		[Test]
		public void AddTooManyItems()
		{
			CheckAddItems( 10 );
		}

		[Test]
		public void IncreaseSize()
		{
			projects.MaxFiles = 10;
			CheckAddItems( 10 );
		}

		[Test]
		public void ReduceSize()
		{
			projects.MaxFiles = 3;
			CheckAddItems( 10 );
		}

		[Test]
		public void IncreaseSizeAfterAdd()
		{
			SetMockValues(5);
			projects.MaxFiles = 7;
			projects.RecentFile = "30";
			projects.RecentFile = "20";
			projects.RecentFile = "10";
			CheckListContains( 10, 20, 30, 1, 2, 3, 4 );
		}

		[Test]
		public void ReduceSizeAfterAdd()
		{
			SetMockValues( 5 );
			projects.MaxFiles = 3;
			CheckMockValues( 3 );
		}

		[Test]
		public void ReorderLastProject()
		{
			SetMockValues( 5 );
			projects.RecentFile = "5";
			CheckListContains( 5, 1, 2, 3, 4 );
		}

		[Test]
		public void ReorderSingleProject()
		{
			SetMockValues( 5 );
			projects.RecentFile = "3";
			CheckListContains( 3, 1, 2, 4, 5 );
		}

		[Test]
		public void ReorderMultipleProjects()
		{
			SetMockValues( 5 );
			projects.RecentFile = "3";
			projects.RecentFile = "5";
			projects.RecentFile = "2";
			CheckListContains( 2, 5, 3, 1, 4 );
		}

		[Test]
		public void ReorderSameProject()
		{
			SetMockValues( 5 );
			projects.RecentFile = "1";
			CheckListContains( 1, 2, 3, 4, 5 );
		}

		[Test]
		public void ReorderWithListNotFull()
		{
			SetMockValues( 3 );
			projects.RecentFile = "3";
			CheckListContains( 3, 1, 2 );
		}

		[Test]
		public void RemoveFirstProject()
		{
			SetMockValues( 3 );
			projects.Remove("1");
			CheckListContains( 2, 3 );
		}

		[Test]
		public void RemoveOneProject()
		{
			SetMockValues( 4 );
			projects.Remove("2");
			CheckListContains( 1, 3, 4 );
		}

		[Test]
		public void RemoveMultipleProjects()
		{
			SetMockValues( 5 );
			projects.Remove( "3" );
			projects.Remove( "1" );
			projects.Remove( "4" );
			CheckListContains( 2, 5 );
		}
		
		[Test]
		public void RemoveLastProject()
		{
			SetMockValues( 5 );
			projects.Remove("5");
			CheckListContains( 1, 2, 3, 4 );
		}
	}
}
