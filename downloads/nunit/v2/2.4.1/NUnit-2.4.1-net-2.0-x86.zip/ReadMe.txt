This zip file contains files that may be added to an NUnit 2.4.1 installation in order to successfully run tests of 32-bit applications on a 64-bit system.

Copy the following to the NUnit 2.4.1 bin folder:
  nunit-console-x86.exe
  nunit-console-x86.exe.config
  nunit-x86.exe
  nunit-x86.exe.config
