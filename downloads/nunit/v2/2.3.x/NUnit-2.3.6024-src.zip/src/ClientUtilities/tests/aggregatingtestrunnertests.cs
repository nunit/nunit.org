using System;
using NUnit.Framework;
using NUnit.Core;
using NUnit.Tests;
using NUnit.Mocks;

namespace NUnit.Util.Tests
{
    [TestFixture]
    class AggregatingTestRunnerTests
    {
        [Test]
        public void TestCountAggregatesTwoRunners()
        {
            DynamicMock mock1 = new DynamicMock("runner1", typeof(TestRunner));
            DynamicMock mock2 = new DynamicMock( "runner2", typeof(TestRunner) );
            TestRunner runner1 = (TestRunner)mock1.MockInstance;
            TestRunner runner2 = (TestRunner)mock2.MockInstance;
            TestRunner runner = new AggregatingTestRunner(runner1,runner2);
        }

    }
}
