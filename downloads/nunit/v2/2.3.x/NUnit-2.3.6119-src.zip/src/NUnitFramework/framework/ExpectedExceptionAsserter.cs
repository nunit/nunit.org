using System;

namespace NUnit.Framework
{
	/// <summary>
	/// Summary description for ExpectedExceptionAsserter.
	/// </summary>
	public class ExpectedExceptionAsserter : AbstractAsserter
	{
		private Type expectedType;
		private Exception actual;

		public ExpectedExceptionAsserter( Type expectedType, Exception actual, string message, object[] args )
			: base( message, args )
		{
			this.expectedType = expectedType;
			this.actual = actual;
		}

		public override bool Test()
		{
			return base.Test ();
		}

		public override string Message
		{
			get
			{
				return base.Message;
			}
		}


	}
}
