using System;

namespace NUnit.Core.Filters
{
	/// <summary>
	/// AndNotFilter allows for including on a filter criterion unless
	/// some other criterion applies. It is intended for use with runners
	/// that allow separte specification of include and exclude criteria.
	/// </summary>
	public class AndNotFilter : ITestFilter
	{
		private ITestFilter include;
		private ITestFilter exclude;

		public AndNotFilter( ITestFilter include, ITestFilter exclude )
		{
			this.include = include;
			this.exclude = exclude;
		}

		public bool Pass( ITest test )
		{
			return this.include.Pass( test ) && !this.exclude.Pass( test );
		}
	}
}
