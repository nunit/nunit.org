using System;
using NUnit.Framework;
using NUnit.Core;

namespace PooleConsulting.LibrarySystem.Tests
{
	/// <summary>
	/// Summary description for SuitePropertyTest.
	/// </summary>
	public class SuitePropertyTest
	{
		[Suite]
		public static TestSuite Suite
		{
			get
			{
				TestSuite suite = new TestSuite( "My Test Suite" );
				suite.Add( new NestedFixture() );
				suite.Add( new SomeTestFixture() );
				suite.Add( new AnotherSuite() );
				return suite;
			}
		}

		public class NestedFixture
		{
			[Test]
			public void NestedClassTest()
			{
			}
		}

		[Test]
		public void LoneTestDirectlyUnderSuite()
		{
		}
	}
	
	public class SomeTestFixture
	{
		[Test]
		public void SomeTest()
		{
		}
	}

	// Note this is not public, so it is not added at the top level
	class AnotherSuite
	{
		[Suite]
		public static TestSuite Suite
		{
			get
			{
				TestSuite suite = new TestSuite("MySuite");
				suite.Add( new AnotherTestFixture() );
				return suite;
			}
		}
	}

	public class AnotherTestFixture
	{
		[Test]
		public void AnotherTest()
		{
		}
	}
}
