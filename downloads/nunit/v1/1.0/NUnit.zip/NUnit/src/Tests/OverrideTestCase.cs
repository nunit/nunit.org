namespace NUnit.Tests {
    
  using System;

  /// <summary>Test class used in SuiteTest.</summary>
  public class OverrideTestCase: OneTestCase {
    public OverrideTestCase(String name) : base(name) {}
    public override void TestCase() {
    }
  }
}
