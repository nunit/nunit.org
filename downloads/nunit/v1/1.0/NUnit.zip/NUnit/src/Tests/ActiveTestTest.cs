namespace NUnit.Tests {

  using System;
  using NUnit.Extensions;
  using NUnit.Framework;

  /// <summary>Testing the ActiveTest support.</summary>
  public class ActiveTestTest: TestCase {

    public class SuccessTest: TestCase {
      public SuccessTest(String name) : base(name) {}
      public void Success() {}
    }

    public ActiveTestTest(String name) : base(name) {}

    ActiveTestSuite CreateActiveTestSuite() {
      ActiveTestSuite suite = new ActiveTestSuite();
      for (int i=0; i < 100; i++)
        suite.AddTest(new SuccessTest("Success"));
      return suite;
    }

    public void TestActiveRepeatedTest() {
      ITest test = new RepeatedTest(CreateActiveTestSuite(), 5);
      TestResult result = new TestResult();
      test.Run(result);
      AssertEquals(500, result.RunCount);
      AssertEquals(0, result.FailureCount);
      AssertEquals(0, result.ErrorCount);
    }

    public void TestActiveRepeatedTest0() {
      ITest test = new RepeatedTest(CreateActiveTestSuite(), 0);
      TestResult result = new TestResult();
      test.Run(result);
      AssertEquals(0, result.RunCount);
      AssertEquals(0, result.FailureCount);
      AssertEquals(0, result.ErrorCount);
    }

    public void TestActiveRepeatedTest1() {
      ITest test = new RepeatedTest(CreateActiveTestSuite(), 1);
      TestResult result = new TestResult();
      test.Run(result);
      AssertEquals(100, result.RunCount);
      AssertEquals(0, result.FailureCount);
      AssertEquals(0, result.ErrorCount);
    }

    public void TestActiveTest() {
      ITest test = CreateActiveTestSuite();
      TestResult result = new TestResult();
      test.Run(result);
      AssertEquals(100, result.RunCount);
      AssertEquals(0, result.FailureCount);
      AssertEquals(0, result.ErrorCount);
    }
  }
}
