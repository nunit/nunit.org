namespace NUnit.Tests {

  using System;

  using NUnit.Framework;

  /// <summary>Test class used in SuiteTest.</summary>
  public class NotPublicTestCase: TestCase {
    public NotPublicTestCase(String name) : base(name) {}
    protected void TestNotPublic() {
    }
    public void TestPublic() {
    }
  }
}
