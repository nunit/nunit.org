namespace NUnit.Tests {

  using System;
  using NUnit.Framework;

  /**
   * A test case testing the testing framework.
   *
   */
  public class TestCaseTest: TestCase {
    
    protected class TornDown: TestCase {
      internal bool fTornDown= false;
        
      protected internal TornDown(String name) : base(name){
      }
      protected override void TearDown() {
        fTornDown= true;
      }
      protected override void RunTest() {
        throw new SystemException();
      }
    }

    public TestCaseTest(String name) : base(name) {
    }
    public void TestCaseToString() {
      // This test wins the award for twisted snake tail eating while
      // writing self Tests. And you thought those weird anonymous
      // inner classes were bad...
      AssertEquals("TestCaseToString(NUnit.Tests.TestCaseTest)", ToString());
    }
    public class ErrorTestCase: TestCase {
      public ErrorTestCase(): base("Error") {}
      protected override void RunTest() {
        throw new SystemException();
      }
    }
    public void TestError() {
      TestCase error= new ErrorTestCase();
      VerifyError(error);
    }
    public class FailureTestCase: TestCase {
      public FailureTestCase() : base ("Failure") {}
      protected override void RunTest() {
        Fail();
      }
    }
    public void TestFailure() {
      TestCase failure= new FailureTestCase();
      VerifyFailure(failure);
    }
    protected class FailsTornDown: TornDown {
      public FailsTornDown() : base("fails") {}
      protected override void TearDown() {
        base.TearDown();
        throw new SystemException();
      }
      protected override void RunTest() {
        throw new SystemException();
      }
    }
    public void TestRunAndTearDownFails() {
      TornDown fails= new FailsTornDown();
      VerifyError(fails);
      Assert(fails.fTornDown);
    }
    protected class SetupFailsTestCase: TestCase {
      public SetupFailsTestCase() : base("success") {}
      protected override void SetUp() {
        throw new SystemException();
      }
      protected override void RunTest() {
      }
    }
    public void TestSetupFails() {
      TestCase fails= new SetupFailsTestCase();
      VerifyError(fails);
    }
    protected class SuccessTestCase: TestCase {
      public SuccessTestCase() : base ("sucess") { }
      protected override void RunTest() {
      }
    }
    public void TestSuccess() {
      TestCase success= new SuccessTestCase();
      VerifySuccess(success);
    }
    public void TestTearDownAfterError() {
      TornDown fails= new TornDown("fails");
      VerifyError(fails);
      Assert(fails.fTornDown);
    }
    protected class TearDownFailsTestCase : TestCase {
      public TearDownFailsTestCase() : base ("success") {}
      protected override void TearDown() {
        throw new SystemException();
      }
      protected override void RunTest() { }
    }
    public void TestTearDownFails() {
      TestCase fails= new TearDownFailsTestCase();
      VerifyError(fails);
    }
    protected class TearDownSetupFailsTestCase: TornDown {
      public TearDownSetupFailsTestCase() : base ("fails") {}
      protected override void SetUp() {
        throw new SystemException();
      }
    }
    public void TestTearDownSetupFails() {
      TornDown fails= new TearDownSetupFailsTestCase();
      VerifyError(fails);
      Assert(!fails.fTornDown);
    }
    public void TestWasRun() {
      WasRun test= new WasRun("");
      test.Run();
      Assert(test.fWasRun);
    }
    private void VerifyError(TestCase test) {
      TestResult result= test.Run();
      Assert(result.RunCount == 1);
      Assert(result.FailureCount == 0);
      Assert(result.ErrorCount == 1);
    }
    private void VerifyFailure(TestCase test) {
      TestResult result= test.Run();
      Assert(result.RunCount == 1);
      Assert(result.FailureCount == 1);
      Assert(result.ErrorCount == 0);
    }
    private void VerifySuccess(TestCase test) {
      TestResult result= test.Run();
      Assert(result.RunCount == 1);
      Assert(result.FailureCount == 0);
      Assert(result.ErrorCount == 0);
    }
  }
}
