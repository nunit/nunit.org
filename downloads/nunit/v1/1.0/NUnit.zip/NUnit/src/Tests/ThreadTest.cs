namespace NUnit.Tests {

  using System;
  using System.Threading;

  using NUnit.Framework;

  /// <summary>A test case Testing the running of Tests across multiple
  /// threads.</summary></remarks>
  /// Demonstrates that running a test case across different threads
  /// doesn't work yet.</remarks>
  public class ThreadTest: TestCase {
    
    public ThreadTest(String name) : base(name) {}
    public static ITest Suite() {
      return new TestSuite(typeof(ThreadTest));
    }
    public void TestRemote() {            
      Thread t= new Thread(new ThreadStart(VerifyResults));
      t.Start();
      try {
        t.Join();
      }
      catch(ThreadInterruptedException) {
        Fail("interrupted test");
      }
    }
    protected class RunInThreadTestCase: TestCase {
      public RunInThreadTestCase() : base("runInThread") {}
      protected override void RunTest() {
        Thread t= new Thread(new ThreadStart(Assertion.Fail));
        t.Start();
        try {
          t.Join();
        }
        catch(ThreadInterruptedException ) {
          Fail("interrupted test");
        }
      }
    }
    public void TestRunInThread() {
      Thread t= new Thread(new ThreadStart(VerifyResults));
      TestCase runInThread= new RunInThreadTestCase();

      TestResult result= runInThread.Run();
      Assert(result.RunCount == 1);
      Assert(result.FailureCount == 1);
      Assert(result.ErrorCount == 0);
    }
        
    public void VerifyResults() {
      Fail("verify failed");
    }
  }
}
