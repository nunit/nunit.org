namespace NUnit.Tests {

  using System;
  using NUnit.Framework;

  /// <summary>A fixture for Testing the "auto" test suite feature.</summary>
  public class SuiteTest: TestCase {
    protected TestResult fResult;
        
    public SuiteTest(String name) : base(name) {}
    
    protected override void SetUp() {
      fResult= new TestResult();
    }
    public static ITest Suite() {
        
      TestSuite suite= new TestSuite("Suite Tests");
      // build the suite manually
      suite.AddTest(new SuiteTest("TestNoTestCaseClass"));
      suite.AddTest(new SuiteTest("TestNoTestCases"));
      suite.AddTest(new SuiteTest("TestOneTestCase"));
      suite.AddTest(new SuiteTest("TestNotPublicTestCase"));
      suite.AddTest(new SuiteTest("TestNotVoidTestCase"));
      suite.AddTest(new SuiteTest("TestNotExistingTestCase"));
      suite.AddTest(new SuiteTest("TestInheritedTests"));
      suite.AddTest(new SuiteTest("TestShadowedTests"));
            
      return suite;
    }
        
    public void TestInheritedTests() {
      TestSuite suite= new TestSuite(typeof(InheritedTestCase));
      suite.Run(fResult);
      Assert(fResult.WasSuccessful);
      AssertEquals(2, fResult.RunCount);
    }
        
    public void TestNoTestCaseClass() {
      ITest t= new TestSuite(typeof(NoTestCaseClass));
      t.Run(fResult);
      AssertEquals(1, fResult.RunCount);  // warning test
      Assert(! fResult.WasSuccessful);
    }
        
    public void TestNoTestCases() {
      ITest t= new TestSuite(typeof(NoTestCases));
      t.Run(fResult);
      Assert(fResult.RunCount == 1);  // warning test
      Assert(fResult.FailureCount == 1);
      Assert(! fResult.WasSuccessful);
    }
        
    public void TestNotExistingTestCase() {
      ITest t= new SuiteTest("NotExistingMethod");
      t.Run(fResult);
      Assert(fResult.RunCount == 1);  
      Assert(fResult.FailureCount == 1);
      Assert(fResult.ErrorCount == 0);
    }
        
    public void TestNotPublicTestCase() {
      TestSuite suite= new TestSuite(typeof(NotPublicTestCase));
      // 1 public test case + 1 warning for the non-public test case
      AssertEquals(2, suite.CountTestCases);
    }

    public void TestNotVoidTestCase() {
      TestSuite suite= new TestSuite(typeof(NotVoidTestCase));
      Assert(suite.CountTestCases == 1);
    }

    public void TestOneTestCase() {
      ITest t= new TestSuite(typeof(OneTestCase));
      t.Run(fResult);
      Assertion.Assert(fResult.RunCount == 1);  
      Assert(fResult.FailureCount == 0);
      Assert(fResult.ErrorCount == 0);
      Assert(fResult.WasSuccessful);
    }
        
    public void TestShadowedTests() {
      TestSuite suite= new TestSuite(typeof(OverrideTestCase));
      suite.Run(fResult);
      AssertEquals(1, fResult.RunCount);
    }
  }
}
