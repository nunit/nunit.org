namespace NUnit.Tests {
  
  using System;
  
  using NUnit.Framework;
  
  /// <summary>A test case testing the testing framework.</summary>
  public class Success: TestCase {

    public Success(String name) : base(name) {}
    public void Test() {
    }
  }
}
