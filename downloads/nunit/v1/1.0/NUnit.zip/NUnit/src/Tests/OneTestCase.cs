namespace NUnit.Tests {

  using System;

  using NUnit.Framework;

  /// <summary>Test class used in SuiteTest.</summary>
  public class OneTestCase: TestCase {
    public OneTestCase(String name): base(name){}

    public void NoTestCase() {
    }

    public virtual void TestCase() {
    }

    public void TestCase(int arg) {
    }
  }
}
