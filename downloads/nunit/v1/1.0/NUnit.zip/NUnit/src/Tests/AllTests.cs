namespace NUnit.Tests {

  using System;

  using NUnit.Framework;
  using NUnit.Runner;

  /// <summary>TestSuite that runs all the sample Tests.</summary>
  public class AllTests {

    public static ITest Suite {
      get {
        TestSuite suite= new TestSuite("Framework Tests");
        suite.AddTest(new TestSuite(typeof(ExtensionTest)));
        suite.AddTest(new TestSuite(typeof(TestCaseTest)));
        suite.AddTest(SuiteTest.Suite()); // Tests suite building, so can't use it 
        suite.AddTest(new TestSuite(typeof(ExceptionTestCaseTest)));
                suite.AddTest(new TestSuite(typeof(ExpectExceptionTest)));
        suite.AddTest(new TestSuite(typeof(TestListenerTest)));
        suite.AddTest(new TestSuite(typeof(ActiveTestTest)));
        suite.AddTest(new TestSuite(typeof(AssertTest)));
        suite.AddTest(new TestSuite(typeof(TextRunnerTest)));
        if (!BaseTestRunner.InVAJava()){
          suite.AddTest(new TestSuite(typeof(TestTestCaseClassLoader)));
        }
        return suite;
      }
    }
  }
}
