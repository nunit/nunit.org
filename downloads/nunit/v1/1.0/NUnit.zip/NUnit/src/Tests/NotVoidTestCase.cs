namespace NUnit.Tests {

  using System;

  using NUnit.Framework;

  /// <summary>Test class used in SuiteTest.</summary>
  public class NotVoidTestCase: TestCase {
    public NotVoidTestCase(String name) : base(name) {}
    public int TestNotVoid() {
      return 1;
    }
    public void TestVoid() {
    }
  }
}
