namespace NUnit.Tests {

  using NUnit.Framework;
  using NUnit.Runner;

  /// <summary>Test class used in TestTestCaseClassLoader</summary>
  public class ClassLoaderTest : Assertion {
    public ClassLoaderTest() {
    }
    public void Verify() {
#if false
      VerifyApplicationClassLoadedByTestLoader();
      VerifySystemClassNotLoadedByTestLoader();
#endif
    }
#if false
    private bool IsTestCaseClassLoader(ClassLoader cl) {
      return (cl != null &&
              cl.GetType().ToString().Equals(
                                             NUnit.Runner.TestCaseClassLoader.GetType().ToString()));
    }
    private void VerifyApplicationClassLoadedByTestLoader() {
      Assert(IsTestCaseClassLoader(getClass().GetClassLoader()));
    } 
    private void VerifySystemClassNotLoadedByTestLoader() {
      Assert(!IsTestCaseClassLoader(typeof(object).GetClassLoader()));
      Assert(!IsTestCaseClassLoader(typeof(TestCase).GetClassLoader()));
    }
#endif
  }
}
