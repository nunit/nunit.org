namespace NUnit.Tests {

  using System;
  using NUnit.Framework;

  /// <summary>Test class used in SuiteTest.</summary>
  public class TestListenerTest: TestCase, ITestListener {
    private TestResult fResult;
    private int fStartCount;
    private int fEndCount;
    private int fFailureCount;
    private int fErrorCount;

    public TestListenerTest(String name): base(name) {}

    public void AddError(ITest test, Exception t) {
      fErrorCount++;
    }

    public void AddFailure(ITest test, AssertionFailedError t) {
      fFailureCount++;
    }

    public void EndTest(ITest test) {
      fEndCount++;
    }

    protected override void SetUp() {
      fResult= new TestResult();
      fResult.AddListener(this);
            
      fStartCount= 0;
      fEndCount= 0;
      fFailureCount= 0;
    }

    public void StartTest(ITest test) {
      fStartCount++;
    }

    protected class ErrorTestCase: TestCase {
      public ErrorTestCase() : base("noop") {}
      protected override void RunTest() {
        throw new SystemException();
      }
    }

    public void TestError() {
      TestCase test= new ErrorTestCase();
      test.Run(fResult);
      AssertEquals(1, fErrorCount);
      AssertEquals(1, fEndCount);
    }

    protected class FailTestCase: TestCase {
      public FailTestCase() : base("noop") {}
      protected override void RunTest() {
        Fail();
      }
    }

    public void TestFailure() {
      TestCase test= new FailTestCase();
      test.Run(fResult);
      AssertEquals(1, fFailureCount);
      AssertEquals(1, fEndCount);
    }

    protected class NoOpTestCase: TestCase {
      public NoOpTestCase() : base("noop") {}
      protected override void RunTest() {
      }
    }

    public void TestStartStop() {
      TestCase test= new NoOpTestCase();
      test.Run(fResult);
      AssertEquals(1, fStartCount);
      AssertEquals(1, fEndCount);
    }
  }
}
