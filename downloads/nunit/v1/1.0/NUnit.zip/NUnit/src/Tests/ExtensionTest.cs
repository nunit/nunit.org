namespace NUnit.Tests {

  using System;
  using NUnit.Extensions;
  using NUnit.Framework;


  /// <summary>A test case testing the extensions to the Testing framework.
  /// </summary>
  public class ExtensionTest: TestCase {
    private class TornDown: TestSetup {
      protected internal bool fTornDown= false;
            
      protected TornDown(ITest test) : base(test) {}
      protected override void TearDown() {
        fTornDown= true;
      }
    }
    public ExtensionTest(String name) : base(name) {}

    protected class RunningSetupFailure: TestCase {
      public RunningSetupFailure() : base("Failure") {}
      protected override void RunTest() {
        Fail();
      }
    }
    public void TestRunningErrorInTestSetup() {
      TestCase test= new RunningSetupFailure();
      TestSetup wrapper= new TestSetup(test);

      TestResult result= new TestResult();
      wrapper.Run(result);
      Assert(!result.WasSuccessful);
    }
    protected class RunningSetupError: TestCase {
      public RunningSetupError(): base("Error") {}
      protected override void RunTest() {
        throw new SystemException();
      }
    }
    public void TestRunningErrorsInTestSetup() {
      TestCase failure= new RunningSetupFailure();
      TestCase error= new RunningSetupError();

      TestSuite suite= new TestSuite();
      suite.AddTest(failure);
      suite.AddTest(error);
            
      TestSetup wrapper= new TestSetup(suite);
            
      TestResult result= new TestResult();
      wrapper.Run(result);
            
      AssertEquals(1, result.FailureCount);
      AssertEquals(1, result.ErrorCount);
    }

    private class TornDownTest: TornDown {
      public TornDownTest(ITest test) : base(test) {}
      protected override void SetUp() {
        Fail();
      }
    }
    public void TestSetupErrorDontTearDown() {
      WasRun test= new WasRun("");
                
      TornDown wrapper= new TornDownTest(test);

      TestResult result= new TestResult();
      wrapper.Run(result);

      Assert(!wrapper.fTornDown);
    }
    protected class SetupFailTest: TestSetup {
      public SetupFailTest(ITest test) : base(test) {}
      protected override void SetUp() {
        Fail();
      }
    }
    public void TestSetupErrorInTestSetup() {
      WasRun test= new WasRun("");
      TestSetup wrapper= new SetupFailTest(test);

      TestResult result= new TestResult();
      wrapper.Run(result);

      Assert(!test.fWasRun);
      Assert(!result.WasSuccessful);
    }
  }
}
