namespace NUnit.Tests {

  using System;

  /// <summary>Test class used in SuiteTest.</summary>
  public class NoTestCaseClass {
    public NoTestCaseClass(String name) {
    }
    public void TestSuccess() {
    }
  }
}
