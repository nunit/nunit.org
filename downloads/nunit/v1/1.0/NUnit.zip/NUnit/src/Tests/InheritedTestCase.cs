namespace NUnit.Tests {

  using System;

  /// <summary>Test class used in SuiteTest.</summary>
  public class InheritedTestCase: OneTestCase {
    public InheritedTestCase(String name) : base(name) {}
    public void Test2() {
    }
  }
}
