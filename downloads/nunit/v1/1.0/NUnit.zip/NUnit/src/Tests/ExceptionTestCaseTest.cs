namespace NUnit.Tests {
  
  using System;
  
  using NUnit.Extensions;
  using NUnit.Framework;
  
  public class ExceptionTestCaseTest: NUnit.Framework.TestCase {

    public ExceptionTestCaseTest(String name) : base(name) {}
    protected class ThrowExceptionTestCase: ExceptionTestCase {
      public ThrowExceptionTestCase(String name, Type exception)
        : base(name, exception) {}
      public void Test() {
        throw new IndexOutOfRangeException();
      }
    }
    protected class ThrowRuntimeExceptionTestCase: ExceptionTestCase {
      public ThrowRuntimeExceptionTestCase(String name, Type exception)
        : base(name, exception) {}
      public void Test() {
        throw new SystemException();
      }
    }
    protected class ThrowNoExceptionTestCase: ExceptionTestCase {
      public ThrowNoExceptionTestCase(String name, Type exception)
        : base(name, exception) {}
      public void Test() {
      }
    }
    public void TestExceptionSubclass() {
      ExceptionTestCase test=
        new ThrowExceptionTestCase("Test", typeof(Exception));
      TestResult result= test.Run();
      AssertEquals(1, result.RunCount);
      Assert(result.WasSuccessful);
    }
    public void TestExceptionTest() {
      ExceptionTestCase test=
        new ThrowExceptionTestCase("Test", typeof(IndexOutOfRangeException));
      TestResult result= test.Run();
      AssertEquals(1, result.RunCount);
      Assert(result.WasSuccessful);
    }
    public void TestFailure() {
      ExceptionTestCase test=
        new ThrowRuntimeExceptionTestCase("Test",
                                          typeof(IndexOutOfRangeException));
      TestResult result= test.Run();
      AssertEquals(1, result.RunCount);
      AssertEquals(1, result.ErrorCount);
    }
    public void TestNoException() {
      ExceptionTestCase test=
        new ThrowNoExceptionTestCase("Test", typeof(Exception));
      TestResult result= test.Run();
      AssertEquals(1, result.RunCount);
      AssertEquals(1, result.FailureCount);
    }
    public void TestWrongException() {
      ExceptionTestCase test=
        new ThrowRuntimeExceptionTestCase("Test",
                                          typeof(IndexOutOfRangeException));
      TestResult result= test.Run();
      AssertEquals(1, result.RunCount);
      AssertEquals(1, result.ErrorCount);
    }
  }
}
