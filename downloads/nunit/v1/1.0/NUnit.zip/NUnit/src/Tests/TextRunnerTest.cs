namespace NUnit.Tests {

  using System;
  using System.Diagnostics;
  using System.Reflection;

  using NUnit.Framework;

  public class TextRunnerTest: TestCase {
    private String testDll;
    private String nunitExe;
    public TextRunnerTest(String name) : base(name) {
      testDll = "\"" + GetType().Module.FullyQualifiedName + "\"";
      String currentExe = typeof(NUnit.Top).Module.FullyQualifiedName;
      int slash = currentExe.LastIndexOf('\\');
      nunitExe = "\"" + currentExe.Substring(0, slash + 1)
        + "NUnitConsole.exe\"";
    }
    
    public void TestFailure() {
        ExecTest("NUnit.Tests.Failure", -1);
    }

    public void TestSuccess() {
        ExecTest("NUnit.Tests.Success", 0);
    }

    public void TestError() {
        ExecTest("NUnit.Tests.BogusDude", -1);
    }
    
    void ExecTest(String testClass, int expected) { 
      Process p= Process.Start(nunitExe, "/t " + testClass + ',' + testDll);
      
      p.WaitForExit();
      AssertEquals(expected, p.ExitCode);
    }
  }
}
