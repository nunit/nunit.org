namespace NUnit.Tests {

  using System;

  using NUnit.Framework;

  public class ExpectExceptionTest : TestCase {
    public ExpectExceptionTest(String name) : base(name) {}
    [ExpectException(typeof(Exception))]
      public void TestSingle()
    {
      throw new Exception("single exception");
    }

    [ExpectException(typeof(ArgumentException))]
      [ExpectException(typeof(CoreException))]
      public void TestList()
    {
      throw new ArgumentException("List of exceptions");
    }

    public void TestInvalid()
    {
      TestSuite suite = new TestSuite(typeof(InvalidExceptionTests));
      TestResult result= new TestResult();
      suite.Run(result);
      AssertEquals(2, result.RunCount);
      AssertEquals(2, result.FailureCount);
    }

    protected class InvalidExceptionTests : TestCase {
      public InvalidExceptionTests(string name) : base(name) {}
      [ExpectException(typeof(ArgumentException))]
        public void Test() {
        ;
      }

      [ExpectException(typeof(ArgumentException))]
        public void TestWrongException() {
        throw new IndexOutOfRangeException("wrong exception");
      }
    }
  }
}
