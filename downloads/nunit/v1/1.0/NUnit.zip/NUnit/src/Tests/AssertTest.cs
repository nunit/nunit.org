namespace NUnit.Tests {

  using System;
  using NUnit.Framework;

  public class AssertTest: TestCase {
    
    public AssertTest(String name) : base(name) {
    }
    public void TestAssertEquals() {
      Object o= new Object();
      AssertEquals(o, o);
    }
    public void TestAssertEqualsNaNFails() {
      try {
        AssertEquals(1.234, Double.NaN, 0.00001);
      } catch (AssertionFailedError) {
        return;
      }
      Fail();
     }         
    public void TestAssertEqualsNull() {
      AssertEquals(null, null);
    }
    public void TestAssertNanEqualsFails() {
      try {
        AssertEquals(Double.NaN, 1.234, 0.00001);
      } catch (AssertionFailedError) {
        return;
      }
      Fail();
     }         
    public void TestAssertNanEqualsNaNFails() {
      try {
        AssertEquals(Double.NaN, Double.NaN, 0.00001);
      } catch (AssertionFailedError) {
        return;
      }
      Fail();
     }         
    public void TestAssertNull() {
      AssertNull(null);
    }
    public void TestAssertNullNotEqualsNull() {
      try {
        AssertEquals(null, new Object());
      } catch (AssertionFailedError) {
        return;
      }
      Fail();
    }
    public void TestAssertSame() {
      Object o= new Object();
      AssertSame(o, o);
    }
    public void TestAssertSameFails() {
      try {
        object one = 1;
        object two = 1;
        AssertSame(one, two);
      } catch (AssertionFailedError) {
        return;
      }
      Fail();    
    }
    public void TestFail() {
      try {
        Fail();
      } catch (AssertionFailedError) {
        return;
      }
      throw new AssertionFailedError("fail"); // You can't call fail() here
    }
    public void TestFailAssertNotNull() {
      try {
        AssertNotNull(null);
      } catch (AssertionFailedError) {
        return;
      }
      Fail();
    }
    public void TestSucceedAssertNotNull() {
      AssertNotNull(new Object());
    }
  }
}
