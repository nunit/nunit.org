namespace NUnit.Extensions {

  using System;

  using NUnit.Framework;
  /// <summary>A Decorator that runs a test repeatedly.</summary>
  public class RepeatedTest: TestDecorator {
    private readonly int fTimesRepeat;
    
    public RepeatedTest(ITest test, int repeat) : base(test) {
      fTimesRepeat= repeat;
    }
    public override int CountTestCases {
      get { return base.CountTestCases * fTimesRepeat; }
    }
    public override void Run(TestResult result) {
      for (int i= 0; i < fTimesRepeat; i++) {
        if (result.ShouldStop)
          break;
        base.Run(result);
      }
    }
    public override String ToString() {
      return base.ToString()+"(repeated)";
    }
  }
}
