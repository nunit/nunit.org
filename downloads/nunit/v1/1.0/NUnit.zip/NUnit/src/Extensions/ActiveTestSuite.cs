namespace NUnit.Extensions {
    
  using System;
  using System.Threading;
  
  using NUnit.Framework;
  
  /// <summary>A TestSuite for active Tests. I waits until all
  /// active tests have terminated.
  /// -- Aarhus Radisson Scandinavian Center 11th floor</summary>
  public class ActiveTestSuite: TestSuite {
    private int fActiveTestDeathCount;

    public override void Run(TestResult result) {
      fActiveTestDeathCount= 0;
      base.Run(result);
      WaitUntilFinished();
    }
    
    public class ThreadLittleHelper {
      private ITest fTest;
      private TestResult fResult;
      private ActiveTestSuite fSuite;
      public ThreadLittleHelper(ITest test, TestResult result,
                                ActiveTestSuite suite) {
        fSuite = suite;
        fTest = test;
        fResult = result;
      }
      public void Run() {
        try {
          fSuite.BaseRunTest(fTest, fResult);
        } finally {
          fSuite.RunFinished(fTest);
        }
      }
    }
    public void BaseRunTest(ITest test, TestResult result) {
      base.RunTest(test, result);
    }
    public override void RunTest(ITest test, TestResult result) {
      ThreadLittleHelper tlh = new ThreadLittleHelper(test, result, this);
      Thread t = new Thread(new ThreadStart(tlh.Run));
      t.Start();
    }
    void WaitUntilFinished() {
      lock(this) {
        while (fActiveTestDeathCount < TestCount) {
          try {
            Monitor.Wait(this);
          } catch (ThreadInterruptedException) {
            return; // TBD
          }
        } 
      }
    }
    public void RunFinished(ITest test) {
      lock(this) {
        fActiveTestDeathCount++;
        Monitor.PulseAll(this);
      }
    }
  }
}
