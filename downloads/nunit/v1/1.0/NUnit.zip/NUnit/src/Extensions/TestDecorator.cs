namespace NUnit.Extensions {

  using System;

  using NUnit.Framework;

  /// <summary>A Decorator for Tests.</summary>
  /// <remarks>Use TestDecorator as the base class
  /// for defining new test decorators. TestDecorator subclasses
  /// can be introduced to add behaviour before or after a test
  /// is run.</remarks>
  public class TestDecorator: Assertion, ITest {
    protected readonly ITest fTest;
    
    public TestDecorator(ITest test) {
      fTest= test;
    }
    
    /// <summary>The basic run behaviour.</summary>
    public void BasicRun(TestResult result) {
      fTest.Run(result);
    }
    public virtual int CountTestCases {
      get { return fTest.CountTestCases; }
    }
    protected ITest GetTest {
      get { return fTest; }
    }
    public virtual void Run(TestResult result) {
      BasicRun(result);
    }
    public override String ToString() {
      return fTest.ToString();
    }
  }
}
