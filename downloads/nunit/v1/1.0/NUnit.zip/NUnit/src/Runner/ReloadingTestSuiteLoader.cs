namespace NUnit.Runner {

  using System;

  /// <summary>A TestSuite loader that can reload classes.</summary>
  public class ReloadingTestSuiteLoader: ITestSuiteLoader {
    public Type Load(String suiteClassName) {
      //            TestCaseClassLoader loader= new TestCaseClassLoader();
      //            return loader.LoadClass(suiteClassName, true);
      throw new System.Exception("Reloading not implemented");
      //            return typeof(ReloadingTestSuiteLoader);
    }
    public Type Reload(Type aClass) {
      //            TestCaseClassLoader loader= new TestCaseClassLoader();
      //            return loader.LoadClass(aClass.ToString(), true);
      throw new System.Exception("Reloading not implemented");
      //            return typeof(ReloadingTestSuiteLoader);
    }
  }
}
