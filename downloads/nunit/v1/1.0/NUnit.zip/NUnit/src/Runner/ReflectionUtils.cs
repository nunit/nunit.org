namespace NUnit.Runner {

  using System;
  using System.Collections;
  using System.IO;
  using System.Reflection;

  public class ReflectionUtils{
    public static StringCollection GetAssemblyClasses(String assemblyName){
      StringCollection classNames = new StringCollection ();
      try {
        Assembly testAssembly = Assembly.LoadFrom(assemblyName);

        foreach(Type testType in testAssembly.GetExportedTypes()){
          if(testType.IsClass && (testType.GetProperty("Suite")!=null)){
            classNames.Add(testType.FullName);
          }
        }
      }catch(ReflectionTypeLoadException rcle){

        Type[] loadedTypes     = rcle.Types;
        Exception[] exceptions = rcle.LoaderExceptions;

        int exceptionCount = 0;

        for ( int i =0; i < loadedTypes.Length; i++ ){
          Console.Error.WriteLine("Unable to load a type because {0}", exceptions[exceptionCount] );
          exceptionCount++;        
        }
      }catch(FileNotFoundException fnfe){
        Console.Error.WriteLine(fnfe.Message);
      }catch(Exception){
        Console.Error.WriteLine("Error reading file{0}", assemblyName);
      }
      return classNames;
    }
  }
}
