namespace NUnit.Runner {

  using System;
  using System.Reflection;

  /// <summary>The standard test suite loader. It can only load the same
  /// class once.</summary>
  public class StandardTestSuiteLoader: ITestSuiteLoader {

    public Type Load(String suiteClassName) {
      return Type.GetType(suiteClassName, true);
    }
 
    public Type Reload(Type aClass) {
      return aClass;
    }
  }
}
