namespace NUnit.Runner {

  /**
   * This class defines the current version of NUnit
   */
  public class Version {
    private Version() {
      // don't instantiate
    }
    
    public static string id() {
      return "1.7";
    }
  }
}
