namespace NUnit.Runner {

  using System;

  /// <summary>An interface to define how a test suite should be
  /// loaded.</summary>
  public interface ITestSuiteLoader {
    Type Load(String suiteClassName);
    Type Reload(Type aType);
  }
}
