namespace NUnit.Runner {

  using System;
  using System.Collections;
  using System.IO;
  using System.IO.IsolatedStorage;
  using System.Reflection;

  using NUnit.Framework;

  /// <summary>Base class for all test runners.</summary>
  /// <remarks>This class was born live on stage in Sardinia during
  /// XP2000.</remarks>
  public abstract class BaseTestRunner: ITestListener {
    static String SUITE_PROPERTYNAME="Suite";
    static NameValueCollection fPreferences;

    protected ITestSuiteLoader fTestLoader;

    public BaseTestRunner() {
      fPreferences = new NameValueCollection();
      fPreferences.Add("loading", "true");
      ReadPreferences();
    }
    public abstract void AddError(ITest test, Exception t);
    public abstract void AddFailure(ITest test, AssertionFailedError t);
    protected virtual void ClearStatus() { // Belongs in the GUI class.
    }
    public abstract void EndTest(ITest test);
    public static String ElapsedTimeAsString(long runTime) {
      return ((double)runTime/1000).ToString();
    }
    public static String ExtractClassName(String className) {
      if(className.StartsWith("Default package for")) 
        return className.Substring(className.LastIndexOf(".")+1);
      return className;
    }
    private static String GetPreference(String key) {
      return fPreferences.Get(key);
    }
    private static FileStream GetPreferencesFile() {
      return new IsolatedStorageFileStream("NUnit.Prefs",
                                           FileMode.OpenOrCreate);
     }
    public ITest GetTest(String suiteClassName) {
      if (suiteClassName.Length <= 0) {
        ClearStatus();
        return null;
      }
      Type testClass= null;
      try {
        testClass = LoadSuiteClass(suiteClassName);
      } catch (TypeLoadException) {
        RunFailed("Type definition \"" + suiteClassName + "\" not found");
        return null;
      } catch (Exception) {
        RunFailed("Type \"" + suiteClassName + "\" not found");
        return null;
      }
      PropertyInfo suiteProperty= null;
      suiteProperty = testClass.GetProperty(SUITE_PROPERTYNAME, new Type[0]);
      if (suiteProperty == null ) {
        // try to extract a test suite automatically
        ClearStatus();
        return new TestSuite(testClass);
      }
      ITest test= null;
      try {
        // static property
        test= (ITest)suiteProperty.GetValue(null, new Type[0]); 
        if (test == null)
          return test;
      } catch(Exception e) {
        RunFailed("Could not get the Suite property. " + e);
        return null;
      }
      ClearStatus();
      return test;  
    }
    public static bool InVAJava() {
      return false;
    }
    protected Type LoadSuiteClass(String suiteClassName) {
      return fTestLoader.Load(suiteClassName);
    }
    private static void ReadPreferences() {
      FileStream fs= null;
      try {
        fs= GetPreferencesFile();
        fPreferences= new NameValueCollection(fPreferences);
        ReadPrefsFromFile(fPreferences, fs);
      } catch (IOException) {
        try {
          if (fs != null)
            fs.Close();
        } catch (IOException) {
        }
      }
     }
    private static void ReadPrefsFromFile(NameValueCollection prefs,
                                          FileStream fs) {
      // Real method reads name/value pairs, populates, or maybe just
      // deserializes...
    }
    protected abstract void RunFailed(String message);
    public static String Truncate(String s) {
        if (s.Length > 200)
            s= s.Substring(0, 200)+"...";
        return s;
    }
    public abstract void StartTest(ITest test);
  }
}
