namespace NUnit.GUI 
{
  using System;
  using System.ComponentModel;
  using System.ComponentModel.Design;
  using System.Drawing;
  using System.Drawing.Drawing2D;
  using System.Drawing.Design;
  using System.WinForms;
  using System.Diagnostics;

  public class ProgressBar : RichControl 
  {
    private const int LeftRightBorder = 10;
    private int value = 0;
    private int min = 0;
    private int max = 100;
    private Color startColor = Color.Lime;
    private Color endColor = Color.Red;
    private Brush backgroundDim = null;
    private Brush baseBackground = null;
    private bool changeBrush = true;
    private bool fError = false;

    public ProgressBar() 
    {
      SetStyle(ControlStyles.Opaque, true);
      SetStyle(ControlStyles.ResizeRedraw, true);
    }

    public int Minimum
    {
      get
      { return min; }
      set
      { min = value; }
    }

    public int Maximum 
    {
      get 
      { return max; }
      set 
      {
        if (max != value) 
        {
          max = value;
          Refresh();
        }
      }
    }

    public Color StatusColor
    {
      get 
      {
        if(fError)
          return Color.Red;
        return Color.Lime;
      }
    }

    public bool Error
    {
      get { return fError; }
      set
      {
        if(fError != value)
        {
          fError = value;
          changeBrush = true;
        }
      }
    }

    public int Value 
    {
      get { return value; }
      set 
      {
        this.value = value;
        Refresh();
      }
    }

    public void Step()
    {
      int old = Value;
      Value = ++old;
    }

    protected override void OnPaint(PaintEventArgs e) 
    {
      base.OnPaint(e);

      if(changeBrush)
      {
        changeBrush = false;
        baseBackground = new SolidBrush(StatusColor);
        backgroundDim = new SolidBrush(BackColor);
      }

      Rectangle r = Rectangle.Inflate(ClientRectangle, -2, -2);
      Rectangle toDim = r;
      float percentValue = ((float)Value / ((float)Maximum - (float)Minimum));
      int nonDimLength = (int)(percentValue * (float)toDim.Width);
      toDim.X += nonDimLength;
      toDim.Width -= nonDimLength;

      ControlPaint.DrawBorder3D(e.Graphics, ClientRectangle);
      e.Graphics.FillRectangle(baseBackground, r);
      e.Graphics.FillRectangle(backgroundDim, toDim);
      e.Graphics.Flush();
    }
  }
}
