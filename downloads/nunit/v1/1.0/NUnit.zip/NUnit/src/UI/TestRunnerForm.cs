namespace NUnit.GUI{
    	
  using System;
  using System.WinForms;
  using System.Drawing;
  using System.Collections;
  using System.ComponentModel;
  using System.IO;
  using System.Reflection;
    	
  using NUnit.Framework;
  using NUnit.Runner;
        
  /// <summary>
  ///    Summary description for TestRunnerForm.
  /// </summary>
  public class TestRunnerForm : System.WinForms.Form,
    ITestListener, ITestRunner {
    /// <summary> 
    ///    Required by the Win Forms designer 
    /// </summary>
    private System.ComponentModel.Container components;
    private System.WinForms.MainMenu mainMenu1;
    private System.WinForms.StatusBarPanel statusMain;
    	
    private System.WinForms.StatusBarPanel statusTestCount;
    private System.WinForms.StatusBarPanel statusTime;
    private System.WinForms.StatusBarPanel statusRunCount;
    private System.WinForms.StatusBarPanel statusFailCount;
    private System.WinForms.StatusBarPanel statusErrorCount;
    private System.WinForms.TextBox StdErrText;
    private System.WinForms.TextBox StdOutText;
    private System.WinForms.ListBox TestErrorsText;
    private System.WinForms.OpenFileDialog FindModuleDialog;
    private System.WinForms.Button BrowseAssemblyButton;
    private System.WinForms.ComboBox TypeNameSelector;
    private System.WinForms.Label typeNameLabel;
    private System.WinForms.Label assemblyNameLabel;
    private System.WinForms.TabPage TestErrorsTabPage;
    private System.WinForms.TabPage StdOutTabPage;
    private System.WinForms.TabPage StdErrTabPage;
    private System.WinForms.TabControl OutputTab;
    private NUnit.GUI.ProgressBar runTestProgressBar;
    private System.WinForms.StatusBar statusBar;
    private System.WinForms.Button RunButton;
    private System.WinForms.TextBox AssemblyNameText;
    private System.WinForms.Panel panel1;
    private System.WinForms.MainMenu mainMenu;
    private System.WinForms.MenuItem testBrowserItem;
    
    private TestResult result;
    private AboutBox aboutBox = null;
    private ShowTests testBrowser = null;
    public String initialTestToRun = "";
    
    public TestRunnerForm() {
      // Required for Win Form Designer support
      InitializeComponent();
    
      MenuSetup();
      ClearStatus();
      Console.SetError(new TextBoxWriter(StdErrText));
      Console.SetOut(new TextBoxWriter(StdOutText));
    }
    
    protected override void OnActivated(EventArgs e) {
      if (initialTestToRun != "") {
        int comma = initialTestToRun.IndexOf(',');
        AssemblyNameText.Text = initialTestToRun.Substring(comma+1);
        TypeNameSelector.Text = initialTestToRun.Substring(0, comma);
    
        RunTest(initialTestToRun);
        initialTestToRun = "";
      }
    }
    
    private void MenuSetup()
    {
      MenuItem nunit = mainMenu.MenuItems.Add("&NUnit");
      MenuItem aboutItem = new MenuItem("&About...",
                                        new EventHandler(ShowAbout),
                                        Shortcut.CtrlA);
      aboutItem.Enabled = true;
      nunit.MenuItems.Add(aboutItem);
      testBrowserItem = new MenuItem("&Show Test Browser",
                                     new EventHandler(ShowTestBrowser),
                                     Shortcut.CtrlS);
      testBrowserItem.Enabled = false;
      nunit.MenuItems.Add(testBrowserItem);
      nunit.MenuItems.Add("-");
      nunit.MenuItems.Add(new MenuItem("&Exit", 
                                       new EventHandler(ExitClicked),
                                       Shortcut.CtrlX));
    }
    
    private void ExitClicked(object sender, System.EventArgs e) 
    { Close(); }
    
    private void ShowAbout(object sender, System.EventArgs e) {
      aboutBox = new AboutBox();
      aboutBox.ShowDialog(this);
    }
    
    private void ShowTestBrowser(object sender, System.EventArgs e)
    {
      testBrowser = new ShowTests(GetSuite(SuiteName), this); 
      testBrowser.ShowDialog(this);
    }
    
    /// <summary>
    ///    Clean up any resources being used
    /// </summary>
    public override void Dispose() {
      base.Dispose();
      components.Dispose();
    }
    
    
    //void ITestListener.AddError(ITest test, Exception e){
    public void AddError(ITest test, Exception e){
      runTestProgressBar.Error = true;
      ListCell cell = new ListCell(test, e);
      TestErrorsText.InsertItem(TestErrorsText.Items.Count, cell);
    }
    
    //void ITestListener.AddFailure(ITest test, Exception e){
    public void AddFailure(ITest test, AssertionFailedError e){
      runTestProgressBar.Error = true;
      ListCell cell = new ListCell(test, e);
      TestErrorsText.InsertItem(TestErrorsText.Items.Count, cell);
    }

    
    //void ITestListener.StartTest(ITest test){
    public void StartTest(ITest test){
      statusMain.Text = "Running test: " + test.ToString();
      Cursor = Cursors.WaitCursor;
    }
    
    //void ITestListener.EndTest(ITest test){
    public void EndTest(ITest test){
      runTestProgressBar.Step();
      Cursor = Cursors.Default;
      DisplaySummary();
    }
    
    /// <summary>
    ///    Resets the screen components to initial values
    /// </summary>
    protected void ClearStatus(){
      runTestProgressBar.Value= 0;
      runTestProgressBar.Error= false;
      StdErrText.Clear();
      StdOutText.Clear();
      TestErrorsText.Items.All = new object[] {}; 	
    
      statusMain.Text = "Ready";
      statusRunCount.Text = "Run";
      statusErrorCount.Text = "Error";
      statusFailCount.Text = "Fail";
      statusTime.Text = "Time";
      statusTestCount.Text = "Tests";
      TestErrorsTabPage.Text = "Errors and Failures";
    }
    /// <summary>
    ///    Runs actual test
    /// </summary>
    protected void RunTest(String name)
    {
      try
      { Run(GetSuite(name)); }
      catch(Exception ex)
      { 
        ClearStatus();
        Console.Error.WriteLine(ex.ToString()); 
      }
    } 
    
    public void Run(ITest suite)
    {
      ClearStatus();
      System.DateTime startTime = System.DateTime.Now;
      runTestProgressBar.Maximum = suite.CountTestCases;
      result = new TestResult();
    
      if(testBrowser != null && testBrowser.Visible)
        result.AddListener(testBrowser);
      result.AddListener(this);
      suite.Run(result);
      System.DateTime endTime = System.DateTime.Now;
      statusTestCount.Text="Tests:"+suite.CountTestCases.ToString();
      statusTime.Text="Time:"+(endTime-startTime).ToString();
      statusMain.Text = "Finished";
      DisplaySummary();
    }
    		
    		
    
    private void DisplaySummary(){
      statusRunCount.Text="Run:"+result.RunCount.ToString();
      statusFailCount.Text="Failed:"+result.FailureCount.ToString();
      statusErrorCount.Text="Errors:"+result.ErrorCount.ToString();
      String eandf = "Errors (" + result.ErrorCount.ToString() + 
        ") and Failures (" + result.FailureCount.ToString() + ")";
      TestErrorsTabPage.Text = eandf; 
    }
    
    		
    public static ITest GetSuite(String className){
      ITest test = null;
      try{
        Type testClass = Type.GetType(className, true);
        PropertyInfo suiteProperty= testClass.GetProperty("Suite",
                                                          new Type[0]);
        test = (ITest)suiteProperty.GetValue(null, new Type[0]);
      } catch (Exception ex){
        Console.Error.WriteLine(ex.ToString(),"Error");
      }
      return test;
    }
    
    		
    protected void RunButton_Click(object sender, System.EventArgs e){
      RunTest(SuiteName);
    }
    
    private String SuiteName
    {
      get 
      {
        String className = TypeNameSelector.Text;
        String modName = AssemblyNameText.Text;
        return className + "," + modName;
      }
    }
    
    protected void TypeName_Click(object sender, System.EventArgs e) {
      ClearStatus();
    }
    
    protected void BrowseAssemblyButton_Click(object sender,
                                              System.EventArgs e) {
      FindModuleDialog.FileName=AssemblyNameText.Text;
      if(FindModuleDialog.ShowDialog()==DialogResult.OK){
        AssemblyNameText.Text=FindModuleDialog.FileName;
      }
    }
    
    protected void AssemblyNameText_TextChanged(object sender, EventArgs e) {
      bool flag=false;
      TypeNameSelector.Items.Clear();
      if(AssemblyNameText.Text.Length>0){
        if(File.FileExists(AssemblyNameText.Text)){
          foreach(String s in ReflectionUtils.GetAssemblyClasses(
                                                                 AssemblyNameText.Text)) {
            TypeNameSelector.Items.Add(s);
          }
          if (TypeNameSelector.Items.Count > 0)
          {
            TypeNameSelector.Text = TypeNameSelector.Items[0].ToString();
            flag=true;
          }
        }
      }
      TypeNameSelector.Enabled=flag;
      typeNameLabel.Enabled = flag;
      testBrowserItem.Enabled = flag;
    
      RunButton.Enabled=flag;
      ClearStatus();
    }
        
    protected void SelectAndOpenDetail(object sender, System.EventArgs e)
    {
      ListCell cell = (ListCell)TestErrorsText.SelectedItem;
      ShowDetail detail = new ShowDetail(cell.Exception);
      detail.ShowDialog(this);
    }
    		
    public class TextBoxWriter: TextWriter{
      TextBoxBase fTextBox;
      private TextBoxWriter(){}
    			
      public TextBoxWriter(TextBoxBase textBox){
        fTextBox=textBox;
      }
    			
      public override void Write(char c){
        fTextBox.AppendText(c.ToString());
      }
      public override void Write(String s){
        fTextBox.AppendText(s);
      }
    }
    
    private class ListCell
    {
      private ITest test;
      private Exception exception;
    
      public ListCell(ITest test, Exception exception)
      {
        this.test = test;
        this.exception = exception;
      }
    
      public override String ToString()
      {
        String cell = test.ToString();
        String message = exception.Message;
        if(message != null)
          return cell + " : " + message;
    
        return cell;
      }
    
      public Exception Exception
      {
        get { return exception; }
      }
    }
    
    
    /// <summary>
    ///    Required method for Designer support - do not modify
    ///    the contents of this method with an editor
    /// </summary>
    private void InitializeComponent()
    {
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(TestRunnerForm));
		
      this.components = new System.ComponentModel.Container();
      this.mainMenu1 = new System.WinForms.MainMenu();
      this.OutputTab = new System.WinForms.TabControl();
      this.statusTime = new System.WinForms.StatusBarPanel();
      this.TestErrorsText = new System.WinForms.ListBox();
      this.StdErrText = new System.WinForms.TextBox();
      this.mainMenu = new System.WinForms.MainMenu();
      this.assemblyNameLabel = new System.WinForms.Label();
      this.statusMain = new System.WinForms.StatusBarPanel();
      this.RunButton = new System.WinForms.Button();
      this.BrowseAssemblyButton = new System.WinForms.Button();
      this.statusFailCount = new System.WinForms.StatusBarPanel();
      this.AssemblyNameText = new System.WinForms.TextBox();
      this.statusErrorCount = new System.WinForms.StatusBarPanel();
      this.runTestProgressBar = new NUnit.GUI.ProgressBar();
      this.StdOutText = new System.WinForms.TextBox();
      this.statusTestCount = new System.WinForms.StatusBarPanel();
      this.statusBar = new System.WinForms.StatusBar();
      this.TypeNameSelector = new System.WinForms.ComboBox();
      this.panel1 = new System.WinForms.Panel();
      this.FindModuleDialog = new System.WinForms.OpenFileDialog();
      this.StdOutTabPage = new System.WinForms.TabPage();
      this.StdErrTabPage = new System.WinForms.TabPage();
      this.TestErrorsTabPage = new System.WinForms.TabPage();
      this.typeNameLabel = new System.WinForms.Label();
      this.statusRunCount = new System.WinForms.StatusBarPanel();
		
      statusTime.BeginInit();
      statusMain.BeginInit();
      statusFailCount.BeginInit();
      statusErrorCount.BeginInit();
      statusTestCount.BeginInit();
      statusRunCount.BeginInit();
		
      //@design this.TrayHeight = 93;
      //@design this.TrayLargeIcon = true;
      //@design this.TrayAutoArrange = true;
      //@design mainMenu1.SetLocation(new System.Drawing.Point(7, 35));
		
      OutputTab.Location = new System.Drawing.Point(0, 104);
      OutputTab.Size = new System.Drawing.Size(584, 361);
      OutputTab.SelectedIndex = 0;
      OutputTab.TabIndex = 4;
      OutputTab.Anchor = System.WinForms.AnchorStyles.Left;
		
      //@design statusTime.SetLocation(new System.Drawing.Point(7, -30));
      statusTime.ToolTipText = "Elapsed time since suite started";
      statusTime.Width = 10;
      statusTime.AutoSize = System.WinForms.StatusBarPanelAutoSize.Contents;
		
      TestErrorsText.Size = new System.Drawing.Size(576, 329);
      TestErrorsText.ScrollAlwaysVisible = true;
      TestErrorsText.Dock = System.WinForms.DockStyle.Fill;
      TestErrorsText.TabIndex = 0;
      TestErrorsText.DoubleClick += new System.EventHandler(SelectAndOpenDetail);
		
      StdErrText.ReadOnly = true;
      StdErrText.Multiline = true;
      StdErrText.ScrollBars = System.WinForms.ScrollBars.Vertical;
      StdErrText.Dock = System.WinForms.DockStyle.Fill;
      StdErrText.TabIndex = 0;
      StdErrText.Size = new System.Drawing.Size(576, 459);
		
      //@design mainMenu.SetLocation(new System.Drawing.Point(289, -30));
		
      assemblyNameLabel.Location = new System.Drawing.Point(8, 8);
      assemblyNameLabel.Text = "Assembly Name";
      assemblyNameLabel.Size = new System.Drawing.Size(104, 24);
      assemblyNameLabel.TabIndex = 0;
		
      //@design statusMain.SetLocation(new System.Drawing.Point(331, -95));
      statusMain.Width = 518;
      statusMain.AutoSize = System.WinForms.StatusBarPanelAutoSize.Spring;
		
      RunButton.Location = new System.Drawing.Point(504, 72);
      RunButton.Size = new System.Drawing.Size(64, 24);
      RunButton.TabIndex = 4;
      RunButton.Anchor = System.WinForms.AnchorStyles.TopRight;
      RunButton.Enabled = false;
      RunButton.Text = "&Run";
      RunButton.Click += new System.EventHandler(RunButton_Click);
		
      BrowseAssemblyButton.Location = new System.Drawing.Point(504, 8);
      BrowseAssemblyButton.Size = new System.Drawing.Size(64, 24);
      BrowseAssemblyButton.TabIndex = 2;
      BrowseAssemblyButton.Anchor = System.WinForms.AnchorStyles.TopRight;
      BrowseAssemblyButton.Text = "&Browse...";
      BrowseAssemblyButton.Click += new System.EventHandler(BrowseAssemblyButton_Click);
		
      //@design statusFailCount.SetLocation(new System.Drawing.Point(85, -30));
      statusFailCount.ToolTipText = "Number of failures encountered";
      statusFailCount.Width = 10;
      statusFailCount.AutoSize = System.WinForms.StatusBarPanelAutoSize.Contents;
		
      AssemblyNameText.Location = new System.Drawing.Point(112, 10);
      AssemblyNameText.TabIndex = 1;
      AssemblyNameText.Anchor = System.WinForms.AnchorStyles.TopLeftRight;
      AssemblyNameText.Size = new System.Drawing.Size(384, 20);
      AssemblyNameText.TextChanged += new System.EventHandler(AssemblyNameText_TextChanged);
		
      //@design statusErrorCount.SetLocation(new System.Drawing.Point(120, -95));
      statusErrorCount.ToolTipText = "Number of errors encountered";
      statusErrorCount.Width = 10;
      statusErrorCount.AutoSize = System.WinForms.StatusBarPanelAutoSize.Contents;
		
      runTestProgressBar.BackColor = System.Drawing.SystemColors.Control;
      runTestProgressBar.Maximum = 100;
      runTestProgressBar.Minimum = 0;
      runTestProgressBar.TabIndex = 1;
      runTestProgressBar.Anchor = System.WinForms.AnchorStyles.TopLeftRight;
      runTestProgressBar.Location = new System.Drawing.Point(0, 72);
      runTestProgressBar.Enabled = false;
      runTestProgressBar.Value = 0;
      runTestProgressBar.Size = new System.Drawing.Size(496, 24);
      runTestProgressBar.Error = false;
      runTestProgressBar.Text = "runTestProgressBar";
		
      StdOutText.ReadOnly = true;
      StdOutText.Multiline = true;
      StdOutText.ScrollBars = System.WinForms.ScrollBars.Both;
      StdOutText.Dock = System.WinForms.DockStyle.Fill;
      StdOutText.TabIndex = 0;
      StdOutText.Size = new System.Drawing.Size(576, 459);
		
      //@design statusTestCount.SetLocation(new System.Drawing.Point(227, -95));
      statusTestCount.ToolTipText = "Number of tests in suite";
      statusTestCount.Width = 10;
      statusTestCount.AutoSize = System.WinForms.StatusBarPanelAutoSize.Contents;
		
      statusBar.BackColor = System.Drawing.SystemColors.Control;
      statusBar.Location = new System.Drawing.Point(0, 465);
      statusBar.Size = new System.Drawing.Size(584, 20);
      statusBar.TabIndex = 0;
      statusBar.ShowPanels = true;
      statusBar.Panels.All = new System.WinForms.StatusBarPanel[] {statusMain,
                                                                   statusTestCount,
                                                                   statusRunCount,
                                                                   statusErrorCount,
                                                                   statusFailCount,
                                                                   statusTime};
		
      TypeNameSelector.Location = new System.Drawing.Point(112, 40);
      TypeNameSelector.Size = new System.Drawing.Size(456, 21);
      TypeNameSelector.Enabled = false;
      TypeNameSelector.TabIndex = 3;
      TypeNameSelector.Anchor = System.WinForms.AnchorStyles.TopLeftRight;
      TypeNameSelector.SelectedIndexChanged += new System.EventHandler(TypeName_Click);
		
      panel1.Dock = System.WinForms.DockStyle.Top;
      panel1.Size = new System.Drawing.Size(584, 104);
      panel1.TabIndex = 0;
      panel1.Text = "panel1";
		
      //@design FindModuleDialog.SetLocation(new System.Drawing.Point(7, -95));
      FindModuleDialog.Filter = "Dll\'s|*.dll|Executables|*.exe|All Files|*.*";
      FindModuleDialog.Title = "Select Assembly";
      FindModuleDialog.ReadOnlyChecked = true;
		
      StdOutTabPage.Text = "Standard Output";
      StdOutTabPage.Size = new System.Drawing.Size(576, 459);
      StdOutTabPage.TabIndex = 3;
		
      StdErrTabPage.Text = "Standard Error";
      StdErrTabPage.Size = new System.Drawing.Size(576, 459);
      StdErrTabPage.TabIndex = 2;
		
      TestErrorsTabPage.Text = "Errors and Failures";
      TestErrorsTabPage.Size = new System.Drawing.Size(576, 335);
      TestErrorsTabPage.TabIndex = 0;
		
      typeNameLabel.Location = new System.Drawing.Point(8, 40);
      typeNameLabel.Text = "Type Name";
      typeNameLabel.Size = new System.Drawing.Size(104, 24);
      typeNameLabel.Enabled = false;
      typeNameLabel.TabIndex = 0;
		
      //@design statusRunCount.SetLocation(new System.Drawing.Point(186, -30));
      statusRunCount.ToolTipText = "Number of tests completed";
      statusRunCount.Width = 10;
      statusRunCount.AutoSize = System.WinForms.StatusBarPanelAutoSize.Contents;
      this.Text = "Run Test Suite";
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.Icon = (System.Drawing.Icon)resources.GetObject("$this.Icon");
      this.AcceptButton = RunButton;
      this.Menu = mainMenu;
      this.ClientSize = new System.Drawing.Size(584, 485);
		
      panel1.Controls.Add(BrowseAssemblyButton);
      panel1.Controls.Add(TypeNameSelector);
      panel1.Controls.Add(assemblyNameLabel);
      panel1.Controls.Add(RunButton);
      panel1.Controls.Add(AssemblyNameText);
      panel1.Controls.Add(runTestProgressBar);
      panel1.Controls.Add(typeNameLabel);
      TestErrorsTabPage.Controls.Add(TestErrorsText);
      StdOutTabPage.Controls.Add(StdOutText);
      StdErrTabPage.Controls.Add(StdErrText);
      OutputTab.Controls.Add(TestErrorsTabPage);
      OutputTab.Controls.Add(StdErrTabPage);
      OutputTab.Controls.Add(StdOutTabPage);
      this.Controls.Add(OutputTab);
      this.Controls.Add(statusBar);
      this.Controls.Add(panel1);
		
      statusTime.EndInit();
      statusMain.EndInit();
      statusFailCount.EndInit();
      statusErrorCount.EndInit();
      statusTestCount.EndInit();
      statusRunCount.EndInit();
    }
  }
}
