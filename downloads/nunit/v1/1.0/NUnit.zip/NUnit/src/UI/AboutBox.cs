// AboutBox.cs
namespace NUnit.GUI {
    
  using System;
  using System.Diagnostics;
  using System.Drawing;
  using System.ComponentModel;
  using System.WinForms;

  /// <summary>
  ///    Summary description for AboutBox.
  /// </summary>
  public class AboutBox : System.WinForms.Form {

    /// <summary> 
    ///    Required by the Win Forms designer 
    /// </summary>
    private System.ComponentModel.Container components;
    private System.WinForms.Label label3;
    private System.WinForms.Button OK;
	
    private System.WinForms.Label label4;
    private System.WinForms.Label Version;
    private System.WinForms.Label label2;
    private System.WinForms.Label label1;
    private System.Resources.ResourceManager resources;
        
    public AboutBox() {

      // Required for Win Form Designer support
      InitializeComponent();
      this.Icon = (Icon)resources.GetObject("$this.Icon");

      Version.Text = "Version " + NUnit.Runner.Version.id();
      // TODO: Add any constructor code after InitializeComponent call

    }

    /// <summary>
    ///    Clean up any resources being used
    /// </summary>
    public override void Dispose() {
      base.Dispose();
      components.Dispose();
    }


    /// <summary>
    ///    Required method for Designer support - do not modify
    ///    the contents of this method with an editor
    /// </summary>
    private void InitializeComponent()
    {
      resources = new System.Resources.ResourceManager(typeof(TestRunnerForm));
      //		new System.Resources.ResourceManager("ShowTests", 
      //									 typeof(NUnit.GUI.ShowTests),
      //									 null, true);
      this.components = new System.ComponentModel.Container();
      this.label1 = new System.WinForms.Label();
      this.label2 = new System.WinForms.Label();
      this.Version = new System.WinForms.Label();
      this.label3 = new System.WinForms.Label();
      this.OK = new System.WinForms.Button();
      this.label4 = new System.WinForms.Label();
		
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.Text = "About NUnit";
      //@design this.TrayLargeIcon = true;
      //@design this.TrayHeight = 0;
      this.ClientSize = new System.Drawing.Size(424, 149);
		
      label1.Location = new System.Drawing.Point(40, 24);
      label1.Text = "NUnit - XUnit testing framework for .Net";
      label1.Size = new System.Drawing.Size(448, 16);
      label1.TabIndex = 0;
      label1.BackColor = System.Drawing.Color.Transparent;
		
      label2.Location = new System.Drawing.Point(40, 40);
      label2.Text = "Copyright � Philip Craig 2000";
      label2.Size = new System.Drawing.Size(448, 16);
      label2.TabIndex = 1;
      label2.BackColor = System.Drawing.Color.Transparent;
		
      Version.Location = new System.Drawing.Point(40, 120);
      Version.Text = "Version unknown";
      Version.Size = new System.Drawing.Size(104, 16);
      Version.TabIndex = 2;
		
      label3.Location = new System.Drawing.Point(40, 88);
      label3.Text = "http://nunit.sourceforge.net/";
      label3.Size = new System.Drawing.Size(168, 16);
      label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 11f, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.World);
      label3.TabIndex = 6;
      label3.BackColor = System.Drawing.Color.Transparent;
      label3.Click += new System.EventHandler(httpClick);
		
      OK.Location = new System.Drawing.Point(256, 96);
      OK.Size = new System.Drawing.Size(88, 24);
      OK.TabIndex = 5;
      OK.Text = "OK";
      OK.Click += new System.EventHandler(OK_Click);
		
      label4.Location = new System.Drawing.Point(40, 56);
      label4.Text = "Thanks to Jim Newkirk, Ethan Smith, Kent Beck and Erich Gamm" + 
        "a";
      label4.Size = new System.Drawing.Size(448, 16);
      label4.TabIndex = 3;
      label4.BackColor = System.Drawing.Color.Transparent;
		
      this.Controls.Add(label3);
      this.Controls.Add(OK);
      this.Controls.Add(label4);
      this.Controls.Add(Version);
      this.Controls.Add(label2);
      this.Controls.Add(label1);
		
    }
    protected void httpClick(object sender, System.EventArgs e)
    {
      Process.Start("http://nunit.sourceforge.net/");
    }
    protected void OK_Click(object sender, System.EventArgs e)
    {
      Close();
    }

  }
}
