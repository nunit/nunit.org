namespace NUnit.GUI {
  using System;
  using System.Reflection;
  using System.Drawing;
  using System.ComponentModel;
  using System.WinForms;
  using System.Collections;

  using NUnit.Framework;

  /// <summary>
  ///    Summary description for Win32Form1.
  /// </summary>
  public class ShowTests : System.WinForms.Form, ITestListener {

    /// <summary> 
    ///    Required by the Win Forms designer 
    /// </summary>
    private System.ComponentModel.Container components;
    private System.WinForms.Button runButton;
    private System.WinForms.Button closeButton;
    private System.WinForms.Button collapseButton;
    private System.WinForms.ImageList imageList;
    private System.WinForms.TreeView testBrowser;
    private System.WinForms.Panel buttonPanel;
    private System.WinForms.Panel testPanel;
    private bool testFailure;

    private Hashtable testNameAssociation = new Hashtable();
    private Hashtable nodeTestAssociation = new Hashtable();
    private ArrayList changedNodes = new ArrayList();
    private ITestRunner runner;

    private enum Icons
    { ClosedFolder= 0, OpenFolder= 1, Ok= 2, Error= 3, Failure= 4 }
        
    public ShowTests(ITest root, ITestRunner testRunner)
    {
      runner = testRunner;

      // Required for Win Form Designer support
      InitializeComponent();

      testNameAssociation.Add(root.ToString(), root);
      TreeNode node = new TreeNode(root.ToString(), GetTestNodes(root));
      nodeTestAssociation.Add(root, node);

      TreeNode[] allNodes = new TreeNode[] 
      { node };

      testBrowser.Nodes.All = allNodes; 
    }

    private TreeNode[] GetTestNodes(ITest maybeSuite)
    {
      TreeNode[] testNodes = null;
      ArrayList tests = null;

      if(maybeSuite is TestSuite)
      {
        TestSuite suite = (TestSuite)maybeSuite;
        tests = suite.Tests;
        testNodes = new TreeNode[tests.Count]; 
      }

      int i = 0;
      foreach(ITest test in tests)
      {
        TreeNode testNode;
        if(test is TestSuite)
          testNode = new TreeNode(test.ToString(), GetTestNodes(test));
        else
          testNode = new TreeNode(test.ToString());

        nodeTestAssociation.Add(test, testNode);
        testNameAssociation.Add(test.ToString(), test);
        testNodes[i++] = testNode;
      }

      return testNodes;
    }

    /// <summary>
    ///    Clean up any resources being used
    /// </summary>
    public override void Dispose() {
      base.Dispose();
      components.Dispose();
    }


    /// <summary>
    ///    Required method for Designer support - do not modify
    ///    the contents of this method with an editor
    /// </summary>
    private void InitializeComponent()
    {
      System.Resources.ResourceManager resources =
        new System.Resources.ResourceManager(typeof(ShowTests));
      this.Icon = (Icon)resources.GetObject("LogoIcon");
      this.components = new System.ComponentModel.Container();
      this.collapseButton = new System.WinForms.Button();
      this.testPanel = new System.WinForms.Panel();
      this.imageList = new System.WinForms.ImageList();
      this.testBrowser = new System.WinForms.TreeView();
      this.buttonPanel = new System.WinForms.Panel();
      this.runButton = new System.WinForms.Button();
      this.closeButton = new System.WinForms.Button();
		
      collapseButton.Location = new System.Drawing.Point(76, 12);
      collapseButton.Size = new System.Drawing.Size(80, 24);
      collapseButton.TabIndex = 1;
      collapseButton.Text = "Collapse All";
      collapseButton.Click += new System.EventHandler(CollapseButtonClicked);
		
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.Text = "Test Browser";
      //@design this.TrayLargeIcon = true;
      this.AcceptButton = closeButton;
      //@design this.TrayHeight = 93;
      this.ClientSize = new System.Drawing.Size(450, 254);
		
      testPanel.Dock = System.WinForms.DockStyle.Fill;
      testPanel.Size = new System.Drawing.Size(450, 206);
      testPanel.TabIndex = 1;
      testPanel.Text = "test browser";

      //@design imageList1.SetLocation(new System.Drawing.Point(7, 7));
      imageList.ImageSize = new System.Drawing.Size(16, 16);
      imageList.ImageStream =
        (System.WinForms.ImageListStreamer)
        resources.GetObject("imageList.ImageStream");
      imageList.ColorDepth = System.WinForms.ColorDepth.Depth8Bit;
      imageList.TransparentColor = System.Drawing.Color.Transparent;
	
      testBrowser.ImageList = imageList;
      testBrowser.SelectedImageIndex = (int)Icons.OpenFolder;
      testBrowser.HideSelection = false;
      testBrowser.HotTracking = false;
      testBrowser.Text = "test browser";
      testBrowser.Size = new System.Drawing.Size(450, 206);
      testBrowser.Dock = System.WinForms.DockStyle.Fill;
      testBrowser.TabIndex = 0;
      testBrowser.AfterSelect += new TreeViewEventHandler(AfterSelect);
		
      buttonPanel.Dock = System.WinForms.DockStyle.Bottom;
      buttonPanel.Location = new System.Drawing.Point(0, 206);
      buttonPanel.Size = new System.Drawing.Size(450, 48);
      buttonPanel.TabIndex = 2;
      buttonPanel.Text = "button panel";
		
      runButton.Location = new System.Drawing.Point(8, 12);
      runButton.Size = new System.Drawing.Size(60, 24);
      runButton.TabIndex = 0;
      runButton.Text = "Run";
      runButton.Enabled = false;
      runButton.Click += new System.EventHandler(RunButtonClicked);
		
      closeButton.Location = new System.Drawing.Point(378, 12);
      closeButton.Size = new System.Drawing.Size(60, 24);
      closeButton.TabIndex = 2;
      closeButton.Anchor = System.WinForms.AnchorStyles.BottomRight;
      closeButton.Text = "Close";
      closeButton.Click += new System.EventHandler(CloseButtonClicked);
		
      buttonPanel.Controls.Add(runButton);
      buttonPanel.Controls.Add(closeButton);
      buttonPanel.Controls.Add(collapseButton);
      testPanel.Controls.Add(testBrowser);
      this.Controls.Add(buttonPanel);
      this.Controls.Add(testPanel);
		
    }

    private ImageList CreateImages(System.Resources.ResourceManager resources)
    {
      ImageList images = new ImageList();
      images.ImageSize = new System.Drawing.Size(16, 16);
      images.ImageStream = null;
      images.ColorDepth = System.WinForms.ColorDepth.Depth8Bit;
      //@design images.SetLocation(new System.Drawing.Point(7, 7));
      images.TransparentColor = System.Drawing.Color.Transparent;
      images.Images.Add((Bitmap)resources.GetObject("ClosedFolder"));
      images.Images.Add((Bitmap)resources.GetObject("OpenFolder"));
      images.Images.Add((Bitmap)resources.GetObject("OkIcon"));
      images.Images.Add((Bitmap)resources.GetObject("ErrorIcon"));
      images.Images.Add((Bitmap)resources.GetObject("FailureIcon"));
      return images;
    }

    private void AfterSelect(object source, TreeViewEventArgs e) 
    {
      if(testBrowser.SelectedNode != null)
        runButton.Enabled = true;
      else
        runButton.Enabled = false;
    }


    protected void RunButtonClicked(object sender, System.EventArgs e)
    {
      ClearResults();
      RunTest();
    }

    private void ClearResults()
    {
      foreach(TreeNode node in changedNodes)
      {
        node.ImageIndex = (int)Icons.ClosedFolder;
      }
      changedNodes.Clear();
    }

    private void RunTest()
    {
      if(testBrowser.SelectedNode != null)
      {
        TreeNode node = testBrowser.SelectedNode;
        if(node.GetNodeCount(false) > 0)
          node.ExpandAll();
        runner.Run((ITest)testNameAssociation[node.Text]);
        testBrowser.SelectedNode = null;
        runButton.Enabled = false;
      }
    }

    private void CloseButtonClicked(object sender, System.EventArgs e)
    { Close();	}

    private void CollapseButtonClicked(object sender, System.EventArgs e)
    { 
      testBrowser.CollapseAll(); 
    }

    public void AddError(ITest test, Exception t) 
    {
      testFailure = true;
      TreeNode node = (TreeNode)nodeTestAssociation[test];
      node.ImageIndex = (int)Icons.Error;
      changedNodes.Add(node);
    }
    public void AddFailure(ITest test, AssertionFailedError t) 
    {
      testFailure = true;
      TreeNode node = (TreeNode)nodeTestAssociation[test];
      node.ImageIndex = (int)Icons.Failure;
      changedNodes.Add(node);
    }

    public void EndTest(ITest test) 
    {
      if(testFailure == false)
      {
        TreeNode node = (TreeNode)nodeTestAssociation[test];
        node.ImageIndex = (int)Icons.Ok;
        changedNodes.Add(node);
      }
    }

    public void StartTest(ITest test) 
    {
      testFailure = false;
    }
  }
}
