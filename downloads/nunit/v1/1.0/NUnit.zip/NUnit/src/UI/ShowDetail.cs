namespace NUnit.GUI
{
  using System;
  using System.WinForms;
  using System.Drawing;
  
  public class ShowDetail : Form 
  {
    private Button closeButton = new Button();
    private RichTextBox stackTrace = new RichTextBox();
    private System.Resources.ResourceManager resources;

    public ShowDetail(Exception ex) 
    {
      InitializeComponent(ex.ToString());
      this.Icon = (Icon)resources.GetObject("LogoIcon");
    }

    private void InitializeComponent(String trace)
    {
      resources = 
        new System.Resources.ResourceManager(typeof(NUnit.GUI.ShowTests));
      InitializeForm();
      InitializeCloseButton();
      InitializeStackTrace(trace);
    }    

    private void InitializeForm()
    {
      Text = "Stack Trace";
      AutoScaleBaseSize = new Size(5, 13);
      ClientSize = new Size(666, 248);
    }

    private void InitializeStackTrace(String trace)
    {
      stackTrace.Location = new System.Drawing.Point(8,8);
      stackTrace.Size = new System.Drawing.Size(650,192);
      stackTrace.ReadOnly = true;
      stackTrace.Text = trace;
      stackTrace.WordWrap = false;
      stackTrace.Anchor = AnchorStyles.All;
      stackTrace.Font = new System.Drawing.Font("Courier New", 12f, 
                                                System.Drawing.FontStyle.Regular, 
                                                System.Drawing.GraphicsUnit.World);
      Controls.Add(stackTrace);
    }

    private void InitializeCloseButton()
    {
      closeButton.Location = new Point(598, 208);
      closeButton.Size = new Size(60, 24);
      closeButton.TabIndex = 1;
      closeButton.Text = "Close";
      closeButton.Anchor = AnchorStyles.BottomRight;
      closeButton.Click += new System.EventHandler(CloseButtonClicked);

      // add to the form
      AcceptButton = closeButton;
      Controls.Add(closeButton);
    }

    private void CloseButtonClicked(object sender, System.EventArgs e)
    {
      Close();	
    }
  }
}
