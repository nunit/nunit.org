namespace NUnit.Samples.Money {

  using System;

  using NUnit.Framework;

  public class MoneyTest: TestCase {
    private Money f12CHF;
    private Money f14CHF;
    private Money f7USD;
    private Money f21USD;
        
    private MoneyBag fMB1;
    private MoneyBag fMB2;

    public MoneyTest(String name): base(name) {}
    protected override void SetUp() {
      f12CHF= new Money(12, "CHF");
      f14CHF= new Money(14, "CHF");
      f7USD= new Money( 7, "USD");
      f21USD= new Money(21, "USD");

      fMB1= new MoneyBag(f12CHF, f7USD);
      fMB2= new MoneyBag(f14CHF, f21USD);
    }
    public void TestBagMultiply() {
      // {[12 CHF][7 USD]} *2 == {[24 CHF][14 USD]}
      Money[] bag = { new Money(24, "CHF"), new Money(14, "USD") };
      MoneyBag expected= new MoneyBag(bag);
      AssertEquals(expected, fMB1.Multiply(2)); 
      Assert(fMB1.Multiply(0).IsZero);
    }
    public void TestBagNegate() {
      // {[12 CHF][7 USD]} negate == {[-12 CHF][-7 USD]}
      Money[] bag= { new Money(-12, "CHF"), new Money(-7, "USD") };
      MoneyBag expected= new MoneyBag(bag);
      AssertEquals(expected, fMB1.Negate());
    }
    public void TestBagSimpleAdd() {
      // {[12 CHF][7 USD]} + [14 CHF] == {[26 CHF][7 USD]}
      Money[] bag= { new Money(26, "CHF"), new Money(7, "USD") };
      MoneyBag expected= new MoneyBag(bag);
      AssertEquals(expected, fMB1.Add(f14CHF));
    }
    public void TestBagSubtract() {
      // {[12 CHF][7 USD]} - {[14 CHF][21 USD] == {[-2 CHF][-14 USD]}
      Money[] bag= { new Money(-2, "CHF"), new Money(-14, "USD") };
      MoneyBag expected= new MoneyBag(bag);
      AssertEquals(expected, fMB1.Subtract(fMB2));
    }
    public void TestBagSumAdd() {
      // {[12 CHF][7 USD]} + {[14 CHF][21 USD]} == {[26 CHF][28 USD]}
      Money[] bag= { new Money(26, "CHF"), new Money(28, "USD") };
      MoneyBag expected= new MoneyBag(bag);
      AssertEquals(expected, fMB1.Add(fMB2));
    }
    public void TestIsZero() {
      Assert(fMB1.Subtract(fMB1).IsZero); 
    }
    public void TestMixedSimpleAdd() {
      // [12 CHF] + [7 USD] == {[12 CHF][7 USD]}
      Money[] bag= { f12CHF, f7USD };
      MoneyBag expected= new MoneyBag(bag);
      AssertEquals(expected, f12CHF.Add(f7USD));
    }
    public void TestMoneyBagEquals() {
      Assert(!fMB1.Equals(null)); 

      AssertEquals(fMB1, fMB1);
      MoneyBag equal= new MoneyBag(new Money(12, "CHF"), new Money(7, "USD"));
      Assert(fMB1.Equals(equal));
      Assert(!fMB1.Equals(f12CHF));
      Assert(!f12CHF.Equals(fMB1));
      Assert(!fMB1.Equals(fMB2));
    }
    public void TestMoneyBagHash() {
      MoneyBag equal= new MoneyBag(new Money(12, "CHF"), new Money(7, "USD"));
      AssertEquals(fMB1.GetHashCode(), equal.GetHashCode());
    }
    public void TestMoneyEquals() {
      Assert(!f12CHF.Equals(null)); 
      Money equalMoney= new Money(12, "CHF");
      AssertEquals(f12CHF, f12CHF);
      AssertEquals(f12CHF, equalMoney);
      AssertEquals(f12CHF.GetHashCode(), equalMoney.GetHashCode());
      Assert(!f12CHF.Equals(f14CHF));
    }
    public void TestMoneyHash() {
      Assert(!f12CHF.Equals(null)); 
      Money equal= new Money(12, "CHF");
      AssertEquals(f12CHF.GetHashCode(), equal.GetHashCode());
    }
    public void TestNormalize() {
      Money[] bag= { new Money(26, "CHF"), new Money(28, "CHF"), new Money(6, "CHF") };
      MoneyBag moneyBag= new MoneyBag(bag);
      Money[] expected = { new Money(60, "CHF") };
      // note: expected is still a MoneyBag
      MoneyBag expectedBag= new MoneyBag(expected);
      AssertEquals(expectedBag, moneyBag);
    }
    public void TestNormalize2() {
      // {[12 CHF][7 USD]} - [12 CHF] == [7 USD]
      Money expected= new Money(7, "USD");
      AssertEquals(expected, fMB1.Subtract(f12CHF));
    }
    public void TestNormalize3() {
      // {[12 CHF][7 USD]} - {[12 CHF][3 USD]} == [4 USD]
      Money[] s1 = { new Money(12, "CHF"), new Money(3, "USD") };
      MoneyBag ms1= new MoneyBag(s1);
      Money expected= new Money(4, "USD");
      AssertEquals(expected, fMB1.Subtract(ms1));
    }
    public void TestNormalize4() {
      // [12 CHF] - {[12 CHF][3 USD]} == [-3 USD]
      Money[] s1 = { new Money(12, "CHF"), new Money(3, "USD") };
      MoneyBag ms1= new MoneyBag(s1);
      Money expected= new Money(-3, "USD");
      AssertEquals(expected, f12CHF.Subtract(ms1));
    }
    public void TestPrint() {
      AssertEquals("[12 CHF]", f12CHF.ToString());
    }
    public void TestSimpleAdd() {
      // [12 CHF] + [14 CHF] == [26 CHF]
      Money expected= new Money(26, "CHF");
      AssertEquals(expected, f12CHF.Add(f14CHF));
    }
    public void TestSimpleBagAdd() {
      // [14 CHF] + {[12 CHF][7 USD]} == {[26 CHF][7 USD]}
      Money[] bag= { new Money(26, "CHF"), new Money(7, "USD") };
      MoneyBag expected= new MoneyBag(bag);
      AssertEquals(expected, f14CHF.Add(fMB1));
    }
    public void TestSimpleMultiply() {
      // [14 CHF] *2 == [28 CHF]
      Money expected= new Money(28, "CHF");
      AssertEquals(expected, f14CHF.Multiply(2));
    }
    public void TestSimpleNegate() {
      // [14 CHF] negate == [-14 CHF]
      Money expected= new Money(-14, "CHF");
      AssertEquals(expected, f14CHF.Negate());
    }
    public void TestSimpleSubtract() {
      // [14 CHF] - [12 CHF] == [2 CHF]
      Money expected= new Money(2, "CHF");
      AssertEquals(expected, f14CHF.Subtract(f12CHF));
    }
  }
}
