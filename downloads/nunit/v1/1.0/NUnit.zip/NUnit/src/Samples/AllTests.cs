namespace NUnit.Samples {

  using System;

  using NUnit.Framework;
  using NUnit.Tests;

  /// <summary>TestSuite that runs all the sample Tests.</summary>
  public class AllTests {
    public static ITest Suite {
      get {
        TestSuite suite= new TestSuite("All NUnit Tests");
        suite.AddTest(ArrayListTest.Suite);
        suite.AddTest(new TestSuite(typeof(NUnit.Samples.Money.MoneyTest)));
        suite.AddTest(NUnit.Tests.AllTests.Suite);
        return suite;
      }
    }
  }
}
