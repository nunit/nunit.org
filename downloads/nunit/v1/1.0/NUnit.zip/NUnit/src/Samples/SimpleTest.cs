namespace NUnit.Samples {

  using System;

  using NUnit.Framework;

  /// <summary>Some simple Tests.</summary>
  public class SimpleTest: TestCase {
    protected int fValue1;
    protected int fValue2;
    
    public SimpleTest(String name) : base(name) {
    }
        
    protected override void SetUp() {
      fValue1= 2;
      fValue2= 3;
    }
        
    public static ITest Suite {
      /*
       * the dynamic way
       */
      get{
        return new TestSuite(typeof (SimpleTest));
      }

      /*
       * the type safe way
       *
       protected class AddSimpleTest: SimpleTest {
         public void AddSimpleTest(String name) : base(name) {}
         protected override void RunTest() { TestAdd(); }
       }
       protected override void DivideSimpleTest: SimpleTest {
         public void DivideSimpleTest(String name) : base(name) {}
         protected override void RunTest() { TestAdd(); }
       }
       ...
       TestSuite suite= new TestSuite();
       suite.AddTest( new AddSimpleTest("Add");
       suite.AddTest( new DivideSimpleTest("TestDivideByZero");
       return suite;
      */
    }

    public void TestAdd() {
      double result= fValue1 + fValue2;
      // forced failure result == 5
      Assert(result == 6);
    }

    public void TestDivideByZero() {
      int zero= 0;
      int result= 8/zero;
    }

    public void TestEquals() {
      AssertEquals(12, 12);
      AssertEquals(12L, 12L);
      AssertEquals((object)12, (object)12);
            
      AssertEquals("Size", 12, 13);
      AssertEquals("Capacity", 12.0, 11.99, 0.0);
    }
  }
}
