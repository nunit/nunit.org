Option Explicit

Imports System

Imports NUnit.Framework

Namespace NUnit.Samples
  Public Class SimpleVBTest
    Inherits TestCase

	Private fValue1 As Integer
	Private fValue2 As Integer

	Public Sub New(name as String)
	  MyBase.New(name)
	End Sub

	Protected Overrides Sub SetUp()
	  fValue1 = 2
	  fValue2 = 3
	End Sub

	ReadOnly Shared Property Suite() As ITest
	  Get
		Suite = New TestSuite(GetType(SimpleVBTest))
	  End Get
	End Property

	Public Sub TestAdd()
	  Dim result As Double

	  result = fValue1 + fValue2
	  Assert(result = 6)
	End Sub

	Public Sub TestDivideByZero()
	  Dim zero As Integer
	  Dim result As Double

	  zero = 0
	  result = 8 / zero
	End Sub

	Public Sub TestEquals()
	  AssertEquals(12, 12)
	  AssertEquals(CLng(12), CLng(12))

	  AssertEquals("Size", 12, 13)
	  AssertEquals("Capacity", 12.0, 11.99, 0.0)
	End Sub
  End Class
End Namespace