namespace NUnit {

  using System;
  using System.Collections;
  using System.WinForms;
  
  using NUnit.Framework;
  using NUnit.Runner;
  using NUnit.TextUI;
  
  public class Top {
    public static void Main(String[] args) {
      String testCase = "";
      bool wait = false;
      ArrayList newArgs = new ArrayList(args.Length);

#if (NUNITCONSOLE)
      bool textUI = true;
#else
      bool textUI = false;
#endif
      
      foreach (String arg in args) {
        if (arg.Equals("/wait"))
          wait= true;
        else if (arg.Equals("/c")) 
          testCase= BaseTestRunner.ExtractClassName(arg);
        else if (arg.Equals("/v")){
          Console.Out.WriteLine("NUnit "+NUnit.Runner.Version.id()
                                + " by Philip Craig");
          Console.Out.WriteLine("ported from JUnit 3.3.1 beta by Kent Beck"
                                + " and Erich Gamma");
        }else
          testCase= arg;
      }
      if (textUI && testCase.Equals("")) {
        Console.WriteLine("Usage: NUnitConsole [/wait] testCaseName, where"
                          + " name is the name of the TestCase class.");
        Environment.Exit(-2);
      }
      if (textUI)    {
        TestRunner aTestRunner = new NUnit.TextUI.TestRunner();
        try {
          TestResult r = aTestRunner.Start(testCase, wait);
          if (!r.WasSuccessful) 
            Environment.Exit(-1);
          Environment.Exit(0);
        } catch(Exception e) {
          Console.Out.WriteLine(e.Message);
          Environment.Exit(-2);
        }
      } else {
        NUnit.GUI.TestRunnerForm g = new NUnit.GUI.TestRunnerForm();
        g.initialTestToRun = testCase;
        Application.Run(g);
      }
    }
  }
}
