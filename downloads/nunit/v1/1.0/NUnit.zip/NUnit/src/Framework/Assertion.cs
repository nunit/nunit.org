namespace NUnit.Framework {

  using System;

  /// <summary>A set of Assert methods.</summary>
  public class Assertion {

    /// <summary>Protect constructor since it is a static only class</summary>
    protected Assertion() {
    }
    
    /// <summary>Asserts that a condition is true. If it isn't it throws
    /// an <see cref="AssertionFailedError"/>.</summary>
    static public void Assert(String message, bool condition) {
      if (!condition)
        Fail(message);
    }
    
    /// <summary>Asserts that a condition is true. If it isn't it throws
    /// an <see cref="AssertionFailedError"/>.</summary>
    static public void Assert(bool condition) {
      Assert(null, condition);
    }

    /// <summary>Asserts that two doubles are equal.</summary>
    /// <param name="expected">the expected value of an object.</param>
    /// <param name="actual">the actual value of an object.</param>
    /// <param name="delta">tolerated delta.</param>
    static public void AssertEquals(double expected, double actual, double delta) {
      AssertEquals(null, expected, actual, delta);
    }
    
    /// <summary>Asserts that two longs are equal.</summary>
    /// <param name="expected">the expected value of an object.</param>
    /// <param name="actual">the actual value of an object.</param>
    static public void AssertEquals(long expected, long actual) {
      AssertEquals(null, expected, actual);
    }
    
    /// <summary>Asserts that two objects are equal. If they are not
    /// an <see cref="AssertionFailedError"/> is thrown.</summary>
    /// <param name="expected">the expected value of an object.</param>
    /// <param name="actual">the actual value of an object.</param>
    static public void AssertEquals(Object expected, Object actual) {
      AssertEquals(null, expected, actual);
    }
    
    /// <summary>Asserts that two doubles are equal.</summary>
    /// <param name="message">the detail message for this Assertion.</param>
    /// <param name="expected">the expected value of an object.</param>
    /// <param name="actual">the actual value of an object.</param>
    /// <param name="delta">tolerated delta.</param>
    static public void AssertEquals(String message, double expected,
                                    double actual, double delta) {
      // Because comparison with NaN always returns false
      if (!(Math.Abs(expected-actual) <= delta))
        FailNotEquals(message, expected, actual);
    }
    
    /// <summary>Asserts that two longs are equal.</summary>
    /// <param name="message">the detail message for this Assertion.</param>
    /// <param name="expected">the expected value of an object.</param>
    /// <param name="actual">the actual value of an object.</param>
    ///
    static public void AssertEquals(String message, long expected, long actual) {
      AssertEquals(message, (object)expected, (object)actual);
    }
    
    /// <summary>Asserts that two objects are equal. If they are not
    /// an <see cref="AssertionFailedError"/> is thrown.</summary>
    /// <param name="message">the detail message for this Assertion.</param>
    /// <param name="expected">the expected value of an object.</param>
    /// <param name="actual">the actual value of an object.</param>
    ///
    static public void AssertEquals(String message, Object expected,
                                    Object actual) {
      if (expected == null && actual == null)
        return;
      if (expected != null && expected.Equals(actual))
        return;
      FailNotEquals(message, expected, actual);
    }
    
    /// <summary>Asserts that an object isn't null.</summary>
    static public void AssertNotNull(Object anObject) {
      AssertNotNull(null, anObject);
    }
    
    /// <summary>Asserts that an object isn't null.</summary>
    static public void AssertNotNull(String message, Object anObject) {
      Assert(message, anObject != null); 
    }
    
    /// <summary>Asserts that an object is null.</summary>
    static public void AssertNull(Object anObject) {
      AssertNull(null, anObject);
    }
    
    /// <summary>Asserts that an object is null.</summary>
    static public void AssertNull(String message, Object anObject) {
      Assert(message, anObject == null); 
    }
    
    /// <summary>Asserts that two objects refer to the same object. If they
    /// are not the same an <see cref="AssertionFailedError"/> is thrown.
    /// </summary>
    /// <param name="expected">the expected value of an object.</param>
    /// <param name="actual">the actual value of an object.</param>
    static public void AssertSame(Object expected, Object actual) {
      AssertSame(null, expected, actual);
    }
    
    /// <summary>Asserts that two objects refer to the same object. 
    /// If they are not an <see cref="AssertionFailedError"/> is thrown.
    /// </summary>
    /// <param name="message">the detail message for this Assertion.</param>
    /// <param name="expected">the expected value of an object.</param>
    /// <param name="actual">the actual value of an object.</param>
    static public void AssertSame(String message, Object expected,
                                  Object actual) {
      if (expected == actual)
        return;
      FailNotSame(message, expected, actual);
    }
    
    /// <summary>Fails a test with no message.</summary>
    static public void Fail() {
      Fail(null);
    }
    
    /// <summary>Fails a test with the given message.</summary>
    static public void Fail(String message) {
      throw new AssertionFailedError(message);
    }
    
    static private void FailNotEquals(String message, Object expected,
                                      Object actual) {
      String formatted= "";
      if (message != null)
        formatted= message+" ";
      Fail(formatted+"expected:<"+expected+"> but was:<"+actual+">");
    }
    
    static private void FailNotSame(String message, Object expected, Object actual) {
      String formatted= "";
      if (message != null)
        formatted= message+" ";
      Fail(formatted+"expected same");
    }
  }
}
