namespace NUnit.Framework {

  using System;
  
  /// <summary>A Listener for test progress</summary>
  public interface ITestListener {
    /// <summary>An error occurred.</summary>
    void AddError(ITest test, Exception t);
    
    /// <summary>A failure occurred.</summary>
    void AddFailure(ITest test, AssertionFailedError t);
    
    /// <summary>A test ended.</summary>
    void EndTest(ITest test); 
    
    /// <summary>A test started.</summary>
    void StartTest(ITest test);
  }
  
  public delegate void TestEventHandler(Object source, TestEventArgs e);
  
  public class TestEventArgs : EventArgs{
    protected ITest fTest;
    protected TestEventArgs (){}
    public TestEventArgs (ITest test){
      fTest = test;
    }
    
    public ITest Test{
      get{return fTest;}
    }
  }
  
  public delegate void TestExceptionEventHandler(Object source,
                                                 TestExceptionEventArgs e);
  
  public class TestExceptionEventArgs : TestEventArgs{
    private TestExceptionEventArgs(){}
    
    private Exception fThrownException;
    
    public TestExceptionEventArgs(ITest test, Exception e){
      //this(test);
      fTest = test;
      fThrownException = e;
    }
    
    public Exception ThrownException{
      get{return fThrownException;}
    }
  }
}
