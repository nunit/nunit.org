namespace NUnit.Framework {

  using System;
  using System.Collections;
  using System.Reflection;

  /// <summary>A <c>TestSuite</c> is a <c>Composite</c> of Tests.</summary>
  /// <remarks>It runs a collection of test cases. Here is an example using
  /// the dynamic test definition.
  /// <code>
  /// TestSuite suite= new TestSuite();
  /// suite.AddTest(new MathTest("TestAdd"));
  /// suite.AddTest(new MathTest("TestDivideByZero"));
  /// </code>
  /// Alternatively, a TestSuite can extract the Tests to be run automatically.
  /// To do so you pass the class of your TestCase class to the
  /// TestSuite constructor.
  /// <code>
  /// TestSuite suite= new TestSuite(typeof(MathTest));
  /// </code>
  /// This constructor creates a suite with all the methods
  /// starting with "Test" that take no arguments.</remarks>
  /// <seealso cref="ITest"/>
  public class TestSuite: ITest {

    private ArrayList fTests= new ArrayList(10);
    private String fName;

    /// <summary>Constructs an empty TestSuite.</summary>
    public TestSuite() {
    }

    /// <summary>Constructs a TestSuite from the given class.</summary>
    /// <remarks>Adds all the methods
    /// starting with "Test" as test cases to the suite.
    /// Parts of this method was written at 2337 meters in the H�ffih�tte,
    /// Kanton Uri</remarks>
    public TestSuite(Type theClass) {
      fName= theClass.ToString();    
      ConstructorInfo constructor= GetConstructor(theClass);
      if (theClass.IsNotPublic) {
        AddTest(Warning("Class "+theClass.ToString()+" is not public"));
        return;
      }
      if (constructor == null) {
        AddTest(Warning("Class "+ theClass.ToString()
                        + " has no public constructor TestCase(String name)"));
        return;
      }

      Type superClass= theClass;
      ArrayList names= new ArrayList();
      while (typeof(ITest).IsAssignableFrom(superClass)) {
        MethodInfo[] methods= superClass.GetMethods(BindingFlags.LookupAll);
        for (int i= 0; i < methods.Length; i++) {
          AddTestMethod(methods[i], names, constructor);
        }
        superClass= superClass.BaseType;
      }
      if (fTests.Count == 0)
        AddTest(Warning("No Tests found in "+theClass.ToString()));
    }

    /// <summary>Constructs an empty TestSuite.</summary>
    public TestSuite(String name) {
      fName= name;
    }

    /// <summary>Adds a test to the suite.</summary>
    public void AddTest(ITest test) {
      fTests.Add(test);
    }
        
    private void AddTestMethod(MethodInfo m, ArrayList names,
                               ConstructorInfo constructor) {
      String name= m.Name;
      if (names.Contains(name)) 
        return;
      if (IsPublicTestMethod(m)) {
        names.Add(name);

        Object[] args= new Object[]{name};
        try {
          AddTest((ITest)constructor.Invoke(args));
        } catch (Exception t) {
          AddTest(Warning("Cannot instantiate test case: "+name + t.Message));
        }
      } else { // almost a test method
        if (IsTestMethod(m)) 
          AddTest(Warning("test method isn't public: "+m.Name));
      }
    }
        
    /// <value>The number of test cases that will be run by this test.</value>
    public int CountTestCases {
      get {
        int count= 0;
        foreach (ITest test in Tests) {
          count += test.CountTestCases;
        }
        return count;
      }
    }

    /// <summary>Gets a constructor which takes a single String as
    /// its argument.</summary>
    private ConstructorInfo GetConstructor(Type theClass) {
      Type[] args= { typeof(String) };
      ConstructorInfo c= null;
      try {
        c= theClass.GetConstructor(args);
      } catch(Exception) {
      }
      return c;
    }
        
    private bool IsPublicTestMethod(MethodInfo m) {
      return IsTestMethod(m) && m.IsPublic;
    }

    private bool IsTestMethod(MethodInfo m) {
      String name= m.Name;            

      ParameterInfo[] parameters= m.GetParameters();
      Type returnType= m.ReturnType;
      return parameters.Length == 0 && name.ToLower().StartsWith("test")
        && returnType.Equals(typeof(Void));
    }
         
    /// <summary>Runs the Tests and collects their result in a
    /// TestResult.</summary>
    public virtual void Run(TestResult result) {
      foreach (ITest test in Tests) {
        if (result.ShouldStop )
          break;
        RunTest(test, result);
      }
    }

    public virtual void RunTest(ITest test, TestResult result) {
      test.Run(result);
    }
        
    /// <value>The test at the given index.</value>
    /// <remarks>Formerly TestAt(int).</remarks>
    public ITest this[int index] {
      get {return (ITest)fTests[index]; }
    }
        
    /// <value>The number of Tests in this suite.</value>
    public int TestCount {
      get {return fTests.Count; }
    }
        
    /// <value>The Tests as an ArrayList.</value>
    public ArrayList Tests {
      get { return fTests; }
    }
        
    public override String ToString() {
      if (fName != null)
        return fName;
      return base.ToString();
    }

    private ITest Warning(String message) {
      return new WarningFail(message);
    }    

    /// <summary>Returns a test which will fail and log a warning
    /// message.</summary>
    public class WarningFail: TestCase {
      private String fMessage;
            
      public WarningFail(String message): base("warning") {
        fMessage = message;
      }

      protected override void RunTest() {
        Fail(fMessage);
      }         
    }
  }
}
