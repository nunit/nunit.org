namespace NUnit.Framework {

  using System;
  
  /// <summary cref="System.Exception">Thrown when an assertion failed.</summary>
  public class AssertionFailedError: Exception {
    public AssertionFailedError (String message) : base(message) {}
  }
}
