namespace NUnit.TextUI {

  using System;
  using System.IO;
  using System.Reflection;

  using NUnit.Framework;
  using NUnit.Runner;

  /// <summary>A command line based tool to run tests.</summary><remarks>
  /// <code>
  /// C:\NUnit /t [/wait] TestCaseClass
  /// </code>
  /// TestRunner expects the name of a TestCase class as argument.
  /// If this class defines a static <c>Suite</c> property it 
  /// will be invoked and the returned test is run. Otherwise all 
  /// the methods starting with "Test" having no arguments are run.
  ///
  /// When the wait command line argument is given TestRunner
  /// waits until the users types RETURN.
  ///
  /// TestRunner prints a trace as the tests are executed followed by a
  /// summary at the end.</remarks>
  public class TestRunner: BaseTestRunner {
    TextWriter fWriter = Console.Out;

    public TestRunner() {
      fTestLoader= new StandardTestSuiteLoader();
    }

    public TestRunner(TextWriter writer) : this() {
      fWriter= writer;
    }

    public override void AddError(ITest test, Exception t) {
      lock(this)
        Writer.Write("E");
    }

    public override void AddFailure(ITest test, AssertionFailedError t) {
      lock (this)
        Writer.Write("F");
    }

    /// <summary>Creates the TestResult to be used for the test run.</summary>
    protected TestResult CreateTestResult() {
      return new TestResult();
    }

    protected TestResult DoRun(ITest suite, bool wait) {
      TestResult result= CreateTestResult();
      result.AddListener(this);
      long startTime= System.DateTime.Now.Ticks;
      suite.Run(result);
      long endTime= System.DateTime.Now.Ticks;
      long runTime= (endTime-startTime) / 10000;
      Writer.WriteLine();
      Writer.WriteLine("Time: "+ElapsedTimeAsString(runTime));
      Print(result);

      Writer.WriteLine();
            
      if (wait) {
        Writer.WriteLine("<RETURN> to continue");
        try {
          Console.ReadLine();
        }
        catch(Exception) {
        }
      }
      return result;    
    }
        
    public override void EndTest(ITest test) {
    }

    public void Print(TestResult result) {
      lock(this) {
        PrintHeader(result);
        PrintErrors(result);
        PrintFailures(result);
      }
    }

    /// <summary>Prints the errors to the standard output.</summary>
    public void PrintErrors(TestResult result) {
      if (result.ErrorCount != 0) {
        if (result.ErrorCount == 1)
          Writer.WriteLine("There was "+result.ErrorCount+" error:");
        else
          Writer.WriteLine("There were "+result.ErrorCount+" errors:");
                
        int i= 1;
        foreach (TestFailure failure in result.Errors) {
          Writer.WriteLine(i++ + ") "+failure.FailedTest);
          failure.FormattedStackTrace(Writer);
        }
      }
    }

    /// <summary>Prints failures to the standard output.</summary>
    public void PrintFailures(TestResult result) {
      if (result.FailureCount != 0) {
        if (result.FailureCount == 1)
          Writer.WriteLine("There was " + result.FailureCount + " failure:");
        else
          Writer.WriteLine("There were " + result.FailureCount + " failures:");
        int i = 1;
        foreach (TestFailure failure in result.Failures) {
          Writer.Write(i++ + ") " + failure.FailedTest);
          Exception t= failure.ThrownException;
          if (t.Message != "")
            Writer.WriteLine(" \"" + Truncate(t.Message) + "\"");
          else {
            Writer.WriteLine();
            failure.FormattedStackTrace(Writer);
          }
        }
      }
    }

    /// <summary>Prints the header of the report.</summary>
    public void PrintHeader(TestResult result) {
      if (result.WasSuccessful) {
        Writer.WriteLine();
        Writer.Write("OK");
        Writer.WriteLine (" (" + result.RunCount + " tests)");
                
      } else {
        Writer.WriteLine();
        Writer.WriteLine("FAILURES!!!");
        Writer.WriteLine("Test Results:");
        Writer.WriteLine("Run: "+result.RunCount+ 
                           " Failures: "+result.FailureCount+
                           " Errors: "+result.ErrorCount);
      }
    }

    /// <summary>Runs a Suite extracted from a TestCase subclass.</summary>
    static public void Run(Type testClass) {
      Run(new TestSuite(testClass));
    }

    static public void Run(ITest suite) {
      TestRunner aTestRunner= new TestRunner();
      aTestRunner.DoRun(suite, false);
    }

    /// <summary>Runs a single test and waits until the user
    /// types RETURN.</summary>
    static public void RunAndWait(ITest suite) {
      TestRunner aTestRunner= new TestRunner();
      aTestRunner.DoRun(suite, true);
    }

    protected override void RunFailed(String message) {
      Console.Out.WriteLine(message);
      // Environment.ExitCode = -1;
      // throw new ApplicationException(message); // (web service
      Environment.Exit(-1);
    }

    /// <summary>Starts a test run. Analyzes the command line arguments
    /// and runs the given test suite.</summary>
    public TestResult Start(String testCase, bool wait) {            
      try {
        ITest suite = GetTest(testCase);
        return DoRun(suite, wait);
      }catch(Exception e) {
        throw
          new ApplicationException("Could not create and run test suite", e);
      }
    }

    public override void StartTest(ITest test) {
      lock (this) {
        Console.Write(".");
      }
    }

    protected TextWriter Writer {
      get { return fWriter; }
    }
  }
}
