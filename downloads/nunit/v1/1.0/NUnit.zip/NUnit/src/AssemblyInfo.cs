using System;
using System.Reflection;
using System.Runtime.CompilerServices;

// Mark the framework assembly as CLS compliant
[assembly:CLSCompliant(true)]

// Basic information for the assembly
[assembly:AssemblyTitle("NUnit Testing Framework")]
[assembly:AssemblyDescription("A unit testing framework for the .Net platform, ported from junit by Kent Beck and Erich Gamma.")]
[assembly:AssemblyConfiguration("")]
[assembly:AssemblyCompany("")]
[assembly:AssemblyProduct("NUnit")]
[assembly:AssemblyCopyright("")]
[assembly:AssemblyTrademark("")]
[assembly:AssemblyCulture("")]

// Version information for the assembly
[assembly:AssemblyVersion("1.7.*")]

// TODO: should this assembly be signed (or should we provide a signed and unsigned version?)
[assembly:AssemblyDelaySign(false)]
[assembly:AssemblyKeyFile("")]
[assembly:AssemblyKeyName("")]
