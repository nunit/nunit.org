using System.Reflection;
using System.Runtime.CompilerServices;

// Information about this assembly is defined by the following
// attributes.
//
// change them to the information which is associated with the assembly
// you compile.

[assembly: AssemblyTitle("Mono.Addins")]
[assembly: AssemblyCopyright("Copyright (C) 2007 Novell, Inc (http://www.novell.com)")]

// The assembly version has following format :
//
// Major.Minor.Build.Revision
//
// You can specify all values by your own or you can build default build and revision
// numbers with the '*' character (the default):

[assembly: AssemblyVersion("1.0.0.0")]

[assembly: InternalsVisibleTo ("Mono.Addins.Setup, PublicKey=00240000048000009400000006020000002400005253413100" +
	"0400000100010079159977d2d03a8e6bea7a2e74e8d1afcc93e8851974952bb480a12c9134474d04062447c37e0e68c080536fcf3c" +
	"3fbe2ff9c979ce998475e506e8ce82dd5b0f350dc10e93bf2eeecf874b24770c5081dbea7447fddafa277b22de47d6ffea449674a4" +
	"f9fccf84d15069089380284dbdd35f46cdff12a1bd78e4ef0065d016df")]
