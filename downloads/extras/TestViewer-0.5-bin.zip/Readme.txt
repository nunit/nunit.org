TestViewer 0.5 Release - April 30, 2008
Copyright 2008 by Charlie Poole

TestViewer allows you to view the xml result file produced by
NUnit in a tree display similar to that used in the NUnit Gui.

INSTALLATION AND USAGE

Unzip all the included files into a directory of your choice
and execute TestViewer.exe from that directory.

If you have an installation of NUnit 2.4.7 for .NET 1.1 on
your system, you may simply copy the TestViewer.exe file 
into the NUnit bin directory and execute it from there.

If you are using any other version of NUnit, or a 2.4.7
package built for .NET 2.0, keep this program in a separate
directory, along with the included NUnit assemblies.

Please report any problems on the nunit-users list.
