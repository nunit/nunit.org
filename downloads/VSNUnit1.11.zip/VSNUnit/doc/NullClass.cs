using System;

namespace doc
{
	/// <summary>
	/// Summary description for NullClass.
	/// </summary>
	public class NullClass
	{
		public NullClass()
		{
			//
			// TODO: Add constructor logic here
			//
		}
	}
}
