namespace NUnit.Tests 
{

	using System;
	using System.Diagnostics;
	using System.Reflection;

	using NUnit.Framework;
/// <summary>
/// 
/// </summary>
	public class TextRunnerTest: TestCase 
	{
		private String testDll;
		private String nunitExe;
		/// <summary>
		/// 
		/// </summary>
		/// <param name="name"></param>
		public TextRunnerTest(String name) : base(name) 
		{
			testDll = "\"" + GetType().Module.FullyQualifiedName + "\"";
			String currentExe = typeof(NUnit.Top).Module.FullyQualifiedName;
			int slash = currentExe.LastIndexOf('\\');
			nunitExe = "\"" + currentExe.Substring(0, slash + 1)
				+ "NUnitConsole.exe\"";
		}
    /// <summary>
    /// 
    /// </summary>
		public void TestFailure() 
		{
			ExecTest("NUnit.Tests.Failure", 1);
		}
	/// <summary>
	/// 
	/// </summary>
		public void TestSuccess() 
		{
			ExecTest("NUnit.Tests.Success", 0);
		}
/// <summary>
/// 
/// </summary>
		public void TestError() 
		{
			ExecTest("NUnit.Tests.BogusDude", 2);
		}
    
		void ExecTest(String testClass, int expected) 
		{ 
			Process p= Process.Start(nunitExe, "/t " + testClass + ',' + testDll);
      
			p.WaitForExit();
			AssertEquals(expected, p.ExitCode);
		}
	}
}
