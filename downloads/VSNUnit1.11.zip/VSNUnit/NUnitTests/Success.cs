namespace NUnit.Tests 
{
	using System;
	using NUnit.Framework;
  
	/// <summary>A test case testing the testing framework.</summary>
	public class Success: TestCase 
	{
		/// <summary>
		/// 
		/// </summary>
		/// <param name="name"></param>
		public Success(String name) : base(name) {}
		/// <summary>
		/// 
		/// </summary>
		public void Test() 
		{
		}
	}
}
