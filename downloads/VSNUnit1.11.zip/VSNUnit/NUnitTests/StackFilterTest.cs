namespace NUnit.Tests {

  using System;
  using System.IO;

  using NUnit.Framework;
  using NUnit.Runner;

  public class StackFilterTest: TestCase {
    string fFiltered;
    string fUnfiltered;
	
    public StackFilterTest(string name) : base(name) {}
	
    protected override void SetUp() {
      StringWriter swin= new StringWriter();
      swin.WriteLine("NUnit.Framework.AssertionFailedError");
      swin.WriteLine("	at NUnit.Framework.Assertion.Fail(Assert.cs:144)");
      swin.WriteLine("	at NUnit.Framework.Assertion.assert(Assert.cs:19)");
      swin.WriteLine("	at NUnit.Framework.Assertion.assert(Assert.cs:26)");
      swin.WriteLine("	at MyTest.F(MyTest.cs:13)");
      swin.WriteLine("	at MyTest.TestStackTrace(MyTest.cs:8)");
      swin.WriteLine("	at NUnit.Framework.TestCase.RunTest(TestCase.cs:156)");
      swin.WriteLine("	at NUnit.Framework.TestCase.RunBare(TestCase.cs:130)");
      swin.WriteLine("	at NUnit.Framework.TestResult$1.protect(TestResult.cs:100)");
      swin.WriteLine("	at NUnit.Framework.TestResult.RunProtected(TestResult.cs:118)");
      swin.WriteLine("	at NUnit.Framework.TestResult.Run(TestResult.cs:103)");
      swin.WriteLine("	at NUnit.Framework.TestCase.Run(TestCase.cs:121)");
      swin.WriteLine("	at NUnit.Framework.TestSuite.RunTest(TestSuite.cs:157)");
      swin.WriteLine("	at NUnit.Framework.TestSuite.Run(TestSuite.cs, Compiled Code)");
      fUnfiltered= swin.ToString();

      StringWriter swout= new StringWriter();
      swout.WriteLine("NUnit.Framework.AssertionFailedError");
      swout.WriteLine("	at MyTest.F(MyTest.cs:13)");
      swout.WriteLine("	at MyTest.TestStackTrace(MyTest.cs:8)");
      fFiltered= swout.ToString();
    }
		
    public void TestFilter() {
      // Create a baserunner so the static fields in baserunner are initialised
      // Can remove this when the GUI uses a BaseTestRunner. Without it,
      // the GUI gets a null reference to the BaseTestRunner fPreferences field
      // during this test.
      NUnit.TextUI.TestRunner dummy = new NUnit.TextUI.TestRunner();
      AssertEquals(fFiltered, BaseTestRunner.FilterStack(fUnfiltered));
    }
  }
}