namespace NUnit.Tests {

  using System;

  using NUnit.Framework;

  /// <summary>Test class used in TestTestCaseClassLoader</summary>
  public class ClassLoaderTestCase {
    public ClassLoaderTestCase() {
    }
    public bool AssertClassLoaders() {
      return (LoadedByTestCaseClassLoader() && SystemClassNotLoadedByTestCaseClassLoader());
    }
    private bool IsTestCaseClassLoader(String cl) {
      return (cl.Equals("NUnit.Util.TestCaseClassLoader"));
    }
    public bool LoadedByTestCaseClassLoader() {
      String cl= GetType().AssemblyQualifiedName;
      return IsTestCaseClassLoader(cl);
    }
    public bool SystemClassNotLoadedByTestCaseClassLoader() {
      String cl= typeof(Object).AssemblyQualifiedName;
      String cl2= typeof(TestCase).AssemblyQualifiedName;
      return (!IsTestCaseClassLoader(cl) && !IsTestCaseClassLoader(cl2)); 
    }
  }
}
