namespace NUnit.Tests {

  using System;
  using NUnit.Framework;
  using NUnit.Runner;

  /// <summary>A TestCase for testing the TestCaseClassLoader.</summary>
  public class TestCaseClassLoaderTest: TestCase {

    // Commented out until figure out .Net class loading

    public TestCaseClassLoaderTest(String name) : base(name) {}
#if (true)
    public void TestNothing() {}
#else
    public void TestClassLoading() {
      TestCaseClassLoader loader= new TestCaseClassLoader();
      Type loadedClass= loader.LoadClass("NUnit.Tests.ClassLoaderTest", true);
      Type[] args = {};
      ConstructorInfo constructor = loadedClass.GetConstructor(args);
      Object o= constructor.Invoke(null);
      //
      // Invoke the assertClassLoaders method via reflection.
      // We use reflection since the class is loaded by
      // another class loader and we can't do a successfull downcast to
      // ClassLoaderTestCase.
      // 
      MethodInfo method= loadedClass.GetMethod("Verify", new Type[0]);
      method.Invoke(o, new Type[0]);
    }
    // !!! Change to test foreign Assembly Type Loading
    public void TestJarClassLoading() throws Exception {
      URL url= getClass().getResource("test.jar");
      String path= url.getFile();
      TestCaseClassLoader loader= new TestCaseClassLoader(path);
      Class loadedClass= loader.loadClass("junit.tests.LoadedFromJar", true);
      Object o= loadedClass.newInstance();            
      //
      // Invoke the assertClassLoaders method via reflection.
      // We use reflection since the class is loaded by
      // another class loader and we can't do a successfull downcast to
      // ClassLoaderTestCase.
      // 
      Method method= loadedClass.getDeclaredMethod("verify", new Class[0]);
      method.invoke(o, new Class[0]);
    }
#endif
  }
}
