namespace NUnit.Tests 
{

	using System;

	/// <summary>Test class used in SuiteTest.</summary>
	public class NoTestCaseClass 
	{
		/// <summary>
		/// 
		/// </summary>
		/// <param name="name"></param>
		public NoTestCaseClass(String name) 
		{
		}
		/// <summary>
		/// 
		/// </summary>
		public void TestSuccess() 
		{
		}
	}
}
