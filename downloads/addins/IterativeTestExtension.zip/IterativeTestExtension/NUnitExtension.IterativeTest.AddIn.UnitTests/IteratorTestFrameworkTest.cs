// *********************************************************************
// Copyright 2008, Kelly Anderson
// This is free software licensed under the MIT license. 
// *********************************************************************
using NUnit.Framework;
using NUnit.Framework.SyntaxHelpers;

namespace NUnitExtension.IterativeTest.AddIn.UnitTests
{
  [TestFixture]
  public class IteratorTestFrameworkTest
  {
    [Test]
    public void GetSourceEnumeratorName()
    {
      string functionName = "TestFunction";
      IterativeTestAttribute attrib = new IterativeTestAttribute(functionName);

      string extractedFunctionName = IterativeTestFramework.GetSourceEnumeratorName(attrib);

      Assert.That(extractedFunctionName, Is.SameAs(functionName));
    }
  }
}