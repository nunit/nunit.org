// *********************************************************************
// Copyright 2008, Kelly Anderson
// This is free software licensed under the MIT license.
// *********************************************************************
using System.Collections;
using NUnit.Framework;

namespace NUnitExtension.IterativeTest.Sample
{
  [TestFixture]
  public class IterativeTestSample
  {
    private ArrayList list;

    public IEnumerable FileList()
    {
      if (list == null)
      {
        list = new ArrayList();
        list.Add( @"C:\test\test1.xml" );
        list.Add( @"C:\test\test2.xml" );
        list.Add( @"C:\test\test3.xml" );
      }
      return list;
    }

    /// <summary>
    /// The parameter is the name of the property member of the TestFixture
    /// that returns the items to iterate over as IEnumerable. In this case, this
    /// test will be invoked three times, passing in the three strings in 
    /// FileList.
    /// </summary>
    /// <param name="current"></param>
    [IterativeTest( "FileList" )]
    public void FileNameTest( object current )
    {
      string curStr = (string) current;
      Assert.IsTrue( curStr.EndsWith( "xml" ) );
    }

    // This should fail.
    [IterativeTest("FileList")]
    public void TestAllFail(object current)
    {
      string curStr = (string) current;
      Assert.IsTrue(curStr.EndsWith("foo"));
    }

    [Test]
    public void RegularTest()
    {
      Assert.IsTrue(true,"here");
    }
  }
}
