// *********************************************************************
// Copyright 2008, Kelly Anderson
// This is free software licensed under the MIT license.
// *********************************************************************
using System.Reflection;
using NUnit.Core;

namespace NUnitExtension.IterativeTest.AddIn
{
  public class IterativeTestCase : NUnitTestMethod
  {
    private readonly object _CurrentObject;

    /// <summary>
    /// 
    /// </summary>
    /// <param name="method"></param>
    /// <param name="current">The "current" object in the iteration.</param>
    public IterativeTestCase(MethodInfo method, object current) : base(method)
    {
      _CurrentObject = current;

      IterativeTestNameBuilder testNameBuilder = new IterativeTestNameBuilder(method, current);
      TestName.Name = testNameBuilder.GetTestName();
      TestName.FullName = testNameBuilder.GetFullTestName();
    }

    public object CurrentObject
    {
      get { return _CurrentObject; }
    }

    public override void RunTestMethod(TestCaseResult testResult)
    {
      object[] arguments = new object[1];
      arguments[0] = _CurrentObject;
      Reflect.InvokeMethod(Method, Fixture, arguments);
    }
  }
}