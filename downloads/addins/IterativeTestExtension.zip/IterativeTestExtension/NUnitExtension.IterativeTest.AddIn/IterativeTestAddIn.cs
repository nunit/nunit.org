// *********************************************************************
// Copyright 2008, Kelly Anderson
// This is free software licensed under the MIT license.
// *********************************************************************
using System;
using System.Collections;
using System.Reflection;
using NUnit.Core;
using NUnit.Core.Extensibility;

namespace NUnitExtension.IterativeTest.AddIn
{
  [NUnitAddin(Name="Iterative Test Extension")]
  public class IterativeTestAddIn : IAddin, ITestCaseBuilder
  {
    public const string IterativeTestAttribute = "NUnitExtension.IterativeTest.IterativeTestAttribute";

    #region IAddin Members

    public bool Install(IExtensionHost host)
    {
      IExtensionPoint testCaseBuilders = host.GetExtensionPoint("TestCaseBuilders");
      if (testCaseBuilders == null)
      {
        return false;
      }

      testCaseBuilders.Install(this);
      return true;
    }

    #endregion

    #region ITestCaseBuilder Members

    public bool CanBuildFrom(MethodInfo method)
    {
      return Reflect.HasAttribute(method, IterativeTestAttribute, false);
    }

    public Test BuildFrom(MethodInfo method)
    {
      Attribute attrib = Reflect.GetAttribute(method, IterativeTestAttribute, false);
      string functionName = IterativeTestFramework.GetSourceEnumeratorName(attrib);
      TestSuite suite = new TestSuite(method.Name);

      object tester = Reflect.Construct(method.DeclaringType);
      MethodInfo m = tester.GetType().GetMethod(functionName);
      IEnumerable returnValue = (IEnumerable) m.Invoke(tester, null);
      if (returnValue != null)
      {
        foreach (object current in returnValue)
        {
          suite.Add(new IterativeTestCase(method, current));
        }
      }

      return suite;
    }

    #endregion
  }
}