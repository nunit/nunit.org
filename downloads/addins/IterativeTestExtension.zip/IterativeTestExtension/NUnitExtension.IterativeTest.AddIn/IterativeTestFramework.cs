// *********************************************************************
// Copyright 2008, Kelly Anderson
// This is free software licensed under the MIT license. 
// *********************************************************************
using System;
using NUnit.Core;

namespace NUnitExtension.IterativeTest.AddIn
{
  public class IterativeTestFramework
  {
    private IterativeTestFramework()
    {
    }

    public static string GetSourceEnumeratorName(Attribute attribute)
    {
      return Reflect.GetPropertyValue(attribute, "SourceEnumeratorName") as string;
    }
  }
}