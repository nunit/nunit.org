// *********************************************************************
// Copyright 2008, Kelly Anderson
// This is free software licensed under the MIT license. 
// *********************************************************************
using System.Reflection;

namespace NUnitExtension.IterativeTest.AddIn
{
  public class IterativeTestNameBuilder
  {
    private readonly MethodInfo _method;
    private readonly object _current;

    public IterativeTestNameBuilder(MethodInfo method, object current)
    {
      _method = method;
      _current = current;
    }

    public string GetTestName()
    {
      return _method.Name + "(" + _current + ")";
    }

    public string GetFullTestName()
    {
      return _method.DeclaringType.FullName + "." + GetTestName();
    }
  }
}