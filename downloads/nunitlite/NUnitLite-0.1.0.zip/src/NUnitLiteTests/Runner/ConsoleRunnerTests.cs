#if UNUSED_FOR_NOW
// *****************************************************
// Copyright 2007, Charlie Poole
//
// Licensed under the Open Software License version 3.0
// *****************************************************

using System;
using System.IO;
using NUnit.Framework;
using NUnitLite.Tests;

namespace NUnitLite.Runner.Tests
{
    [TestFixture]
    public class ConsoleRunnerTests : TestCase
    {
        public ConsoleRunnerTests(string name) : base(name) { }

        public void testCanRunTestAndReportResults()
        {
            CommandLineOptions options = new CommandLineOptions();
            TextWriter writer = new StringWriter();
            TestRunner runner = new ConsoleUI( options, writer );
            runner.Run(new DummyTestSuite("SNSFSES"));

            string report = writer.ToString();

            string fullName = typeof(DummyTestCase).FullName + ".TheTest";
            Assert.That( report, Contains.Substring( "7 Tests : 1 Errors, 1 Failures, 0 Not Run" ) );
            Assert.That(report, Contains.Substring(string.Format("1) TheTest ({0})" + Env.NewLine + "Simulated Failure", fullName)));
            Assert.That(report, Contains.Substring(string.Format("2) TheTest ({0})" + Env.NewLine + "System.Exception : Simulated Error", fullName)));
        }

       private class DummyTestSuite : TestSuite
        {
            public DummyTestSuite( string recipe ) : base("Dummy")
            {
                foreach (char c in recipe)
                {
                    DummyTestCase test = new DummyTestCase( "TheTest" );

                    switch (c)
                    {
                        case 'E':
                            test.simulateTestError = true;
                            break;
                        case 'F':
                            test.simulateTestFailure = true;
                            break;
                        default:
                            break;
                    }

                    this.AddTest(test);
               }
            }
        }
    }
}
#endif
