// *****************************************************
// Copyright 2007, Charlie Poole
//
// Licensed under the Open Software License version 3.0
// *****************************************************

using System;
using NUnitLite.Runner;

namespace NUnitLite.Tests
{
    class Program
    {
        static void Main(string[] args)
        {
            ConsoleUI.Main( args );
        }
    }
}