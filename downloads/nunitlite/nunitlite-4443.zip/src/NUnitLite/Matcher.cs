// *****************************************************
// Copyright 2006, Charlie Poole
//
// Licensed under the Open Software License version 3.0
// *****************************************************

using System;
using System.IO;
using NUnitLite.Matchers;

namespace NUnitLite
{
    public abstract class Matcher
    {
        protected object actual;
        protected StringWriter messages = new StringWriter();

        public bool Matches(object actual)
        {
            this.actual = actual;
            return doMatch();
        }

        protected abstract bool doMatch();
        public abstract void DescribeTo(MessageWriter writer);

        public virtual void WriteMessageTo(MessageWriter writer)
        {
            writer.DisplayDifferences(this, actual);
        }

        public static Matcher operator &(Matcher left, Matcher right)
        {
            return new AndMatcher(left, right);
        }

        public static Matcher operator |(Matcher left, Matcher right)
        {
            return new OrMatcher(left, right);
        }
    }
}
