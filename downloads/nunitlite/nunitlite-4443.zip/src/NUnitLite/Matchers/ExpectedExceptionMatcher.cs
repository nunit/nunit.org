// *****************************************************
// Copyright 2006, Charlie Poole
//
// Licensed under the Open Software License version 3.0
// *****************************************************

using System;

namespace NUnitLite.Matchers
{
    public class ExpectedExceptionMatcher : Matcher
    {
        private Type expectedType;

        public ExpectedExceptionMatcher(Type expectedType)
        {
            this.expectedType = expectedType;
        }

        protected override bool doMatch()
        {
            return actual.GetType().IsAssignableFrom( expectedType );
        }

        public override void DescribeTo(MessageWriter writer)
        {
            writer.WritePredicate("exception of type");
            writer.WriteExpected(expectedType);
        }
    }
}
