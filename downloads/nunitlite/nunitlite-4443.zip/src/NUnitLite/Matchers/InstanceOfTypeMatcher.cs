// *****************************************************
// Copyright 2006, Charlie Poole
//
// Licensed under the Open Software License version 3.0
// *****************************************************

using System;

namespace NUnitLite.Matchers
{
    public class InstanceOfTypeMatcher : Matcher
    {
        Type expectedType;

        public InstanceOfTypeMatcher(Type type)
        {
            this.expectedType = type;
        }

        protected override bool doMatch()
        {
            return actual != null && expectedType.IsInstanceOfType(actual);
        }

        public override void DescribeTo(MessageWriter writer)
        {
            writer.WritePredicate("instance of");
            writer.WriteExpected(expectedType);
        }
    }
}
