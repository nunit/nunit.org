// *****************************************************
// Copyright 2006, Charlie Poole
//
// Licensed under the Open Software License version 3.0
// *****************************************************

using System;

namespace NUnitLite.Matchers
{
    public abstract class BinaryOperation : Matcher
    {
        protected Matcher left;
        protected Matcher right;

        public BinaryOperation(Matcher left, Matcher right)
        {
            this.left = left;
            this.right = right;
        }
    }
}
