// *****************************************************
// Copyright 2006, Charlie Poole
//
// Licensed under the Open Software License version 3.0
// *****************************************************

using System;

namespace NUnitLite.Matchers
{
    public class NaNMatcher : Matcher
    {
        protected override bool doMatch()
        {
            return actual is double && double.IsNaN((double)actual) ||
                    actual is float && float.IsNaN((float)actual);
        }

        public override void DescribeTo(MessageWriter writer)
        {
            writer.WriteExpected(double.NaN);
        }
    }
}
