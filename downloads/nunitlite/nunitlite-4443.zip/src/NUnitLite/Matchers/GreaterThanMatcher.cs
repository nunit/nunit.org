// *****************************************************
// Copyright 2006, Charlie Poole
//
// Licensed under the Open Software License version 3.0
// *****************************************************

using System;

namespace NUnitLite.Matchers
{
    class GreaterThanMatcher : Matcher
    {
        private IComparable value;

        public GreaterThanMatcher(IComparable value)
        {
            this.value = value;
        }

        protected override bool doMatch()
        {
            return actual != null && actual.GetType() == value.GetType() && value.CompareTo(actual) < 0; // Test is reversed from syntax
        }

        public override void DescribeTo(MessageWriter writer)
        {
            writer.WritePredicate("greater than");
            writer.WriteExpected(value);
        }
    }
}
