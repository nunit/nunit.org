// *****************************************************
// Copyright 2006, Charlie Poole
//
// Licensed under the Open Software License version 3.0
// *****************************************************

using System;

namespace NUnitLite.Matchers
{
    class SubstringMatcher : Matcher
    {
        private string substring;

        public SubstringMatcher(string substring)
        {
            this.substring = substring;
        }

        protected override bool doMatch()
        {
            return actual is string && ((string)actual).IndexOf( substring ) >= 0;
        }

        public override void DescribeTo(MessageWriter writer)
        {
            writer.WritePredicate( "String containing");
            writer.WriteExpected( substring );
        }
    }
}
