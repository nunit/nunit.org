// *****************************************************
// Copyright 2006, Charlie Poole
//
// Licensed under the Open Software License version 3.0
// *****************************************************

using System;

namespace NUnitLite.Matchers
{
    public class TrueMatcher : Matcher
    {
        protected override bool doMatch()
        {
            return actual is bool && (bool)actual == true;
        }

        public override void DescribeTo(MessageWriter writer)
        {
            writer.WriteExpected(true);
        }
    }
}
