// *****************************************************
// Copyright 2006, Charlie Poole
//
// Licensed under the Open Software License version 3.0
// *****************************************************

using System;

namespace NUnitLite.Matchers
{
    public class ExactTypeMatcher : Matcher
    {
        private Type expectedType;

        public ExactTypeMatcher(Type type)
        {
            this.expectedType = type;
        }

        protected override bool doMatch()
        {
            return actual != null && actual.GetType() == this.expectedType;
        }

        public override void DescribeTo(MessageWriter writer)
        {
            writer.WriteExpected(expectedType);
        }
    }
}
