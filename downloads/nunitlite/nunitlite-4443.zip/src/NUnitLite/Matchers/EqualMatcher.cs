// *****************************************************
// Copyright 2006, Charlie Poole
//
// Licensed under the Open Software License version 3.0
// *****************************************************

using System;
using System.IO;
using System.Collections;

namespace NUnitLite.Matchers
{
    public class EqualMatcher : Matcher
    {
        private object expected;

        public EqualMatcher(object expected)
        {
            this.expected = expected;
        }

        protected override bool doMatch()
        {
            return ObjectsEqual( expected, actual );
        }

        public override void DescribeTo( MessageWriter writer )
        {
            writer.WriteExpected( expected );   
        }

        public override void WriteMessageTo(MessageWriter writer)
        {
            if (messages.ToString().Length > 0)
                writer.Write(messages.ToString());
            else if (expected is string && actual is string)
                writer.DisplayStringDifferences((string)expected, (string)actual);
            else if (expected is Array && actual is Array)
                writer.DisplayArrayDifferences((Array)expected, (Array)actual);
            else
                writer.DisplayDifferences(this, actual);
        }

        private bool ObjectsEqual(object expected, object actual)
        {
            if (expected == null && actual == null)
                return true;

            if (expected == null || actual == null)
                return false;

            Type expectedType = expected.GetType();
            Type actualType = actual.GetType();

            if (IsNumericType(expected) && IsNumericType(actual))
            {
                //
                // Convert to strings and compare result to avoid
                // issues with different types that have the same
                // value
                //
                string sExpected = expected is decimal ? ((decimal)expected).ToString("G29") : expected.ToString();
                string sActual = actual is decimal ? ((decimal)actual).ToString("G29") : actual.ToString();
                return sExpected.Equals(sActual);
            }

            if (expectedType.IsArray && actualType.IsArray)
            {
                int rank = expectedType.GetArrayRank();

                if (rank != actualType.GetArrayRank())
                {
                    messages.WriteLine("Arrays have different numbers of dimensions");
                    return false;
                }
                 
                Array expectedArray = (Array)expected;
                Array actualArray = (Array)actual;

                for ( int r = 0; r < rank; r++ )
                    if (expectedArray.GetLength(r) != actualArray.GetLength(r))
                    {
                        messages.WriteLine("Arrays are of different lengths");
                        return false;
                    }

                IEnumerator expectedEnum = expectedArray.GetEnumerator();
                IEnumerator actualEnum = actualArray.GetEnumerator();

                while( expectedEnum.MoveNext() && actualEnum.MoveNext() )
                {
                    if ( !ObjectsEqual( expectedEnum.Current, actualEnum.Current ) ) return false;
                }

                return true;
            }

            return expected.Equals(actual);
        }

        /// <summary>
        /// Checks the type of the object, returning true if
        /// the object is a numeric type.
        /// </summary>
        /// <param name="obj">The object to check</param>
        /// <returns>true if the object is a numeric type</returns>
        private bool IsNumericType(Object obj)
        {
            if (null != obj)
            {
                if (obj is byte) return true;
                if (obj is sbyte) return true;
                if (obj is decimal) return true;
                if (obj is double) return true;
                if (obj is float) return true;
                if (obj is int) return true;
                if (obj is uint) return true;
                if (obj is long) return true;
                if (obj is short) return true;
                if (obj is ushort) return true;

                if (obj is System.Byte) return true;
                if (obj is System.SByte) return true;
                if (obj is System.Decimal) return true;
                if (obj is System.Double) return true;
                if (obj is System.Single) return true;
                if (obj is System.Int32) return true;
                if (obj is System.UInt32) return true;
                if (obj is System.Int64) return true;
                if (obj is System.UInt64) return true;
                if (obj is System.Int16) return true;
                if (obj is System.UInt16) return true;
            }
            return false;
        }
    }
}
