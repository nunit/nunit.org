// *****************************************************
// Copyright 2006, Charlie Poole
//
// Licensed under the Open Software License version 3.0
// *****************************************************

using System;

namespace NUnitLite.Matchers
{
    public class EmptyMatcher : Matcher
    {
        protected override bool doMatch()
        {
            return actual != null && typeof(string).IsAssignableFrom(actual.GetType()) && string.Empty.Equals((string)actual);
        }

        public override void DescribeTo(MessageWriter writer)
        {
            writer.WriteExpected(string.Empty);
        }
    }
}
