// *****************************************************
// Copyright 2006, Charlie Poole
//
// Licensed under the Open Software License version 3.0
// *****************************************************

using System;
using NUnitLite.Matchers;

namespace NUnitLite.Framework
{
    public class Is
    {
        public static readonly Matcher Null = new NullMatcher();

        public static readonly Matcher NotNull = new NotMatcher(Null);

        public static readonly Matcher True = new TrueMatcher();

        public static readonly Matcher False = new FalseMatcher();

        public static readonly Matcher NaN = new NaNMatcher();

        public static Matcher EqualTo(object expected)
        {
            return new EqualMatcher(expected);
        }

        public static Matcher Same(object expected)
        {
            return new SameMatcher(expected);
        }

        public static Matcher GreaterThan(IComparable expected)
        {
            return new GreaterThanMatcher(expected);
        }

        public static Matcher LessThan(IComparable expected)
        {
            return new LessThanMatcher(expected);
        }

        public static Matcher AtMost(IComparable expected)
        {
            return new NotMatcher(new GreaterThanMatcher(expected));
        }

        public static Matcher AtLeast(IComparable expected)
        {
            return new NotMatcher(new LessThanMatcher(expected));
        }

        public static Matcher String = new ExactTypeMatcher(typeof(string));

        public static Matcher ExactType(Type type)
        {
            return new ExactTypeMatcher(type);
        }

        public static Matcher InstanceOfType(Type type)
        {
            return new InstanceOfTypeMatcher(type);
        }
    }
}
