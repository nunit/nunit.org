// *****************************************************
// Copyright 2006, Charlie Poole
//
// Licensed under the Open Software License version 3.0
// *****************************************************

using System;

namespace NUnitLite.Framework
{
    public class Assert
    {
        /// <summary>
        /// Assert that a boolean expression is true
        /// </summary>
        /// <param name="expression">Expression that must be true for the match to succeed</param>
        public static void That(bool expression)
        {
            Assert.That(expression, Is.True, null);
        }

        /// <summary>
        /// Assert that a boolean expression is true, providing a user message for failures
        /// </summary>
        /// <param name="expression">Expression that must be true for the match to succeed</param>
        /// <param name="message">User message to display if the match fails</param>
        public static void That(bool expression, string message)
        {
            Assert.That(expression, Is.True, message);
        }

        /// <summary>
        /// Assert that some value matches a matcher
        /// </summary>
        /// <param name="actual">The value to be matched</param>
        /// <param name="matcher">The matcher to use</param>
        public static void That(object actual, Matcher expectation)
        {
            Assert.That(actual, expectation, null);
        }

        /// <summary>
        /// Assert that some value matches a matcher, providing a label for the value
        /// and a user message to display in case of failure.
        /// </summary>
        /// <param name="label">A label to display in front of the value in case of failure</param>
        /// <param name="actual">The value to be matched</param>
        /// <param name="matcher">The matcher to use</param>
        /// <param name="message">User message to display if the match fails</param>
        public static void That(object actual, Matcher matcher, string message)
        {
            if (!matcher.Matches(actual))
            {
                TextMessageWriter writer = new TextMessageWriter(message);
                matcher.WriteMessageTo(writer);

                Fail(writer.ToString());
            }
        }

        /// <summary>
        /// Throw an assertion exception with a message and optional arguments
        /// </summary>
        /// <param name="message">The message, possibly with format placeholders</param>
        /// <param name="args">Arguments used in formatting the string</param>
        public static void Fail(string message, params object[] args)
        {
            if (message == null) message = string.Empty;
            else if (args != null && args.Length > 0 )
                message = string.Format(message, args);

            throw new AssertionException(message);
        }
    }
}
