// *****************************************************
// Copyright 2006, Charlie Poole
//
// Licensed under the Open Software License version 3.0
// *****************************************************

using System;
using System.Reflection;

namespace NUnitLite.Framework
{
    public class Reflect
    {
        #region Types
        public static bool IsTestCaseClass(Type type)
        {
            return typeof(TestCase).IsAssignableFrom(type);
        }
        #endregion

        #region Methods
        public static MethodInfo GetMethod(Type type, string name, params Type[] argTypes)
        {
            if (argTypes == null) argTypes = Type.EmptyTypes;
            return type.GetMethod(name, argTypes);
        }

        public static MethodInfo GetMethod(Type type, string name, BindingFlags flags, params Type[] argTypes)
        {
            if (argTypes == null) argTypes = Type.EmptyTypes;
            return type.GetMethod(name, flags, null, argTypes, null);
        }
        #endregion

        #region Construction
        public static bool HasConstructor(Type type, params Type[] argTypes)
        {
            return GetConstructor(type, argTypes) != null;
        }

        public static ConstructorInfo GetConstructor(Type type, params Type[] argTypes)
        {
            if (argTypes == null) argTypes = Type.EmptyTypes;
            return type.GetConstructor(argTypes);
        }

        public static object Construct(Type type, params object[] args)
        {
            Type[] argTypes;

            if (args == null)
            {
                args = new object[0];
                argTypes = Type.EmptyTypes;
            }
            else
            {
                argTypes = Type.GetTypeArray(args);
            }

            ConstructorInfo ctor = GetConstructor( type, argTypes );
            return ctor.Invoke(args);
        }

        public static Test ConstructTestCase(MethodInfo method)
        {
            return ConstructTestCase(method, method.Name);
        }

        public static Test ConstructTestCase(MethodInfo method, string name)
        {
            return ConstructTestCase(method.ReflectedType, name);
        }

        private static Test ConstructTestCase(Type type, string name)
        {
            if (IsTestCaseClass(type))
                return (Test)Construct( type, name );
            else
                return new ProxyTestCase( name, Construct( type ) );
        }
        #endregion

        #region Attributes
        public static bool HasAttribute(MemberInfo member, Type attr)
        {
            return member.GetCustomAttributes(attr, true).Length > 0;
        }

        public static Attribute GetAttribute(MemberInfo member, Type attr)
        {
            object[] attrs = member.GetCustomAttributes(typeof(ExpectedExceptionAttribute), false);
            return attrs.Length == 0 ? null : attrs[0] as Attribute;
        }
        #endregion

        #region Properties
        public static PropertyInfo GetSuiteProperty(Type type)
        {
            return type.GetProperty("Suite", typeof(Test), Type.EmptyTypes);
        }
        #endregion
    }
}
