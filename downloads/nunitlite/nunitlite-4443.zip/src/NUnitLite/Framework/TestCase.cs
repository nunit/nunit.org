// *****************************************************
// Copyright 2006, Charlie Poole
//
// Licensed under the Open Software License version 3.0
// *****************************************************

using System;
using System.Reflection;

namespace NUnitLite.Framework
{
    public class TestCase : Test
    {

        public override int TestCaseCount
        {
            get { return 1; }
        }

        public TestCase(string name) : base( name  ) 
        {
            this.fullName = this.GetType().FullName + "." + name;
        }

        public override void Run(TestResult result, TestListener listener) 
        {
            try
            {
                RunBare();
                result.Success();
            }
            catch (NUnitLiteException nex)
            {
                result.RecordException( nex.InnerException );
            }
            catch (System.Threading.ThreadAbortException)
            {
                throw;
            }
            catch (Exception ex)
            {
                result.RecordException( ex );
            }
        }

        public void RunBare()
        {
            SetUp();
            try
            {
                RunTest();
            }
            finally
            {
                TearDown();
            }
        }

        protected virtual void SetUp() { }

        protected virtual void TearDown() { }

        protected virtual void RunTest()
        {
            MethodInfo method = GetMethod( this.Name, BindingFlags.Public | BindingFlags.Instance );

            try
            {
                InvokeMethod( method );
                ProcessNoException(method);
            }
            catch (TargetInvocationException ex)
            {
                ProcessException(method, ex.InnerException);
            }
        }

        protected virtual MethodInfo GetMethod(string name, BindingFlags flags, params Type[] argTypes)
        {
            return Reflect.GetMethod(this.GetType(), name, flags, argTypes);
        }

        protected virtual void InvokeMethod(MethodInfo exceptionHandler, params object[] args)
        {
            exceptionHandler.Invoke(this, args);
        }

        private static void ProcessNoException(MethodInfo method)
        {
            ExpectedExceptionAttribute exceptionAttribute =
                (ExpectedExceptionAttribute)Reflect.GetAttribute(method, typeof(ExpectedExceptionAttribute));

            if (exceptionAttribute != null)
                Assert.Fail("Expected Exception of type <{0}>, but none was thrown", exceptionAttribute.ExceptionType);
        }

        private void ProcessException(MethodInfo method, Exception caughtException)
        {
            ExpectedExceptionAttribute exceptionAttribute =
                (ExpectedExceptionAttribute)Reflect.GetAttribute(method, typeof(ExpectedExceptionAttribute));

            if (exceptionAttribute == null)
                throw new NUnitLiteException("", caughtException);

            if (!exceptionAttribute.Match(caughtException))
                Assert.Fail("Expected Exception of type <{0}>, but was <{1}>", exceptionAttribute.ExceptionType, caughtException.GetType());

            string handlerName = exceptionAttribute.Handler;
            MethodInfo handler = handlerName == null ? null : GetMethod(handlerName, 
                BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance | BindingFlags.Static, 
                new Type[] { typeof(Exception) });

            if (handler != null)
            {
                try
                {
                    InvokeMethod( handler, caughtException );
                }
                catch (TargetInvocationException ex)
                {
                    throw new NUnitLiteException("", ex.InnerException);
                }
            }
        }
    }
}
