// *****************************************************
// Copyright 2006, Charlie Poole
//
// Licensed under the Open Software License version 3.0
// *****************************************************

using System;
using System.IO;
using System.Text;
using System.Collections;

namespace NUnitLite.Framework
{
    public class TextMessageWriter : MessageWriter
    {
        #region Message Formats
        public static readonly string Pfx_Expected = "  Expected: ";
        public static readonly string Pfx_Actual = "  But was:  ";

        private static readonly string Fmt_Connector = " {0} ";
        private static readonly string Fmt_Predicate = "{0} ";
        private static readonly string Fmt_Label = "{0}";

        private static readonly string Fmt_Null = "null";
        private static readonly string Fmt_EmptyString = "<string.Empty>";

        private static readonly string Fmt_String = "\"{0}\"";
        private static readonly string Fmt_ValueType = "{0}";
        private static readonly string Fmt_Default = "<{0}>";

        private static readonly string Fmt_Expected = Pfx_Expected + "{0}";
        private static readonly string Fmt_Actual = Pfx_Actual + "{0}";

        private static readonly string Fmt_StringLengthsSame = "String lengths are both {0}. Strings differ at index {1}.";
        private static readonly string Fmt_StringLengthsDiffer = "Expected string length {0} but was {1}. Strings differ at index {2}.";
        private static readonly string Fmt_Ellipsis = "...";

        #endregion

        private int maxLineLength = 78;

        public TextMessageWriter() { }

        public TextMessageWriter(string userMessage, params object[] args)
            : base(userMessage, args) { }

        public override void WriteUserMessage(string userMessage)
        {
            WriteLine(userMessage);
        }

        public override void DisplayDifferences(Matcher expectation, object actual)
        {
            Write(Pfx_Expected);
            expectation.DescribeTo(this);
            WriteLine();
            Write(Pfx_Actual);
            WriteActual(actual);
            WriteLine();
        }

        public override void DisplayStringDifferences(string expected, string actual)
        {
            int mismatch = FindMismatchPosition( expected, actual, 0 );

            if (expected.Length == actual.Length)
                WriteLine(Fmt_StringLengthsSame, expected.Length, mismatch);
            else
                WriteLine(Fmt_StringLengthsDiffer, expected.Length, actual.Length, mismatch);

            int maxStringLength = maxLineLength -Pfx_Expected.Length;
            int maxCaret = maxStringLength - Fmt_Ellipsis.Length;   // In case end of string is tuncated

            if (expected.Length > maxStringLength || actual.Length > maxStringLength)
            {
                int clipLength = maxCaret;
                int clipStart = 0;
                if ( mismatch > clipLength )
                {   // Need to truncate at front
                    clipStart = mismatch - clipLength / 2;
                    mismatch = mismatch - clipStart + Fmt_Ellipsis.Length;

                    if (expected.Length - clipStart > maxStringLength)
                        expected = Fmt_Ellipsis + expected.Substring(clipStart, clipLength) + Fmt_Ellipsis;
                    else
                        expected = Fmt_Ellipsis + expected.Substring(clipStart);

                    if (actual.Length - clipStart > maxStringLength)
                        actual = Fmt_Ellipsis + actual.Substring(clipStart, clipLength) + Fmt_Ellipsis;
                    else
                        actual = Fmt_Ellipsis + actual.Substring(clipStart) + Fmt_Ellipsis;
                }
                else
                {
                    if (expected.Length > maxStringLength)
                        expected = expected.Substring(0, clipLength) + Fmt_Ellipsis;

                    if (actual.Length > maxStringLength)
                        actual = actual.Substring(0, clipLength) + Fmt_Ellipsis;
                }
            }

            WriteLine(Fmt_Expected, expected);
            WriteLine(Fmt_Actual, actual);
            WriteLine("  {0}^", new String('-', Pfx_Expected.Length + mismatch - 2));
        }

        public override void DisplayArrayDifferences(Array expected, Array actual)
        {
            Write(Pfx_Expected);
            WriteArray(expected);
            WriteLine();
            Write(Pfx_Actual);
            WriteArray(actual);
            WriteLine();
        }

        public override void WriteConnector(string connector)
        {
            Write(Fmt_Connector, connector);
        }

        public override void WritePredicate(string predicate)
        {
            Write(Fmt_Predicate, predicate);
        }

        public override void WriteLabel(string label)
        {
            Write(Fmt_Label, label);
        }

        public override void WriteExpected(object obj)
        {
            WriteValue(obj);
        }

        public override void WriteActual(object obj)
        {
            WriteValue(obj);
        }

        private void WriteValue(object obj)
        {
            if (obj == null)
                Write(Fmt_Null);
            else if (obj.GetType().IsArray)
                WriteArray((Array)obj);
            else if (obj is string)
                WriteString((string)obj);
            else if (obj is double)
                WriteDouble((double)obj);
            else if (obj is float)
                WriteFloat((float)obj);
            else if (obj is decimal)
                WriteDecimal((decimal)obj);
            else if (obj.GetType().IsValueType)
                Write(Fmt_ValueType, obj);
            else
                Write(Fmt_Default, obj);
        }

        private void WriteArray(Array array)
        {
            int rank = array.Rank;
            int[] products = new int[rank];

            for (int product = 1, r = rank; --r >= 0; )
                products[r] = product *= array.GetLength(r);

            int count = 0;
            foreach( object obj in array )
            {
                if (count > 0)
                    Write(", ");

                bool startSegment = false;
                for (int r = 0; r < rank; r++)
                {
                    startSegment = startSegment || count % products[r] == 0;
                    if (startSegment) Write("< ");
                }

                WriteValue(obj);

                ++count;

                bool nextSegment = false;
                for (int r = 0; r < rank; r++)
                {
                    nextSegment = nextSegment || count % products[r] == 0;
                    if (nextSegment) Write(" >");
                }
            }
        }

        private void WriteString(string s)
        {
            if (s == string.Empty)
                Write( Fmt_EmptyString );
            else
                Write( Fmt_String, s );
        }

        private void WriteDouble(double d)
        {

            if (double.IsNaN(d) || double.IsInfinity(d))
                Write(d);
            else
            {
                string s = d.ToString("G17");

                if (s.IndexOf('.') > 0)
                    Write(s + "d");
                else
                    Write(s + ".0d");
            }
        }

        private void WriteFloat(float f)
        {
            if (float.IsNaN(f) || float.IsInfinity(f))
                Write(f);
            else
            {
                string s = f.ToString("G9");

                if (s.IndexOf('.') > 0)
                    Write(s + "f");
                else
                    Write(s + ".0f");
            }
        }

        private void WriteDecimal(Decimal d)
        {
            Write( d.ToString("G29") + "m");
        }
    }
}
