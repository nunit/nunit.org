// *****************************************************
// Copyright 2006, Charlie Poole
//
// Licensed under the Open Software License version 3.0
// *****************************************************

using System;
using System.Collections;

namespace NUnitLite.Framework
{
    public abstract class Test
    {
        public static readonly NullListener NullListener = new NullListener();

        private string name;
        protected string fullName;

        protected Test( string name )
        {
            this.name = name;
        }

        public string Name
        {
            get { return name; }
        }

        public string FullName
        {
            get { return fullName; }
        }

        public TestResult Run()
        {
            return Run(Test.NullListener);
        }

        public TestResult Run(TestListener listener)
        {
            listener.TestStarted(this);

            TestResult result = new TestResult(this);
            Run(result, listener);

            listener.TestFinished(result);

            return result;
        }

        public abstract void Run(TestResult result, TestListener listener);
        public abstract int TestCaseCount { get; }
    }
}
