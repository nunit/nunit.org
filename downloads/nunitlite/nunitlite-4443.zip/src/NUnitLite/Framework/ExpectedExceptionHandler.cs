// *****************************************************
// Copyright 2006, Charlie Poole
//
// Licensed under the Open Software License version 3.0
// *****************************************************

using System;
using System.Collections.Generic;
using System.Text;

namespace NUnitLite.Framework
{
    class ExpectedExceptionHandler
    {
        public ExpectedExceptionHandler()
        {
        }

        public void Handle(Exception ex)
        {
        }
    }
}
