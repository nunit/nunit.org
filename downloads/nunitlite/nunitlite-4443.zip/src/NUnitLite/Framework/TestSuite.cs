// *****************************************************
// Copyright 2006, Charlie Poole
//
// Licensed under the Open Software License version 3.0
// *****************************************************

using System;
using System.Collections;
using System.Reflection;

namespace NUnitLite.Framework
{
    public class TestSuite : Test
    {
        private ArrayList tests = new ArrayList(10);

        public TestSuite(string name) : base( name ) { }

        public TestSuite(Type type) : base( type.Name )
        {
            this.fullName = type.FullName;

            if ( !InvalidTestSuite(type) )
            {
                foreach (MethodInfo method in type.GetMethods())
                    if (IsTestMethod(method))
                        if ( HasValidSignature(method) )
                            this.AddTest(Reflect.ConstructTestCase(method));
                        else
                            this.AddInvalidTestCase(method.Name, "Test methods must have signature void MethodName()");
            }
        }

        private bool InvalidTestSuite(Type type)
        {
            if (Reflect.IsTestCaseClass(type))
            {
                if (!Reflect.HasConstructor(type, typeof(string)))
                {
                    this.AddInvalidTestCase( type.Name,
                        string.Format( "Class {0} has no public constructor TestCase(string name)", type.Name));
                    return true;
                }
            }
            else
            {
                if (!Reflect.HasConstructor(type))
                {
                    this.AddInvalidTestCase( type.Name,
                        string.Format( "Class {0} has no default constructor", type.Name));
                    return true;
                }
            }

            return false;
        }

        private void AddInvalidTestCase( string name, string message)
        {
            this.AddTest(new InvalidTestCase( name, message ) );
        }

        public IList Tests
        {
            get { return tests; }
        }

        public override void Run(TestResult result, TestListener listener)
        {
            int failures = 0;
            foreach (Test test in tests)
            {
                TestResult r = test.Run(listener);
                result.AddResult(r);
                switch (r.ResultState)
                {
                    case ResultState.Error:
                    case ResultState.Failure:
                        failures++;
                        break;
                    default:
                        break;
                }
            }

            if (failures == 0)
                result.Success();
            else
                result.Failure("One or more component tests failed", null);
        }

        public override int TestCaseCount
        {
            get
            {
                int count = 0;
                foreach( Test test in this.tests )
                    count += test.TestCaseCount;
                return count;
            }
        }

        public void AddTest(Test test)
        {
            tests.Add(test);
        }

        private static bool HasValidSignature(MethodInfo method)
        {
            return method.ReturnType == typeof(void)
                && method.GetParameters().Length == 0; ;
        }

        private bool IsTestMethod(MethodInfo method)
        {
            return method.Name.ToLower().StartsWith("test")
                || Reflect.HasAttribute(method, typeof(TestAttribute));
        }
    }
}
