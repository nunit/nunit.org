// *****************************************************
// Copyright 2006, Charlie Poole
//
// Licensed under the Open Software License version 3.0
// *****************************************************

using System;

namespace NUnitLite.Framework
{
    [AttributeUsage(AttributeTargets.Method,AllowMultiple=false)]
    public class ExpectedExceptionAttribute : Attribute
    {
        private Type exceptionType;
        private string handler;

        public ExpectedExceptionAttribute()
        {
            this.exceptionType = typeof( Exception );
        }

        public ExpectedExceptionAttribute(Type exceptionType)
        {
            this.exceptionType = exceptionType;
        }

        public Type ExceptionType
        {
            get { return exceptionType; }
        }

        public string Handler
        {
            get { return handler; }
            set { handler = value; }
        }

        public override bool Match(object obj)
        {
            if (obj is Exception && exceptionType.IsAssignableFrom(obj.GetType()))
                return true;
                
            return base.Match(obj);
        }
    }
}
