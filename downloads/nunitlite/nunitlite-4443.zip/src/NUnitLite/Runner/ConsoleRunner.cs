// *****************************************************
// Copyright 2006, Charlie Poole
//
// Licensed under the Open Software License version 3.0
// *****************************************************

using System;
using System.IO;
using NUnitLite.Framework;

namespace NUnitLite.Runner
{
    public class ConsoleRunner : BaseTestRunner
    {
        private TextWriter writer;
        private int reportCount = 0;

        public ConsoleRunner()
        {
            this.writer = Console.Out;
        }

        public ConsoleRunner(TextWriter writer)
        {
            this.writer = writer;
        }

        public override void Run(NUnitLite.Framework.Test test)
        {
            TestResult result = test.Run(this);
            ResultSummary summary = new ResultSummary(result);

            writer.WriteLine("{0} Tests : {1} Errors, {2} Failures, {3} Not Run",
                summary.TestCount, summary.ErrorCount, summary.FailureCount, summary.NotRunCount);

            if (summary.ErrorCount + summary.FailureCount > 0)
                PrintErrorReport(result);

            if (summary.NotRunCount > 0)
                PrintNotRunReport(result);
        }

        private void PrintErrorReport(TestResult result)
        {
            reportCount = 0;
            writer.WriteLine();
            writer.WriteLine("Errors and Failures:");
            PrintErrors(result);
        }

        private void PrintErrors(TestResult result)
        {
            if (result.Results != null)
                foreach (TestResult r in result.Results)
                    PrintErrors(r);
            else if (result.IsError || result.IsFailure)
            {
                writer.WriteLine();
                writer.WriteLine("{0}) {1} ({2})", ++reportCount, result.Test.Name, result.Test.FullName);
                writer.WriteLine(result.Message);
                writer.WriteLine(result.StackTrace);
            }
        }

        private void PrintNotRunReport(TestResult result)
        {
            reportCount = 0;
            writer.WriteLine();
            writer.WriteLine("Errors and Failures:");
            PrintNotRun(result);
        }

        private void PrintNotRun(TestResult result)
        {
            if (result.Results != null)
                foreach (TestResult r in result.Results)
                    PrintErrors(r);
            else if (result.IsError || result.IsFailure)
            {
                writer.WriteLine();
                writer.WriteLine("{0}) {1} ({2}) : {3}", ++reportCount, result.Test.Name, result.Test.FullName, result.Message);
            }
        }
    }
}
