// *****************************************************
// Copyright 2006, Charlie Poole
//
// Licensed under the Open Software License version 3.0
// *****************************************************

using System;
using System.IO;
using System.Reflection;
using System.Collections;
using NUnitLite.Framework;

namespace NUnitLite.Runner
{
    public class BaseTestRunner : TestListener
    {
        private IList listeners = new ArrayList();

        public void AddListener(TestListener listener)
        {
            listeners.Add(listener);
        }

        public void RemoveListener(TestListener listener)
        {
            listeners.Remove(listener);
        }

        public void Run(string[] args)
        {
            if (args.Length == 0)
            {
                Run(Assembly.GetCallingAssembly());
            }
            else
            {
                foreach (string arg in args)
                    Console.WriteLine(arg);
            }
        }

        public void Run(Assembly assembly)
        {
            Test suite = TestLoader.Load(assembly);
            Run(suite);
        }

        public void Run(string className)
        {
            Type type = null;
            
            type = Type.GetType(className);

            if ( type == null )
            {
                //writer.WriteLine("Unable to locate type {0}", className);
                return;
            }

            Run(type);
        }

        public void Run( Type type )
        {
            Test test = TestLoader.LoadSuite(type);
            if ( test == null )
                test = new TestSuite(type);

            Run(test);
        }

        public virtual void Run(Test test)
        {
            TestResult result = test.Run(this);
        }

        public void TestStarted(Test test)
        {
            foreach (TestListener listener in listeners)
                listener.TestStarted(test);
        }

        public void TestFinished(TestResult result)
        {
            foreach (TestListener listener in listeners)
                listener.TestFinished(result);
        }
    }
}
