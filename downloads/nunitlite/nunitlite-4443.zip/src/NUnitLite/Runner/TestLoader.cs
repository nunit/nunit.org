// *****************************************************
// Copyright 2006, Charlie Poole
//
// Licensed under the Open Software License version 3.0
// *****************************************************

using System;
using System.Reflection;
using NUnitLite.Framework;

namespace NUnitLite.Runner
{
    public class TestLoader
    {
        public static Test Load(Assembly assembly)
        {
            TestSuite suite = new TestSuite(assembly.GetName().Name);

            foreach (Type type in assembly.GetTypes())
            {
                if ( Reflect.HasAttribute( type, typeof(TestFixtureAttribute) ) )
                    suite.AddTest(new TestSuite(type));
            }

            return suite;
        }

        public static Test LoadSuite(Type type)
        {
            PropertyInfo suiteProperty = Reflect.GetSuiteProperty(type);
            if (suiteProperty != null)
                return (Test)suiteProperty.GetValue(null, Type.EmptyTypes);

            return null;
        }
   }
}
