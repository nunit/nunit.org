// *****************************************************
// Copyright 2006, Charlie Poole
//
// Licensed under the Open Software License version 3.0
// *****************************************************

using System;
using System.Text;
using System.Collections;

namespace NUnitLite.Runner
{
    public class CommandLineOptions
    {
        private string optionChars;

        bool error = false;

        ArrayList invalidOptions = new ArrayList();
        ArrayList parameters = new ArrayList();

        bool wait = false;

        public CommandLineOptions(string optionChars)
        {
            this.optionChars = optionChars;
        }

        public void Parse(params string[] args)
        {
            foreach( string arg in args )
            {
                if (optionChars.IndexOf(arg[0]) >= 0 )
                    ProcessOption(arg);
                else
                    ProcessParameter(arg);
            }
        }

        public string[] Parameters
        {
            get { return (string[])parameters.ToArray( typeof(string) ); }
        }

        private void ProcessOption(string opt)
        {
            switch (opt.Substring(1))
            {
                case "wait":
                    wait = true;
                    break;
                default:
                    error = true;
                    invalidOptions.Add(opt);
                    break;
            }
        }

        private void ProcessParameter(string param)
        {
            parameters.Add(param);
        }

        public bool HasError
        {
            get { return error; }
        }

        public string Message
        {
            get 
            {
                StringBuilder sb = new StringBuilder();
                foreach (string opt in invalidOptions)
                    sb.AppendLine("Invalid option: " + opt);
                return sb.ToString();
            }
        }

        public bool Wait
        {
            get { return wait; }
        }
    }
}
