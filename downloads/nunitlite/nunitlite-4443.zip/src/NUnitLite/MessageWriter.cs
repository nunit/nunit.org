// *****************************************************
// Copyright 2006, Charlie Poole
//
// Licensed under the Open Software License version 3.0
// *****************************************************

using System;
using System.IO;

namespace NUnitLite
{
    public abstract class MessageWriter : StringWriter
    {
        public MessageWriter() { }

        public MessageWriter(string userMessage, params object[] args)
        {
            if (userMessage != null)
            {
                if (args != null && args.Length > 0)
                    userMessage = string.Format(userMessage, args);

                this.WriteUserMessage(userMessage);
            }
        }

        public abstract void WriteUserMessage(string userMessage);
        public abstract void DisplayDifferences(Matcher matcher, object actual);
        public abstract void DisplayStringDifferences(string expected, string actual);
        public abstract void DisplayArrayDifferences(Array expected, Array actual);

        public abstract void WriteConnector(string connector);
        public abstract void WriteLabel(string label);
        public abstract void WritePredicate(string predicate);
        public abstract void WriteExpected(object obj);
        public abstract void WriteActual(object obj);

        /// <summary>
        /// Shows the position two strings start to differ.  Comparison 
        /// starts at the start index.
        /// </summary>
        /// <param name="sExpected"></param>
        /// <param name="sActual"></param>
        /// <param name="iStart"></param>
        /// <returns>-1 if no mismatch found, or the index where mismatch found</returns>
        static protected int FindMismatchPosition(string sExpected, string sActual, int iStart)
        {
            int iLength = Math.Min(sExpected.Length, sActual.Length);
            for (int i = iStart; i < iLength; i++)
            {
                //
                // If they mismatch at a specified position, report the
                // difference.
                //
                if (sExpected[i] != sActual[i])
                {
                    return i;
                }
            }
            //
            // Strings have same content up to the length of the shorter string.
            // Mismatch occurs because string lengths are different, so show
            // that they start differing where the shortest string ends
            //
            if (sExpected.Length != sActual.Length)
            {
                return iLength;
            }

            //
            // Same strings
            //
            return -1;
        }
    }
}
