// *****************************************************
// Copyright 2006, Charlie Poole
//
// Licensed under the Open Software License version 3.0
// *****************************************************

using System;
using NUnitLite.Framework;

namespace NUnitLite.Tests
{
    public abstract class BaseMatcherTest : TestCase
    {
        protected Matcher Matcher;
        protected object[] GoodValues;
        protected object[] BadValues;
        protected string Description;

        //public BaseMatcherTest() { }

        public BaseMatcherTest(string name) : base(name) { }

        public void testSucceedsOnGoodValues()
        {
            foreach (object value in GoodValues)
                Assert.That(value, Matcher);
        }

        public void testFailsOnBadValues()
        {
            foreach ( object value in BadValues )
                Assert.That( Matcher.Matches(value), Is.False );
        }

        public void testProvidesProperDescription()
        {
            TextMessageWriter writer = new TextMessageWriter();
            Matcher.DescribeTo(writer);
            Assert.That( writer.ToString(), Is.EqualTo( Description ), null );
        }
    }
}
