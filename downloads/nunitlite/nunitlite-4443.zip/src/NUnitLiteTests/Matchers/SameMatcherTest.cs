// *****************************************************
// Copyright 2006, Charlie Poole
//
// Licensed under the Open Software License version 3.0
// *****************************************************

using System;
using NUnitLite.Framework;
using NUnitLite.Matchers;

namespace NUnitLite.Tests
{
    [TestFixture]
    public class SameMatcherTest : BaseMatcherTest
    {
        public SameMatcherTest(string name) : base(name) { }

        protected override void SetUp()
        {
            object obj1 = new object();
            object obj2 = new object();

            Matcher = new SameMatcher(obj1);
            GoodValues = new object[] { obj1 };
            BadValues = new object[] { obj2, 3, "Hello" };
            Description = "same as <System.Object>";
        }
    }
}
