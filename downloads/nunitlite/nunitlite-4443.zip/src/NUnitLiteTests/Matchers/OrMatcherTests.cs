// *****************************************************
// Copyright 2006, Charlie Poole
//
// Licensed under the Open Software License version 3.0
// *****************************************************

using System;
using NUnitLite.Framework;
using NUnitLite.Matchers;

namespace NUnitLite.Tests
{
    [TestFixture]
    public class OrMatcherTests : BaseMatcherTest
    {
        public OrMatcherTests(string name) : base(name) { }

        protected override void SetUp()
        {
            Matcher = new OrMatcher(Is.EqualTo(42), Is.EqualTo(99));
            GoodValues = new object[] { 99, 42 };
            BadValues = new object[] { 37 };
            Description = "42 or 99";
        }

        [Test]
        public void CanCombineTestsWithOrOperator()
        {
            Assert.That(99, Is.EqualTo(42) | Is.EqualTo(99) );
        }
    }
}
