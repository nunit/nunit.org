// *****************************************************
// Copyright 2006, Charlie Poole
//
// Licensed under the Open Software License version 3.0
// *****************************************************

using System;
using System.IO;
using NUnitLite.Framework;
using NUnitLite.Matchers;

namespace NUnitLite.Tests
{
    [TestFixture]
    public class EqualMatcherTest : BaseMatcherTest
    {
        public EqualMatcherTest(string name) : base(name) { }

        protected override void SetUp()
        {
            Matcher = new EqualMatcher( 4 );
            GoodValues = new object[] { 4, 4.0f, 4.0d, 4.0000m };
            BadValues = new object[] { 5, null, "Hello" };
            Description = "4";
        }

        [Test, ExpectedException(typeof(AssertionException),Handler="CheckStringMessage")]
        public void FailedStringMatchShowsFailurePosition()
        {
            Assert.That( "abcdgfe", Is.EqualTo( "abcdefg" ) );
        }

        static string testString = "abcdefghijklmnopqrstuvwxyz0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789abcdefghijklmnopqrstuvwxyz0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";

        [Test, ExpectedException(typeof(AssertionException), Handler = "CheckStringMessage")]
        public void LongStringsAreTruncated()
        {
            string expected = testString;
            string actual = testString.Replace('k', 'X');

            Assert.That(actual, Is.EqualTo(expected));
        }

        [Test, ExpectedException(typeof(AssertionException), Handler = "CheckStringMessage")]
        public void LongStringsAreTruncatedAtBothEndsIfNecessary()
        {
            string expected = testString;
            string actual = testString.Replace('Z', '?');

            Assert.That(actual, Is.EqualTo(expected));
        }

        [Test, ExpectedException(typeof(AssertionException), Handler = "CheckStringMessage")]
        public void LongStringsAreTruncatedAtFrontEndIfNecessary()
        {
            string expected = testString;
            string actual = testString  + "+++++";

            Assert.That(actual, Is.EqualTo(expected));
        }

        private void CheckStringMessage(Exception ex)
        {
            StringReader rdr = new StringReader(ex.Message);
            string report = rdr.ReadLine();
            string expected = rdr.ReadLine().Substring(11);
            string actual = rdr.ReadLine().Substring(11);
            int caret = rdr.ReadLine().Substring(11).IndexOf('^');

            int minLength = Math.Min(expected.Length, actual.Length);
            int minMatch = Math.Min(caret, minLength);

            if (caret != minLength)
            {
                if (caret > minLength ||
                    expected.Substring(0, minMatch) != actual.Substring(0, minMatch) ||
                    expected[caret] == actual[caret])
                Assert.Fail("Message Error: Caret does not point at first mismatch..." + Environment.NewLine + ex.Message);
            }

            if (expected.Length > 68 || actual.Length > 68 || caret > 68)
                Assert.Fail("Message Error: Strings are not truncated..." + Environment.NewLine + ex.Message);
        }
    }
}
