// *****************************************************
// Copyright 2006, Charlie Poole
//
// Licensed under the Open Software License version 3.0
// *****************************************************

using System;
using NUnitLite.Framework;

namespace NUnitLite.Tests
{
    [TestFixture]
    class ExactTypeMatcherTest : BaseMatcherTest
    {
        public ExactTypeMatcherTest(string name) : base(name) { }

        protected override void SetUp()
        {
            Matcher = Is.ExactType(typeof(D1));
            GoodValues = new object[] { new D1() };
            BadValues = new object[] { new B(), new D2() };
            Description = "<NUnitLite.Tests.ExactTypeMatcherTest+D1>";
        }

        class B { }
        class D1 : B { }
        class D2 : D1 { }
    }
}
