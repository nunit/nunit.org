// *****************************************************
// Copyright 2006, Charlie Poole
//
// Licensed under the Open Software License version 3.0
// *****************************************************

using System;
using NUnitLite.Framework;
using NUnitLite.Matchers;

namespace NUnitLite.Tests
{
    [TestFixture]
    public class FalseMatcherTest : BaseMatcherTest
    {
        public FalseMatcherTest(string name) : base(name) { }

        protected override void SetUp()
        {
            Matcher = new FalseMatcher();
            GoodValues = new object[] { false };
            BadValues = new object[] { true, null, 17, "false" };
            Description = "False";
        }
    }
}
