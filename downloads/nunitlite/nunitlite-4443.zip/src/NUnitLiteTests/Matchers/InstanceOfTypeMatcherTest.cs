// *****************************************************
// Copyright 2006, Charlie Poole
//
// Licensed under the Open Software License version 3.0
// *****************************************************

using System;
using NUnitLite.Framework;

namespace NUnitLite.Tests
{
    [TestFixture]
    class InstanceOfTypeMatcherTest : BaseMatcherTest
    {
        public InstanceOfTypeMatcherTest(string name) : base(name) { }

        protected override void SetUp()
        {
            Matcher = Is.InstanceOfType(typeof(D1));
            GoodValues = new object[] { new D1(), new D2() };
            BadValues = new object[] { new B() };
            Description = "instance of <NUnitLite.Tests.InstanceOfTypeMatcherTest+D1>";
        }

        class B { }
        class D1 : B { }
        class D2 : D1 { }
    }
}
