// *****************************************************
// Copyright 2006, Charlie Poole
//
// Licensed under the Open Software License version 3.0
// *****************************************************

using System;
using NUnitLite.Framework;
using NUnitLite.Matchers;

namespace NUnitLite.Tests
{
    [TestFixture]
    public class NotMatcherTest : BaseMatcherTest
    {
        public NotMatcherTest(string name) : base(name) { }

        protected override void SetUp()
        {
            Matcher = new NotMatcher( new NullMatcher() );
            GoodValues = new object[] { 42, "Hello" };
            BadValues = new object [] { null };
            Description = "not null";
        }
    }
}
