// *****************************************************
// Copyright 2006, Charlie Poole
//
// Licensed under the Open Software License version 3.0
// *****************************************************

using System;
using NUnitLite.Framework;

namespace NUnitLite.Tests
{
    class MatcherTests
    {
        public static Test Suite
        {
            get
            {
                TestSuite suite = new TestSuite("MatcherTests");
                suite.AddTest(new TestSuite(typeof(NullMatcherTest)));
                suite.AddTest(new TestSuite(typeof(TrueMatcherTest)));
                suite.AddTest(new TestSuite(typeof(FalseMatcherTest)));
                suite.AddTest(new TestSuite(typeof(NaNMatcherTest)));
                suite.AddTest(new TestSuite(typeof(EmptyMatcherTest)));
                suite.AddTest(new TestSuite(typeof(EqualMatcherTest)));
                suite.AddTest(new TestSuite(typeof(SameMatcherTest)));
                suite.AddTest(new TestSuite(typeof(NotMatcherTest)));
                return suite;
            }
        }
    }
}
