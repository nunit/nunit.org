// *****************************************************
// Copyright 2006, Charlie Poole
//
// Licensed under the Open Software License version 3.0
// *****************************************************

using System;
using NUnitLite.Framework;

namespace NUnitLite.Tests
{
    [TestFixture]
    class SubstringMatcherTest : BaseMatcherTest
    {
        public SubstringMatcherTest(string name) : base(name) { }

        protected override void SetUp()
        {
            Matcher = Has.Substring("hello");
            GoodValues = new object[] { "hello", "hello there", "I said hello", "say hello to fred" };
            BadValues = new object[] { "goodbye", "What the hell?", string.Empty, null };
            Description = "String containing \"hello\"";
        }
    }
}
