// *****************************************************
// Copyright 2006, Charlie Poole
//
// Licensed under the Open Software License version 3.0
// *****************************************************

using System;
using NUnitLite.Framework;
using NUnitLite.Matchers;

namespace NUnitLite.Tests
{
    [TestFixture]
    public class EmptyMatcherTest : BaseMatcherTest
    {
        public EmptyMatcherTest(string name) : base(name) { }

        protected override void SetUp()
        {
            Matcher = new EmptyMatcher();
            GoodValues = new object[] { string.Empty, "" };
            BadValues = new object[] { "Hello", null, 42 };
            Description = "<string.Empty>";
        }
    }
}
