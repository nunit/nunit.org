// *****************************************************
// Copyright 2006, Charlie Poole
//
// Licensed under the Open Software License version 3.0
// *****************************************************

using System;
using NUnitLite.Framework;

namespace NUnitLite.Tests
{
    [TestFixture]
    class LessThanMatcherTest : BaseMatcherTest
    {
        public LessThanMatcherTest(string name) : base(name) { }

        protected override void SetUp()
        {
            Matcher = Is.LessThan(5);
            GoodValues = new object[] { 4 };
            BadValues = new object[] { 6, 5, "big", null };
            Description = "less than 5";
        }
    }
}
