// *****************************************************
// Copyright 2006, Charlie Poole
//
// Licensed under the Open Software License version 3.0
// *****************************************************

using System;
using NUnitLite.Framework;
using NUnitLite.Matchers;

namespace NUnitLite.Tests
{
    [TestFixture]
    public class NaNMatcherTest : BaseMatcherTest
    {
        public NaNMatcherTest(string name) : base(name) { }

        protected override void SetUp()
        {
            Matcher = new NaNMatcher();
            GoodValues = new object[] { Double.NaN, float.NaN };
            BadValues = new object[] { 5.0d, 12.2f, double.NegativeInfinity , float.PositiveInfinity };
            Description = "NaN";
        }
    }
}
