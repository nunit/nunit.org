// *****************************************************
// Copyright 2006, Charlie Poole
//
// Licensed under the Open Software License version 3.0
// *****************************************************

using System;
using System.IO;
using NUnitLite.Framework;
using NUnitLite.Tests;

namespace NUnitLite.Runner.Tests
{
    [TestFixture]
    public class BaseTestRunnerTests : TestCase, TestListener
    {
        private int tests;
        private int errors;
        private int failures;
        private int notrun;

        public BaseTestRunnerTests(string name) : base(name) { }

        protected override void SetUp()
        {
            tests = errors = failures = notrun = 0;
        }
        public void testCanRunTestAndReportResults()
        {
            BaseTestRunner runner = new BaseTestRunner();
            runner.AddListener(this);
            runner.Run(new DummyTestSuite("SNSFSES"));

            Assert.That(tests, Is.EqualTo(7), "tests");
            Assert.That(errors, Is.EqualTo(1), "errors");
            Assert.That(failures, Is.EqualTo(1), "failures");
            Assert.That(notrun, Is.EqualTo(0), "notrun");
        }

        public void testCanRunTestByTypeAndReportResults()
        {
            BaseTestRunner runner = new BaseTestRunner();
            runner.AddListener(this);
            runner.Run(typeof(SimpleTestCase));

            Assert.That(tests, Is.EqualTo(6), "tests");
            Assert.That(errors, Is.EqualTo(0), "errors");
            Assert.That(failures, Is.EqualTo(2), "failures");
            Assert.That(notrun, Is.EqualTo(0), "notrun");
        }

        void TestListener.TestStarted(Test test)
        {
        }

        void TestListener.TestFinished(TestResult result)
        {
            if (!result.IsSuiteResult)
            {
                ++tests;
                if (result.IsError) ++errors;
                if (result.IsFailure) ++failures;
                if (!result.Executed) ++notrun;
            }
        }

        class DummyTestSuite : TestSuite
        {
            public DummyTestSuite(string recipe)
                : base("Dummy")
            {
                foreach (char c in recipe)
                {
                    DummyTestCase test = new DummyTestCase("TheTest");

                    switch (c)
                    {
                        case 'E':
                            test.simulateTestError = true;
                            break;
                        case 'F':
                            test.simulateTestFailure = true;
                            break;
                        default:
                            break;
                    }

                    this.AddTest(test);
                }
            }
        }
    }
}
