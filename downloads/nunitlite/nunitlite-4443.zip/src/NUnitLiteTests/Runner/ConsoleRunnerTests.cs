// *****************************************************
// Copyright 2006, Charlie Poole
//
// Licensed under the Open Software License version 3.0
// *****************************************************

using System;
using System.IO;
using NUnitLite.Framework;
using NUnitLite.Tests;

namespace NUnitLite.Runner.Tests
{
    [TestFixture]
    public class ConsoleRunnerTests : TestCase
    {
        public ConsoleRunnerTests(string name) : base(name) { }

        public void testCanRunTestAndReportResults()
        {
            TextWriter writer = new StringWriter();
            BaseTestRunner runner = new ConsoleRunner(writer);
            runner.Run(new DummyTestSuite("SNSFSES"));

            string report = writer.ToString();

            string fullName = typeof(DummyTestCase).FullName + ".TheTest";
            Assert.That( report, Has.Substring( "7 Tests : 1 Errors, 1 Failures, 0 Not Run" ) );
            Assert.That(report, Has.Substring(string.Format("1) TheTest ({0})" + Environment.NewLine + "Simulated Failure", fullName)));
            Assert.That(report, Has.Substring(string.Format("2) TheTest ({0})" + Environment.NewLine + "System.Exception : Simulated Error", fullName)));
        }

        public void testCanRunTestByTypeAndReportResults()
        {
            TextWriter writer = new StringWriter();
            BaseTestRunner runner = new ConsoleRunner(writer);
            runner.Run( typeof(SimpleTestCase) );

            string report = writer.ToString();

            Assert.That( report, Has.Substring( "6 Tests : 0 Errors, 2 Failures, 0 Not Run" ) );
        }

        private class DummyTestSuite : TestSuite
        {
            public DummyTestSuite( string recipe ) : base("Dummy")
            {
                foreach (char c in recipe)
                {
                    DummyTestCase test = new DummyTestCase( "TheTest" );

                    switch (c)
                    {
                        case 'E':
                            test.simulateTestError = true;
                            break;
                        case 'F':
                            test.simulateTestFailure = true;
                            break;
                        default:
                            break;
                    }

                    this.AddTest(test);
               }
            }
        }
    }
}
