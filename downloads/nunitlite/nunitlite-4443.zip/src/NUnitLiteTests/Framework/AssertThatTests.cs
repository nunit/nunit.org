// *****************************************************
// Copyright 2006, Charlie Poole
//
// Licensed under the Open Software License version 3.0
// *****************************************************

using System;
using NUnitLite.Framework;
using NUnitLite.Matchers;

namespace NUnitLite.Tests
{
    [TestFixture]
    public class AssertThatTests
    {
        [Test]
        public void AssertThatPassesIfMatcherMatches()
        {
            Assert.That( 4, new AlwaysMatcher() );
        }

        [Test, ExpectedException(typeof(AssertionException))]
        public void AssertThatFailsIfMatcherFails()
        {
            Assert.That(4, new NeverMatcher());
        }

        [Test, ExpectedException(typeof(AssertionException),Handler="MessageChecker")]
        public void HasValidMessageFormat()
        {
            Assert.That(42, Is.Null);
        }

        private static void MessageChecker(Exception ex)
        {
            Assert.That(ex.Message, Is.EqualTo(
                "  Expected: null" + Environment.NewLine +
                "  But was:  42" + Environment.NewLine));
        }

    }
}
