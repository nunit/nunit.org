// *****************************************************
// Copyright 2006, Charlie Poole
//
// Licensed under the Open Software License version 3.0
// *****************************************************

using System;
using NUnitLite.Framework;

namespace NUnitLite.Tests
{
    [TestFixture]
    public class AssertionExceptionTests : TestCase
    {
        public AssertionExceptionTests(string name) : base(name) { }

        [ExpectedException(typeof(AssertionException), Handler="CheckMessage")]
        public void testCanThrowAndCatchAssertionException()
        {
            throw new AssertionException("My message");
        }

        [ExpectedException(typeof(AssertionException), Handler="CheckMessage")]
        public void testThatCallingFailThrowsAssertionException()
        {
            Assert.Fail("My message");
        }

        private void CheckMessage( Exception ex )
        {
            Assert.That( ex.Message, Is.EqualTo( "My message" ) );
        }
    }
}
