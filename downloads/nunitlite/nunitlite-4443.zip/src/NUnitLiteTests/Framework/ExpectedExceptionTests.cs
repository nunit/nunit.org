// *****************************************************
// Copyright 2006, Charlie Poole
//
// Licensed under the Open Software License version 3.0
// *****************************************************

using System;
using NUnitLite.Framework;

namespace NUnitLite.Tests
{
    [TestFixture]
    public class ExpectedExceptionTests
    {
        [Test, ExpectedException(typeof(ArgumentException))]
        public void TestSucceedsWhenSpecifiedExceptionIsThrown()
        {
            throw new ArgumentException();
        }

        [Test]
        public void TestFailsWhenNoExceptionIsThrown()
        {
            TestSuite suite = new TestSuite(typeof(NoExceptionThrownClass));
            TestResult result = (TestResult)suite.Run().Results[0];
            Assert.That(result.ResultState, Is.EqualTo(ResultState.Failure));
            Assert.That(result.Message, Is.EqualTo( 
                "Expected Exception of type <System.ArgumentException>, but none was thrown" ));
        }

        class NoExceptionThrownClass
        {
            [Test, ExpectedException(typeof(ArgumentException))]
            public void NoExceptionThrown()
            {
            }
        }

        [Test]
        public void TestFailsWhenWrongExceptionIsThrown()
        {
            TestSuite suite = new TestSuite(typeof(WrongExceptionThrownClass));
            TestResult result = (TestResult)suite.Run().Results[0];
            Assert.That(result.ResultState, Is.EqualTo(ResultState.Failure));
            Assert.That(result.Message, Is.EqualTo("Expected Exception of type <System.ArgumentException>, but was <System.ApplicationException>"));
        }

        class WrongExceptionThrownClass
        {
            [Test, ExpectedException(typeof(ArgumentException))]
            public void WrongExceptionThrown()
            {
                throw new ApplicationException();
            }
        }

        [Test, ExpectedException(typeof(ApplicationException))]
        public void TestSucceedsWhenDerivedExceptionIsThrown()
        {
            throw new System.Reflection.TargetException();
        }

        [Test, ExpectedException]
        public void TestSucceedsWithAnyExceptionWhenNoTypeIsSpecified()
        {
            throw new AssertionException("message");
        }

        [Test]
        public void ExceptionHandlerIsCalledWhenExceptionMatches()
        {
            ExceptionHandlerCalledClass fixture = new ExceptionHandlerCalledClass();
            Test testCase = new ProxyTestCase("ThrowsArgumentException", fixture);
            testCase.Run();
            Assert.That(fixture.HandlerCalled, "Handler was not called");
        }

        [Test]
        public void ExceptionHandlerIsNotCalledWhenExceptionDoesNotMatch()
        {
            ExceptionHandlerCalledClass fixture = new ExceptionHandlerCalledClass();
            Test testCase = new ProxyTestCase("ThrowsApplicationException", fixture);
            testCase.Run();
            Assert.That(fixture.HandlerCalled, Is.False, "Handler should not have been called");
        }

        class ExceptionHandlerCalledClass
        {
            public bool HandlerCalled = false;

            [Test, ExpectedException(typeof(ArgumentException), Handler = "ExceptionHandler")]
            public void ThrowsArgumentException()
            {
                throw new ArgumentException();
            }

            [Test, ExpectedException(typeof(ArgumentException), Handler = "ExceptionHandler")]
            public void ThrowsApplicationException()
            {
                throw new ApplicationException();
            }

            public void ExceptionHandler(Exception ex)
            {
                HandlerCalled = true;
            }
        }
    }
}
