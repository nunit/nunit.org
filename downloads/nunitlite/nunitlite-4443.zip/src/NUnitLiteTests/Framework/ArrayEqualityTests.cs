// *****************************************************
// Copyright 2006, Charlie Poole
//
// Licensed under the Open Software License version 3.0
// *****************************************************

using System;
using NUnitLite.Framework;

namespace NUnitLite.Tests
{
    [TestFixture]
    class ArrayEqualityTests
    {
        private string expectedMessage;

        [Test]
        public void CanMatchSingleDimensionedArrays()
        {
            int[] expected = new int[] { 1, 2, 3 };
            int[] actual = new int[] { 1, 2, 3 };

            Assert.That(actual, Is.EqualTo(expected));
        }

        [Test]
        public void CanMatchDoubleDimensionedArrays()
        {
            int[,] expected = new int[,] { { 1, 2, 3 }, { 4, 5, 6 } };
            int[,] actual = new int[,] { { 1, 2, 3 }, { 4, 5, 6 } };

            Assert.That(actual, Is.EqualTo(expected));
        }

        [Test]
        public void CanMatchTripleDimensionedArrays()
        {
            int[, ,] expected = new int[,,] { { { 1, 2 }, { 3, 4 } }, { { 5, 6 }, { 7, 8 } } };
            int[,,] actual = new int[,,] { { { 1, 2 }, { 3, 4 } }, { { 5, 6 }, { 7, 8 } } };

            Assert.That(actual, Is.EqualTo(expected));
        }

        [Test]
        public void CanMatchFiveDimensionedArrays()
        {
            int[, , , ,] expected = new int[2, 2, 2, 2, 2] { { { { { 1, 2 }, { 3, 4 } }, { { 5, 6 }, { 7, 8 } } }, { { { 1, 2 }, { 3, 4 } }, { { 5, 6 }, { 7, 8 } } } }, { { { { 1, 2 }, { 3, 4 } }, { { 5, 6 }, { 7, 8 } } }, { { { 1, 2 }, { 3, 4 } }, { { 5, 6 }, { 7, 8 } } } } };
            int[, , , ,] actual = new int[2, 2, 2, 2, 2] { { { { { 1, 2 }, { 3, 4 } }, { { 5, 6 }, { 7, 8 } } }, { { { 1, 2 }, { 3, 4 } }, { { 5, 6 }, { 7, 8 } } } }, { { { { 1, 2 }, { 3, 4 } }, { { 5, 6 }, { 7, 8 } } }, { { { 1, 2 }, { 3, 4 } }, { { 5, 6 }, { 7, 8 } } } } };

            Assert.That(actual, Is.EqualTo(expected));
        }

        [Test]
        public void CanMatchJaggedArrays()
        {
            int[][] expected = new int[][] { new int[] { 1, 2, 3 }, new int[] { 4, 5, 6, 7 }, new int[] { 8, 9 } };
            int[][] actual = new int[][] { new int[] { 1, 2, 3 }, new int[] { 4, 5, 6, 7 }, new int[] { 8, 9 } };

            Assert.That(actual, Is.EqualTo( expected ));
        }

        [Test]
        public void CanMatchObjectArraysWithMixedNumericTypes()
        {
            DateTime now = DateTime.Now;
            object[] expected = new object[] { 1, 2.0f, 3.5d, 7.000m, "Hello", now };
            object[] actual = new object[] { 1.0d, 2, 3.5, 7, "Hello", now };

            Assert.That(actual, Is.EqualTo(expected));
        }

        [Test]
        public void CanMatchArraysOfDifferentNumericTypes()
        {
            int[] expected = new int[] { 1, 2, 3 };
            double[] actual = new double[] { 1, 2, 3 };

            Assert.That(actual, Is.EqualTo(expected));
        }

        [Test, ExpectedException(typeof(AssertionException), Handler = "ExpectedMessageChecker")]
        public void DifferentRanksFailWithValidMessage()
        {
            int[] expected = new int[] { 1, 2, 3, 4 };
            int[,] actual = new int[,] { { 1, 2 }, { 3, 4 } };

            expectedMessage = "Arrays have different numbers of dimensions" + Environment.NewLine;
            Assert.That(actual, Is.EqualTo(expected));
        }

        [Test, ExpectedException(typeof(AssertionException), Handler = "ExpectedMessageChecker")]
        public void DifferentLengthsFailWithValidMessage()
        {
            int[] expected = new int[] { 1, 2, 3, 4 };
            int[] actual = new int[] { 1, 2, 3 };

            expectedMessage = "Arrays are of different lengths" + Environment.NewLine;
            Assert.That(actual, Is.EqualTo(expected));
        }

        [Test, ExpectedException(typeof(AssertionException), Handler="ExpectedMessageChecker")]
        public void FailureOnSingleDimensionedArrays()
        {
            int[] expected = new int[] { 1, 2, 3 };
            int[] actual = new int[] { 1, 5, 3 };

            expectedMessage = "  Expected: < 1, 2, 3 >" + Environment.NewLine +
                "  But was:  < 1, 5, 3 >" + Environment.NewLine;
            Assert.That(actual, Is.EqualTo(expected));
        }

        [Test, ExpectedException(typeof(AssertionException),Handler="ExpectedMessageChecker")]
        public void FailureOnDoubleDimensionedArrays()
        {
            int[,] expected = new int[,] { { 1, 2, 3 }, { 4, 5, 6 } };
            int[,] actual = new int[,] { { 1, 3, 2 }, { 4, 0, 6 } };

            expectedMessage = "  Expected: < < 1, 2, 3 >, < 4, 5, 6 > >" + Environment.NewLine +
                "  But was:  < < 1, 3, 2 >, < 4, 0, 6 > >" + Environment.NewLine;
            Assert.That(actual, Is.EqualTo(expected));
        }

        [Test, ExpectedException(typeof(AssertionException),Handler="ExpectedMessageChecker")]
        public void FailureOnTripleDimensionedArrays()
        {
            int[, ,] expected = new int[,,] { { { 1, 2 }, { 3, 4 } }, { { 5, 6 }, { 7, 8 } } };
            int[, ,] actual = new int[,,] { { { 1, 2 }, { 3, 4 } }, { { 0, 6 }, { 7, 8 } } };

            expectedMessage = "  Expected: < < < 1, 2 >, < 3, 4 > >, < < 5, 6 >, < 7, 8 > > >" + Environment.NewLine +
                "  But was:  < < < 1, 2 >, < 3, 4 > >, < < 0, 6 >, < 7, 8 > > >" + Environment.NewLine;
            Assert.That(actual, Is.EqualTo(expected));
        }

        [Test, ExpectedException(typeof(AssertionException),Handler="ExpectedMessageChecker")]
        public void FailureOnFiveDimensionedArrays()
        {
            int[, , , ,] expected = new int[2, 2, 2, 2, 2] { { { { { 1, 2 }, { 3, 4 } }, { { 5, 6 }, { 7, 8 } } }, { { { 1, 2 }, { 3, 4 } }, { { 5, 6 }, { 7, 8 } } } }, { { { { 1, 2 }, { 3, 4 } }, { { 5, 6 }, { 7, 8 } } }, { { { 1, 2 }, { 3, 4 } }, { { 5, 6 }, { 7, 8 } } } } };
            int[, , , ,] actual = new int[2, 2, 2, 2, 2] { { { { { 1, 2 }, { 4, 3 } }, { { 5, 6 }, { 7, 8 } } }, { { { 1, 2 }, { 3, 4 } }, { { 5, 6 }, { 7, 8 } } } }, { { { { 1, 2 }, { 3, 4 } }, { { 5, 6 }, { 7, 8 } } }, { { { 1, 2 }, { 3, 4 } }, { { 5, 6 }, { 7, 8 } } } } };

            expectedMessage =
                "  Expected: < < < < < 1, 2 >, < 3, 4 > >, < < 5, 6 >, < 7, 8 > > >, < < < 1, 2 >, < 3, 4 > >, < < 5, 6 >, < 7, 8 > > > >, < < < < 1, 2 >, < 3, 4 > >, < < 5, 6 >, < 7, 8 > > >, < < < 1, 2 >, < 3, 4 > >, < < 5, 6 >, < 7, 8 > > > > >" + Environment.NewLine +
                "  But was:  < < < < < 1, 2 >, < 4, 3 > >, < < 5, 6 >, < 7, 8 > > >, < < < 1, 2 >, < 3, 4 > >, < < 5, 6 >, < 7, 8 > > > >, < < < < 1, 2 >, < 3, 4 > >, < < 5, 6 >, < 7, 8 > > >, < < < 1, 2 >, < 3, 4 > >, < < 5, 6 >, < 7, 8 > > > > >" + Environment.NewLine;
            Assert.That(actual, Is.EqualTo(expected));
        }

        void ExpectedMessageChecker(Exception ex)
        {
            Assert.That(ex.Message, Is.EqualTo(expectedMessage));
        }
    }
}
