// *****************************************************
// Copyright 2006, Charlie Poole
//
// Licensed under the Open Software License version 3.0
// *****************************************************

using System;
using NUnitLite.Framework;

namespace NUnitLite.Tests
{
    public class AllTests
    {
        public static Test Suite
        {
            get
            {
                TestSuite suite = new TestSuite("AllTests");
                suite.AddTest(MatcherTests.Suite);
                suite.AddTest(new TestSuite(typeof(AssertionExceptionTests)));
                suite.AddTest(new TestSuite(typeof(AssertThatTests)));
                suite.AddTest(new TestSuite(typeof(NUnitLite.Runner.Tests.ResultSummaryTests)));
                suite.AddTest(new TestSuite(typeof(TestCaseInvocationTests)));
                suite.AddTest(new TestSuite(typeof(TestResultTests)));
                suite.AddTest(new TestSuite(typeof(NUnitLite.Runner.Tests.ConsoleRunnerTests)));
                suite.AddTest(new TestSuite(typeof(TestSuiteBasicTests)));
                suite.AddTest(new TestSuite(typeof(TestSuiteCreationTests)));
                suite.AddTest(new TestSuite(typeof(TestMessageWriterTests)));
                return suite;
            }
        }
    }
}
