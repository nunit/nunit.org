// *****************************************************
// Copyright 2006, Charlie Poole
//
// Licensed under the Open Software License version 3.0
// *****************************************************

using System;
using NUnitLite.Runner;

namespace NUnitLite.Tests
{
    class Program
    {
        static void Main(string[] args)
        {
            BaseTestRunner runner = new ConsoleRunner();
            runner.Run(args);
        }
    }
}