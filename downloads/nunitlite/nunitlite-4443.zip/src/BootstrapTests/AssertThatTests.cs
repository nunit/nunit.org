// *****************************************************
// Copyright 2006, Charlie Poole
//
// Licensed under the Open Software License version 3.0
// *****************************************************

using System;
using NUnitLite.Framework;
using NUnitLite.Matchers;

namespace NUnitLite.Tests
{
    [NUnit.Framework.TestFixture]
    public class AssertThatTests
    {
        [NUnit.Framework.Test]
        public void PassesIfMatcherMatches()
        {
            Assert.That( 4, new AlwaysMatcher() );
        }

        [NUnit.Framework.Test]
        public void FailsIfMatcherFails()
        {
            try
            {
                Assert.That(4, new NeverMatcher());
                NUnit.Framework.Assert.Fail("Expected Match to Fail");
            }
            catch (AssertionException ex)
            {
                NUnit.Framework.Assert.AreEqual(
                    TextMessageWriter.Pfx_Expected + "never" + Environment.NewLine +
                    TextMessageWriter.Pfx_Actual + "<4>" + Environment.NewLine,
                    ex.Message);
            }
        }

        [NUnit.Framework.Test]
        public void HasValidMessageFormat()
        {
            try
            {
                Assert.That(42, Is.Null);
                NUnit.Framework.Assert.Fail("Expected Assert to Fail");
            }
            catch (AssertionException ex)
            {
                NUnit.Framework.Assert.AreEqual(
                    TextMessageWriter.Pfx_Expected + "<null>" + Environment.NewLine +
                    TextMessageWriter.Pfx_Actual + "<42>" + Environment.NewLine,
                    ex.Message);
            }
        }
    }
}
