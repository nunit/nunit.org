// *****************************************************
// Copyright 2006, Charlie Poole
//
// Licensed under the Open Software License version 3.0
// *****************************************************

using System;
using NUnitLite.Matchers;

namespace NUnitLite.Tests
{
    [NUnit.Framework.TestFixture]
    public class SameMatcherTest : MatcherTest
    {
        protected override void SetUp()
        {
            object obj1 = new object();
            object obj2 = new object();

            matcher = new SameMatcher(obj1);
            goodValue = obj1;
            badValue = obj2;
            description = "same as <System.Object>";
        }
    }
}
