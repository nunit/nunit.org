// *****************************************************
// Copyright 2006, Charlie Poole
//
// Licensed under the Open Software License version 3.0
// *****************************************************

using System;

namespace NUnitLite.Matchers
{
    public class NeverMatcher : Matcher
    {
        protected override bool doMatch()
        {
            return false;
        }

        public override void DescribeTo(MessageWriter writer)
        {
            writer.Write("never");
        }
    }
}
