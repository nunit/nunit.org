This project contains the initial tests used to bootstrap NUnitLite.

These are NUnit tests of the basic underpinnings of NUitLite, intended to get it to the point
where it is capable of testing itself.