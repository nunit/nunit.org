// *****************************************************
// Copyright 2006, Charlie Poole
//
// Licensed under the Open Software License version 3.0
// *****************************************************

using System;
using System.IO;
using NUnitLite.Framework;
using NUnitLite.Runner;

namespace NUnitLite.Tests
{
    [NUnit.Framework.TestFixture]
    public class TextUITests
    {
        [NUnit.Framework.Test]
        public void CanRunTestAndReportResults()
        {
            TextWriter writer = new StringWriter();
            BaseTestRunner runner = new ConsoleRunner(writer);
            runner.Run(new DummyTestSuite("SNSFSES"));

            string report = writer.ToString();

            string fullName = typeof(DummyTestCase).FullName + ".TheTest";
            NUnit.Framework.StringAssert.Contains("7 Tests : 1 Errors, 1 Failures, 0 Not Run", report);
            NUnit.Framework.StringAssert.Contains(string.Format("1) TheTest ({0})" + Environment.NewLine + "Simulated Failure", fullName), report);
            NUnit.Framework.StringAssert.Contains(string.Format("2) TheTest ({0})" + Environment.NewLine + "Simulated Error", fullName), report);
        }

        [NUnit.Framework.Test]
        public void CanRunTestByTypeAndReportResults()
        {
            TextWriter writer = new StringWriter();
            BaseTestRunner runner = new ConsoleRunner(writer);
            runner.Run( typeof(TestSuiteTests.SimpleTestCase) );

            string report = writer.ToString();

            NUnit.Framework.StringAssert.Contains("4 Tests : 0 Errors, 0 Failures, 0 Not Run", report);
        }

        private class DummyTestSuite : TestSuite
        {
            public DummyTestSuite( string recipe ) : base("Dummy")
            {
                foreach (char c in recipe)
                {
                    DummyTestCase test = new DummyTestCase( "TheTest" );

                    switch (c)
                    {
                        case 'E':
                            test.simulateTestError = true;
                            break;
                        case 'F':
                            test.simulateTestFailure = true;
                            break;
                        default:
                            break;
                    }

                    this.AddTest(test);
               }
            }
        }
    }
}
