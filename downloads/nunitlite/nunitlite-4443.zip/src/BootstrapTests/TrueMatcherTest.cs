// *****************************************************
// Copyright 2006, Charlie Poole
//
// Licensed under the Open Software License version 3.0
// *****************************************************

using System;
using NUnitLite.Matchers;

namespace NUnitLite.Tests
{
    [NUnit.Framework.TestFixture]
    public class TrueMatcherTest : MatcherTest
    {
        protected override void SetUp()
        {
            matcher = new TrueMatcher();
            goodValue = true;
            badValue = false;
            description = "<true>";
        }
    }
}
