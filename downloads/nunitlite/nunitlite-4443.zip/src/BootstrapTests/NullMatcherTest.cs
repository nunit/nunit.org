// *****************************************************
// Copyright 2006, Charlie Poole
//
// Licensed under the Open Software License version 3.0
// *****************************************************

using System;
using NUnitLite.Matchers;

namespace NUnitLite.Tests
{
    [NUnit.Framework.TestFixture]
    public class NullMatcherTest : MatcherTest
    {
        protected override void SetUp()
        {
            matcher = new NullMatcher();
            goodValue = null;
            badValue = 42;
            description = "<null>";
        }
    }
}
