// *****************************************************
// Copyright 2006, Charlie Poole
//
// Licensed under the Open Software License version 3.0
// *****************************************************

using System;
using NUnitLite.Framework;
using NUnitLite.Runner;

namespace NUnitLite.Tests
{
    [NUnit.Framework.TestFixture]
    public class TestSuiteTests
    {
        [NUnit.Framework.Test]
        public void CanAddTestsToSuite()
        {
            TestSuite suite = CreateSimpleSuite("my suite");
            TestSuite suite2 = CreateSimpleSuite("suite two");
            suite.AddTest(suite2);
            NUnit.Framework.Assert.AreEqual(6, suite.TestCaseCount);
        }

        [NUnit.Framework.Test]
        public void CanRunTestSuite()
        {
            RecordingTestListener listener = new RecordingTestListener();
            TestSuite suite = CreateSimpleSuite("my suite");
            TestResult result = suite.Run(listener);
            NUnit.Framework.Assert.AreEqual(ResultState.Success, result.ResultState);
            foreach (TestResult r in result.Results)
                NUnit.Framework.Assert.AreEqual(ResultState.Success, r.ResultState);
            NUnit.Framework.Assert.AreEqual(
                "<my suite:<One::Success><Two::Success><Three::Success>:Success>",
                listener.Events );
        }

        [NUnit.Framework.Test]
        public void CanCreateSuiteAutomaticallyFromClass()
        {
            TestSuite suite = new TestSuite(typeof(SimpleTestCase));
            NUnit.Framework.Assert.AreEqual(4, suite.TestCaseCount);
            foreach (Test test in suite.Tests)
                NUnit.Framework.Assert.IsInstanceOfType(typeof(SimpleTestCase), test);
            RecordingTestListener listener = new RecordingTestListener();
            TestResult result = suite.Run(listener);
            NUnit.Framework.Assert.AreEqual(ResultState.Success, result.ResultState);
            NUnit.Framework.Assert.AreEqual(4, result.Results.Count);
            NUnit.Framework.Assert.AreEqual(
                "<SimpleTestCase:<test1::Success><test2::Success><Test3::Success><TEST4::Success>:Success>",
                listener.Events);
        }

        [NUnit.Framework.Test]
        public void FailuresPropagateToSuite()
        {
            TestSuite suite = CreateSimpleSuite("my suite");
            DummyTestCase dummy = new DummyTestCase( "TheTest" );
            suite.AddTest(dummy);
            dummy.simulateTestFailure = true;
            TestResult result = suite.Run();
            NUnit.Framework.Assert.AreEqual(ResultState.Failure, result.ResultState);
        }

        [NUnit.Framework.Test]
        public void ErrorsPropagateToSuiteAsFailures()
        {
            TestSuite suite = CreateSimpleSuite("my suite");
            DummyTestCase dummy = new DummyTestCase( "TheTest" );
            suite.AddTest(dummy);
            dummy.simulateTestError = true;
            TestResult result = suite.Run();
            NUnit.Framework.Assert.AreEqual(ResultState.Failure, result.ResultState);
        }

        [NUnit.Framework.Test]
        public void CanRunSuiteFromSuiteProperty()
        {
            Test suite = TestLoader.LoadSuite(typeof(MyTests));
            NUnit.Framework.Assert.IsNotNull(suite, "Could not get suite");
            NUnit.Framework.Assert.AreEqual(4, suite.TestCaseCount);
            RecordingTestListener listener = new RecordingTestListener();
            suite.Run(listener);
            NUnit.Framework.Assert.AreEqual(
                "<MyTests:<One::Success><Two::Success><TheTest::Failure><Three::Success>:Failure>",
                listener.Events);
        }

        private TestSuite CreateSimpleSuite(string name)
        {
            TestSuite suite = new TestSuite(name);
            NUnit.Framework.Assert.AreEqual(0, suite.TestCaseCount);
            suite.AddTest(new SimpleTestCase("One"));
            suite.AddTest(new SimpleTestCase("Two"));
            suite.AddTest(new SimpleTestCase("Three"));
            NUnit.Framework.Assert.AreEqual(3, suite.TestCaseCount);
            return suite;
        }

        public class SimpleTestCase : TestCase
        {
            public SimpleTestCase(string name) : base(name) { }

            public void One() { }
            public void Two() { }
            public void Three() { }

            public void test1() { }
            public void test2() { }
            public void Test3() { }
            public void TEST4() { }

            private void test5() { }
            public int test6() { return 0; }
            public void test7(int x, int y) { }  // Should not be loaded
        }

        private class MyTests
        {
            public static Test Suite
            {
                get
                {
                    TestSuite suite = new TestSuite("MyTests");
                    suite.AddTest(new SimpleTestCase("One"));
                    suite.AddTest(new SimpleTestCase("Two"));
                    DummyTestCase dummy = new DummyTestCase( "TheTest" );
                    dummy.simulateTestFailure = true;
                    suite.AddTest(dummy);
                    suite.AddTest(new SimpleTestCase("Three"));
                    return suite;
                }
            }
        }
    }
}
