// *****************************************************
// Copyright 2006, Charlie Poole
//
// Licensed under the Open Software License version 3.0
// *****************************************************

using System;
using NUnitLite.Framework;

namespace NUnitLite.Tests
{
    public abstract class MatcherTest
    {
        protected Matcher matcher;
        protected object goodValue;
        protected object badValue;
        protected string description;

        [NUnit.Framework.SetUp]
        protected abstract void SetUp();

        [NUnit.Framework.Test]
        public void SucceedsOnGoodValue()
        {
            NUnit.Framework.Assert.IsTrue(matcher.Matches(goodValue));
        }

        [NUnit.Framework.Test]
        public void FailsOnBadValue()
        {
            NUnit.Framework.Assert.IsFalse(matcher.Matches(badValue));
        }

        [NUnit.Framework.Test]
        public void ProvidesProperDescription()
        {
            TextMessageWriter writer = new TextMessageWriter();
            matcher.DescribeTo(writer);
            NUnit.Framework.Assert.AreEqual(description, writer.ToString());
        }
    }
}
