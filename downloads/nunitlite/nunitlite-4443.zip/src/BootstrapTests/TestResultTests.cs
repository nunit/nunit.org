// *****************************************************
// Copyright 2006, Charlie Poole
//
// Licensed under the Open Software License version 3.0
// *****************************************************

using System;
using NUnitLite.Framework;

namespace NUnitLite.Tests
{
    [NUnit.Framework.TestFixture]
    public class TestResultTests
    {
        private static readonly string MESSAGE = "my message";
        private static readonly string STACKTRACE = "stack trace";

        private TestResult result;

        [NUnit.Framework.SetUp]
        public void SetUp()
        {
            result = new TestResult(null);
        }

        void VerifyResultState(ResultState expectedState, bool executed, bool success, bool failure, bool error, string message )
        {
            NUnit.Framework.Assert.AreEqual(expectedState, result.ResultState, "ResultState");
            NUnit.Framework.Assert.AreEqual(executed, result.Executed, "Executed");
            NUnit.Framework.Assert.AreEqual(success, result.IsSuccess, "IsSucess");
            NUnit.Framework.Assert.AreEqual(failure, result.IsFailure, "IsFailure");
            NUnit.Framework.Assert.AreEqual(error, result.IsError, "IsError");
            NUnit.Framework.Assert.AreEqual(message, result.Message, "Message");
        }

        [NUnit.Framework.Test]
        public void DefaultStateIsNotRun()
        {
            VerifyResultState(ResultState.NotRun, false, false, false, false, null);
        }

        [NUnit.Framework.Test]
        public void CanMarkAsSuccess()
        {
            result.Success();
            VerifyResultState(ResultState.Success, true, true, false, false, null);
        }

        [NUnit.Framework.Test]
        public void CanMarkAsFailure()
        {
            result.Failure(MESSAGE, STACKTRACE);
            VerifyResultState(ResultState.Failure, true, false, true, false, MESSAGE);
            NUnit.Framework.Assert.AreEqual(STACKTRACE, result.StackTrace);
        }

        [NUnit.Framework.Test]
        public void CanMarkAsError()
        {
            Exception caught;
            try
            {
                throw new Exception(MESSAGE);
            }
            catch(Exception ex)
            {
                caught = ex;          
            }

            result.Error(caught);
            VerifyResultState(ResultState.Error, true, false, false, true, MESSAGE);
            NUnit.Framework.Assert.AreEqual(caught.StackTrace, result.StackTrace);
        }

        [NUnit.Framework.Test]
        public void CanMarkAsNotRun()
        {
            result.NotRun(MESSAGE);
            VerifyResultState(ResultState.NotRun, false, false, false, false, MESSAGE);
        }
    }
}
