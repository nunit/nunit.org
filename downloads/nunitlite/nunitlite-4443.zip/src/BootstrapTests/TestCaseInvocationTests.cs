// *****************************************************
// Copyright 2006, Charlie Poole
//
// Licensed under the Open Software License version 3.0
// *****************************************************

using System;
using System.Collections;
using NUnitLite.Framework;

namespace NUnitLite.Tests
{
    [NUnit.Framework.TestFixture]
    public class TestCaseInvocationTests
    {
        DummyTestCase test;
        TestResult result;

        [NUnit.Framework.SetUp]
        public void SetUp()
        {
            test = new DummyTestCase( "TheTest" );
        }

        [NUnit.Framework.Test]
        public void SetUpCalled()
        {
            RunTestAndVerifyResult(ResultState.Success);
            NUnit.Framework.Assert.IsTrue(test.calledSetUp);
        }

        [NUnit.Framework.Test]
        public void SetupFailureIsReported()
        {
            test.simulateSetUpFailure = true;
            RunTestAndVerifyResult(ResultState.Failure);
            NUnit.Framework.Assert.AreEqual("Simulated SetUp Failure", result.Message);
            VerifyStackTraceContainsMethod("SetUp");
        }

        [NUnit.Framework.Test]
        public void SetupErrorIsReported()
        {
            test.simulateSetUpError = true;
            RunTestAndVerifyResult(ResultState.Error);
            NUnit.Framework.Assert.AreEqual("Simulated SetUp Error", result.Message);
            VerifyStackTraceContainsMethod("SetUp");
        }

        [NUnit.Framework.Test]
        public void TearDownCalled()
        {
            RunTestAndVerifyResult(ResultState.Success);
            NUnit.Framework.Assert.IsTrue(test.calledTearDown);
        }

        [NUnit.Framework.Test]
        public void TearDownCalledAfterTestFailure()
        {
            test.simulateTestFailure = true;
            test.Run();
            NUnit.Framework.Assert.IsTrue(test.calledTearDown);
        }

        [NUnit.Framework.Test]
        public void TearDownCalledAfterTestError()
        {
            test.simulateTestError = true;
            test.Run();
            NUnit.Framework.Assert.IsTrue(test.calledTearDown);
        }

        [NUnit.Framework.Test]
        public void TestAndTearDownNotCalledAfterSetUpFailure()
        {
            test.simulateSetUpFailure = true;
            test.Run();
            NUnit.Framework.Assert.IsFalse(test.calledTheTest, "Test");
            NUnit.Framework.Assert.IsFalse(test.calledTearDown, "TearDown");
        }

        [NUnit.Framework.Test]
        public void TestAndTearDownNotCalledAfterSetUpError()
        {
            test.simulateSetUpError = true;
            test.Run();
            NUnit.Framework.Assert.IsFalse(test.calledTheTest, "Test");
            NUnit.Framework.Assert.IsFalse(test.calledTearDown, "TearDown");
        }

        [NUnit.Framework.Test]
        public void TearDownFailureIsReported()
        {
            test.simulateTearDownFailure = true;
            RunTestAndVerifyResult(ResultState.Failure);
            NUnit.Framework.Assert.AreEqual("Simulated TearDown Failure", result.Message);
            VerifyStackTraceContainsMethod("TearDown");
        }

        //[NUnit.Framework.Test]
        public void TearDownFailureDoesNotOverWriteTestFailureInfo()
        {
            test.simulateTestFailure = true;
            test.simulateTearDownFailure = true;
            RunTestAndVerifyResult(ResultState.Failure);
            NUnit.Framework.StringAssert.Contains("Simulated Test Failure", result.Message);
            NUnit.Framework.StringAssert.Contains("Simulated TearDown Failure", result.Message);
            VerifyStackTraceContainsMethod("TheTest");
            VerifyStackTraceContainsMethod("TearDown");
        }

        [NUnit.Framework.Test]
        public void TearDownErrorIsReported()
        {
            test.simulateTearDownError = true;
            RunTestAndVerifyResult(ResultState.Error);
            NUnit.Framework.Assert.AreEqual("Simulated TearDown Error", result.Message);
            VerifyStackTraceContainsMethod("TearDown");
        }

        [NUnit.Framework.Test]
        public void TestCalled()
        {
            RunTestAndVerifyResult(ResultState.Success);
            NUnit.Framework.Assert.IsTrue(test.calledTheTest);
        }

        [NUnit.Framework.Test]
        public void TestErrorIsReported()
        {
            test.simulateTestError = true;
            RunTestAndVerifyResult(ResultState.Error);
            NUnit.Framework.Assert.AreEqual("Simulated Error", result.Message);
            VerifyStackTraceContainsMethod("TheTest");
        }

        [NUnit.Framework.Test]
        public void TestFailureIsReported()
        {
            test.simulateTestFailure = true;
            RunTestAndVerifyResult(ResultState.Failure);
            NUnit.Framework.Assert.AreEqual("Simulated Failure", result.Message);
            VerifyStackTraceContainsMethod("TheTest");
        }

        [NUnit.Framework.Test]
        public void TestListenerIsCalled()
        {
            RecordingTestListener listener = new RecordingTestListener();
            test.Run(listener);
            NUnit.Framework.Assert.AreEqual("<TheTest::Success>", listener.Events);
        }

        [NUnit.Framework.Test]
        public void TestListenerReceivesFailureMessage()
        {
            RecordingTestListener listener = new RecordingTestListener();
            test.simulateTestFailure = true;
            test.Run(listener);
            NUnit.Framework.Assert.AreEqual("<TheTest::Failure>", listener.Events);
        }

        #region Helper Methods
        private void RunTestAndVerifyResult(ResultState expected)
        {
            result = test.Run();
            VerifyResult(expected);
        }

        private void VerifyResult(ResultState expected)
        {
            NUnit.Framework.Assert.AreEqual(expected, result.ResultState);
        }

        private void VerifyStackTraceContainsMethod(string methodName)
        {
            NUnit.Framework.Assert.IsNotNull(result.StackTrace, "StackTrace is null");
            string fullName = string.Format("{0}.{1}()", typeof(DummyTestCase).FullName, methodName);
            NUnit.Framework.StringAssert.Contains(fullName, result.StackTrace);
        }
        #endregion
    }
}
