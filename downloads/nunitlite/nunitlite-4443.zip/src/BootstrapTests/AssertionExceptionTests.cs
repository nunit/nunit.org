// *****************************************************
// Copyright 2006, Charlie Poole
//
// Licensed under the Open Software License version 3.0
// *****************************************************

using System;
using NUnitLite.Framework;

namespace NUnitLite.Tests
{
    [NUnit.Framework.TestFixture]
    public class AssertionExceptionTests
    {
        [NUnit.Framework.Test, NUnit.Framework.ExpectedException(typeof(AssertionException), "My message")]
        public void CanThrowAndCatchAssertionException()
        {
            throw new AssertionException("My message");
        }

        [NUnit.Framework.Test, NUnit.Framework.ExpectedException(typeof(AssertionException), "My message")]
        public void CallingFailThrowsAssertionException()
        {
            Assert.Fail("My message");
        }

    }
}
