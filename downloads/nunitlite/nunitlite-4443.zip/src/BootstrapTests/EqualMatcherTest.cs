// *****************************************************
// Copyright 2006, Charlie Poole
//
// Licensed under the Open Software License version 3.0
// *****************************************************

using System;
using NUnitLite.Matchers;

namespace NUnitLite.Tests
{
    [NUnit.Framework.TestFixture]
    public class EqualMatcherTest : MatcherTest
    {
        protected override void SetUp()
        {
            matcher = new EqualMatcher(4);
            goodValue = 4;
            badValue = 5;
            description = "<4>";
        }
    }
}
