using System;
using System.Collections.Generic;
using System.Text;

namespace ClassLibrary1
{
    public class Class1
    {
        public bool Hello()
        {
            Console.WriteLine("Hello, World 2");
            return true;
        }
    }
}
