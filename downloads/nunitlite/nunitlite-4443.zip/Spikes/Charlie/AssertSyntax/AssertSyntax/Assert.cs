using System;
using System.Collections.Generic;
using System.Text;

namespace AssertSyntax
{
    class Assert
    {
        public static void That(object something, IConstraint constraint)
        {
            if (!constraint.IsSatisfiedBy(something))
                Fail("expected: " + constraint.Message);
        }

        public static void Fail(string message)
        {
            throw new AssertionException(message);
        }
    }
}
