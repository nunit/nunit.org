using System;
using System.Collections.Generic;
using System.Text;

namespace AssertSyntax
{
    public interface IConstraint
    {
        bool IsSatisfiedBy(object something);
        string Message { get; }
    }
}
