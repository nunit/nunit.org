using System;
using System.Collections.Generic;
using System.Text;
using NUnit.Framework;

namespace AssertSyntax.Tests
{
    [TestFixture]
    public class SimpleAsserts
    {
        private const object NULL = null;
        private const string NOTNULL = "";

        [Test]
        public void IsNull()
        {
            Assert.That( NULL, Is.Null() );

            try
            {
                Assert.That(NOTNULL, Is.Null());
                throw new NUnit.Framework.AssertionException("Expected AssertionException");
            }
            catch (AssertionException)
            {
            }
        }

        [Test]
        public void IsNotNull()
        {
            Assert.That(NOTNULL, Is.NotNull() );
            Assert.That(NOTNULL, new Not(new IsNull()));

            try
            {
                Assert.That(NULL, new IsNotNull());
                throw new NUnit.Framework.AssertionException("Expected AssertionException");
            }
            catch (AssertionException)
            {
            }

            try
            {
                Assert.That(NULL, new Not(new IsNull()));
                throw new NUnit.Framework.AssertionException("Expected AssertionException");
            }
            catch (AssertionException)
            {
            }
        }
    }
}
