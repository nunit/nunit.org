using System;
using System.Collections.Generic;
using System.Text;

namespace AssertSyntax
{
    class AssertionException : Exception
    {
        public AssertionException(string message) : base(message) { }
    }
}
