using System;
using System.Collections.Generic;
using System.Text;

namespace AssertSyntax
{
    class IsNull : IConstraint
    {
        public bool IsSatisfiedBy(object theObject)
        {
            return theObject == null;
        }

        public string Message
        {
            get { return "<null>"; }
        }
    }

    class IsNotNull : IConstraint
    {
        public bool IsSatisfiedBy(object theObject)
        {
            return theObject != null;
        }

        public string Message
        {
            get { return "NOT <null>"; }
        }
    }

    class Not : IConstraint
    {
        IConstraint baseConstraint;

        public Not( IConstraint baseConstraint )
        {
            this.baseConstraint = baseConstraint;
        }

        public bool IsSatisfiedBy(object theObject)
        {
            return !baseConstraint.IsSatisfiedBy(theObject);
        }

        public string Message
        {
            get { return "NOT " + baseConstraint.Message; }
        }
    }
}
