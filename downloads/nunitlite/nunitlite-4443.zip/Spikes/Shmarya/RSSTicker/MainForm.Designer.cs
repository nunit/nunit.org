namespace RSSTicker
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
               _timer.Enabled=false; 
               _timer.Dispose();
               RegisterBar(false);
               components.Dispose();
            }
            base.Dispose(disposing);
        }



        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this._labelsPanel = new System.Windows.Forms.Panel();
            this._contextMenu = new System.Windows.Forms.ContextMenuStrip(this.components);
            this._exitMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.addFeedToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this._contextMenu.SuspendLayout();
            this.SuspendLayout();
            // 
            // _labelsPanel
            // 
            this._labelsPanel.ContextMenuStrip = this._contextMenu;
            this._labelsPanel.Location = new System.Drawing.Point(485, 13);
            this._labelsPanel.Name = "_labelsPanel";
            this._labelsPanel.Size = new System.Drawing.Size(200, 100);
            this._labelsPanel.TabIndex = 1;
            // 
            // _contextMenu
            // 
            this._contextMenu.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this._exitMenuItem,
            this.addFeedToolStripMenuItem});
            this._contextMenu.Name = "_contextMenu";
            this._contextMenu.Size = new System.Drawing.Size(121, 48);
            // 
            // _exitMenuItem
            // 
            this._exitMenuItem.Name = "_exitMenuItem";
            this._exitMenuItem.Size = new System.Drawing.Size(120, 22);
            this._exitMenuItem.Text = "E&xit";
            this._exitMenuItem.Click += new System.EventHandler(this._exitMenuItem_Click);
            // 
            // addFeedToolStripMenuItem
            // 
            this.addFeedToolStripMenuItem.Name = "addFeedToolStripMenuItem";
            this.addFeedToolStripMenuItem.Size = new System.Drawing.Size(120, 22);
            this.addFeedToolStripMenuItem.Text = "Add Feed";
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(19F, 38F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Black;
            this.ClientSize = new System.Drawing.Size(754, 46);
            this.ContextMenuStrip = this._contextMenu;
            this.ControlBox = false;
            this.Controls.Add(this._labelsPanel);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(10, 9, 10, 9);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "MainForm";
            this.ShowIcon = false;
            this.ShowInTaskbar = false;
            this.Text = "Form1";
            this.TopMost = true;
            this._contextMenu.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel _labelsPanel;
        private System.Windows.Forms.ContextMenuStrip _contextMenu;
        private System.Windows.Forms.ToolStripMenuItem _exitMenuItem;
        private System.Windows.Forms.ToolStripMenuItem addFeedToolStripMenuItem;
    }
}

