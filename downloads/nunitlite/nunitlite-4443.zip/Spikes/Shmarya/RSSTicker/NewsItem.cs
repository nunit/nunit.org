using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Text;
using System.Windows.Forms;

namespace RSSTicker
{
    public class NewsItem : UserControl
    {
        private Rss.RssItem _item;
        private Rss.RssChannel _channel;
        private LinkLabel _title;
        private LinkLabel _source;

        public NewsItem(Rss.RssItem item, Rss.RssChannel channel)
        {
            _item = item;
            _channel = channel;

            _title = new LinkLabel();
            _source = new LinkLabel();

            this.SuspendLayout();
            // 
            // _title
            // 
            _title.AutoSize = true;
            _title.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            _title.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline;
            _title.LinkColor = System.Drawing.Color.Lime;
            _title.Location = new System.Drawing.Point(3, 16);
            _title.Name = "_title";
            _title.Text = _item.Title.Replace("&quot;","\"");
            _title.MouseEnter += new EventHandler(linkMouseEnter);                
            _title.MouseLeave += new EventHandler(linkMouseLeave);
            _title.Click += new EventHandler(titleClick);
            // 
            // _source
            // 
            _source.AutoSize = true;
            _source.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            _source.LinkColor = System.Drawing.Color.Orange;
            _source.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline;
            _source.Location = new System.Drawing.Point(3, 0);
            _source.Name = "_source";           
             _source.Text = _channel.Title;
            _source.MouseEnter += new EventHandler(linkMouseEnter);    
            _source.MouseLeave += new EventHandler(linkMouseLeave);
            _source.Click += new EventHandler(sourceClick);
            // 
            // NewsItem
            // 
            this.BackColor = System.Drawing.Color.Transparent;
            this.Controls.Add(this._source);
            this.Controls.Add(this._title);
            this.Name = "NewsItem";
            this.ResumeLayout(false);
            this.PerformLayout();

                       
            this.Width = Math.Max(_title.Width, _source.Width) + 5;

            base.MouseEnter += new EventHandler(baseMouseEnter);
            base.MouseLeave += new EventHandler(baseMouseLeave);
        }

      

        #region ItemEvent
        public delegate void ItemEventHandler(object sender, ItemEventArgs e);
        public class ItemEventArgs : EventArgs
        {
            public ItemEventArgs(Rss.RssItem item, Rss.RssChannel channel)
            {
                Item = item;
                Channel = channel;
            }
            public Rss.RssItem Item;
            public Rss.RssChannel Channel;
        } 
        #endregion ItemEvent

        #region SourceClick Event
        public event ItemEventHandler SourceClick;
        private void OnSourceClick(EventArgs e)
        {
            if (SourceClick != null)
                SourceClick(this, new ItemEventArgs(_item, _channel));
        } 
        #endregion SourceClick Event

        #region TitleClick Event
        public event ItemEventHandler TitleClick;
        private void OnTitleClick(EventArgs e)
        {
            if (TitleClick != null)
                TitleClick(this, new ItemEventArgs(_item, _channel));
        } 
        #endregion TitleClick Event

        void baseMouseLeave(object sender, EventArgs e)
        {
            this.BackColor = System.Drawing.Color.Transparent;
        }

        void baseMouseEnter(object sender, EventArgs e)
        {
            this.BackColor = System.Drawing.Color.SlateGray;
        }

        void linkMouseEnter(object sender, EventArgs e)
        {
            OnMouseEnter(e);
        }

        void linkMouseLeave(object sender, EventArgs e)
        {
            OnMouseLeave(e);
        }

        void sourceClick(object sender, EventArgs e)
        {
            OnSourceClick(e);
        }
        void titleClick(object sender, EventArgs e)
        {
            OnTitleClick(e);
        }

    }
}
