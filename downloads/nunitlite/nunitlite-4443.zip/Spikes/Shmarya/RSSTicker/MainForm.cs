using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Runtime.InteropServices;

namespace RSSTicker
{
    public partial class MainForm : Form
    {
        #region Fields
        private int uCallBack;
        private System.Timers.Timer _timer;
        private System.Timers.Timer _updateTimer;
        private IList<string> _readItems;
        private IList<string> _showing;
        private IList<string> _feeds;
        private SizeF _messageSize = SizeF.Empty;
        private string _readItemsFile = System.IO.Path.Combine(System.IO.Path.GetDirectoryName(Application.ExecutablePath), "read-items.xml");
        private string _feedsFile = System.IO.Path.Combine(System.IO.Path.GetDirectoryName(Application.ExecutablePath), "feeds.xml");
        #endregion Fields

        #region ctor
        public MainForm()
        {
            InitializeComponent();
            this.SetStyle(ControlStyles.UserPaint, true);
            this.SetStyle(ControlStyles.OptimizedDoubleBuffer, true);
            this.SetStyle(ControlStyles.AllPaintingInWmPaint, true);

            _labelsPanel.Bounds = this.Bounds;
            _showing = new List<string>();

            if(System.IO.File.Exists(_readItemsFile))
            using (System.IO.FileStream file = new System.IO.FileStream(_readItemsFile,System.IO.FileMode.Open))
            {
                System.Xml.Serialization.XmlSerializer serializer = new System.Xml.Serialization.XmlSerializer(typeof(List<string>));
                _readItems = serializer.Deserialize(file) as IList<string>;
            }

            if( _readItems == null)
                _readItems = new List<string>();

           
            _tick = new tickDelegate(tick);
            
            UpdateFeeds();

            RegisterBar(true);
            _timer = new System.Timers.Timer(40);
            _timer.Elapsed += new System.Timers.ElapsedEventHandler(_timer_Elapsed);
            _timer.Start();
            _updateTimer = new System.Timers.Timer(5*60000);
            _updateTimer.Elapsed += new System.Timers.ElapsedEventHandler(_updateTimer_Elapsed);
            _updateTimer.Start();

        }

        void _updateTimer_Elapsed(object sender, System.Timers.ElapsedEventArgs e)
        {
            UpdateFeeds();
        }

        private delegate void UpdateFeedsDelegate();
        private void UpdateFeeds()
        {
            if (this.InvokeRequired)
            {
                this.Invoke(new UpdateFeedsDelegate(UpdateFeeds));
                return;
            }

            if (System.IO.File.Exists(_feedsFile))
                using (System.IO.FileStream file = new System.IO.FileStream(_feedsFile, System.IO.FileMode.Open))
                {
                    System.Xml.Serialization.XmlSerializer serializer = new System.Xml.Serialization.XmlSerializer(typeof(List<string>));
                    _feeds = serializer.Deserialize(file) as IList<string>;
                }

            if (_feeds == null)
                _feeds = new List<string>();

            foreach(string feed in _feeds)
                UpdateFeed(feed.Replace("&amp;","&"));
        }
        private void UpdateFeed(string url)
        {
            _labelsPanel.SuspendLayout();
            Rss.RssFeed feed;
            try
            {
                 feed = Rss.RssFeed.Read(url);
            }
            catch
            {
                return;
            }
            foreach (Rss.RssChannel channel in feed.Channels)
            {
                foreach (Rss.RssItem item in channel.Items)
                {
                    string itemID = string.Format("{0}|{1}", channel.Link.ToString(), item.Link.ToString());

                    if (_readItems.Contains(itemID) || _showing.Contains(itemID))
                        continue;

                    NewsItem newsItem = new NewsItem(item, channel);
                    newsItem.Dock = DockStyle.Left;

                    newsItem.MouseEnter += new EventHandler(linkMouseEnter);
                    newsItem.MouseLeave += new EventHandler(linkMouseLeave);
                    newsItem.TitleClick += new NewsItem.ItemEventHandler(itemTitleClick);
                    newsItem.SourceClick += new NewsItem.ItemEventHandler(itemSourceClick);
                    newsItem.ContextMenuStrip = _contextMenu;
                    _labelsPanel.Controls.Add(newsItem);
                    _showing.Add(itemID);

                }    
            }

            updateWidth();

            _labelsPanel.ResumeLayout(false);
        }

        private void updateWidth()
        {
            int width = 0;
            foreach (Control control in _labelsPanel.Controls)
                width += control.Width;
            
            _labelsPanel.Width = Math.Max(width, _labelsPanel.Width);
        }

       

        void itemSourceClick(object sender, NewsItem.ItemEventArgs e)
        {
            System.Diagnostics.Process.Start(e.Channel.Link.ToString());
        }

        void itemTitleClick(object sender, NewsItem.ItemEventArgs e)
        {
            string itemId = string.Format("{0}|{1}", e.Channel.Link.ToString(), e.Item.Link.ToString());
            _showing.Remove(itemId);
            _readItems.Add(itemId);
            writeOut();

            System.Diagnostics.Process.Start(e.Item.Link.ToString());
            _labelsPanel.Controls.Remove(sender as Control);
            updateWidth();
            _labelsPanel.PerformLayout();
            

        }

        private void writeOut()
        {
            using (System.IO.FileStream file = new System.IO.FileStream(_readItemsFile, System.IO.FileMode.OpenOrCreate))
            {
                System.Xml.Serialization.XmlSerializer serializer = new System.Xml.Serialization.XmlSerializer(_readItems.GetType());
                serializer.Serialize(file, _readItems);
            }
        }

        void linkMouseEnter(object sender, EventArgs e)
        {
            _timer.Enabled = false;
        }

        void linkMouseLeave(object sender, EventArgs e)
        {
            _timer.Enabled = true;
        }

        #endregion

        private delegate void tickDelegate();
        private tickDelegate _tick;
        private void tick()
        {
            if (this.InvokeRequired)
            {
                this.Invoke(_tick);
                return;
            }
            _labelsPanel.Left -= 2;
            if (_labelsPanel.Right < 0)
                _labelsPanel.Left = this.Width;
        }

        #region Ticker
        void _timer_Elapsed(object sender, System.Timers.ElapsedEventArgs e)
        {
            try
            {
                this.Invoke(_tick);
            }
            catch { }
        }
        protected override void OnPaint(PaintEventArgs e)
        {
            //if (_messageSize == SizeF.Empty)
            //    _messageSize = e.Graphics.MeasureString(_message, this.Font);

            //if (_lastPosition + _messageSize.Width < 0)
            //    _lastPosition = this.Width;


            //_lastPosition -= 20;
            //e.Graphics.DrawString(_message, this.Font, System.Drawing.Brushes.LimeGreen, _lastPosition, this.Height / 2 - _messageSize.Height / 2);
            base.OnPaint(e);
        }
        #endregion Ticker
        
        #region AppBar
        [StructLayout(LayoutKind.Sequential)]
        public struct RECT
        {
            public int left;
            public int top;
            public int right;
            public int bottom;
        }
        [StructLayout(LayoutKind.Sequential)]
        public struct APPBARDATA
        {
            public int cbSize;
            public IntPtr hWnd;
            public int uCallbackMessage;
            public int uEdge;
            public RECT rc;
            public IntPtr lParam;
        }

        public enum AppBarMsg : int
        {
            ABM_NEW = 0,
            ABM_REMOVE,
            ABM_QUERYPOS,
            ABM_SETPOS,
            ABM_GETSTATE,
            ABM_GETTASKBARPOS,
            ABM_ACTIVATE,
            ABM_GETAUTOHIDEBAR,
            ABM_SETAUTOHIDEBAR,
            ABM_WINDOWPOSCHANGED,
            ABM_SETSTATE
        }
        public enum AppBarNotify : int
        {
            ABN_STATECHANGE = 0,
            ABN_POSCHANGED,
            ABN_FULLSCREENAPP,
            ABN_WINDOWARRANGE
        }
        public enum AppBarEdge : int
        {
            ABE_LEFT = 0,
            ABE_TOP,
            ABE_RIGHT,
            ABE_BOTTOM
        }

        [DllImport("SHELL32", CallingConvention = CallingConvention.StdCall)]
        static extern uint SHAppBarMessage(int dwMessage, ref APPBARDATA pData);
        [DllImport("USER32")]
        static extern int GetSystemMetrics(int Index);
        [DllImport("User32.dll", ExactSpelling = true, CharSet = System.Runtime.InteropServices.CharSet.Auto)]
        private static extern bool MoveWindow(IntPtr hWnd, int x, int y, int cx, int cy, bool repaint);
        [DllImport("User32.dll", CharSet = CharSet.Auto)]
        private static extern int RegisterWindowMessage(string msg);

        private void RegisterBar(bool register)
        {
            APPBARDATA appbarData = new APPBARDATA();
            appbarData.cbSize = Marshal.SizeOf(appbarData);
            appbarData.hWnd = this.Handle;
            if (register)
            {
                uCallBack = RegisterWindowMessage("AppBarMessage");
                appbarData.uCallbackMessage = uCallBack;

                uint ret = SHAppBarMessage((int)AppBarMsg.ABM_NEW, ref appbarData);

                AppBarSetPos(AppBarEdge.ABE_TOP);
            }
            else
            {
                SHAppBarMessage((int)AppBarMsg.ABM_REMOVE, ref appbarData);
            }
        }

        private void AppBarSetPos(AppBarEdge edge)
        {
            APPBARDATA appbarData = new APPBARDATA();
            appbarData.cbSize = Marshal.SizeOf(appbarData);
            appbarData.hWnd = this.Handle;
            appbarData.uEdge = (int)edge;

            if (appbarData.uEdge == (int)AppBarEdge.ABE_LEFT || appbarData.uEdge == (int)AppBarEdge.ABE_RIGHT)
            {
                appbarData.rc.top = 0;
                appbarData.rc.bottom = SystemInformation.PrimaryMonitorSize.Height;
                if (appbarData.uEdge == (int)AppBarEdge.ABE_LEFT)
                {
                    appbarData.rc.left = 0;
                    appbarData.rc.right = Size.Width;
                }
                else
                {
                    appbarData.rc.right = SystemInformation.PrimaryMonitorSize.Width;
                    appbarData.rc.left = appbarData.rc.right - Size.Width;
                }

            }
            else
            {
                appbarData.rc.left = 0;
                appbarData.rc.right = SystemInformation.PrimaryMonitorSize.Width;
                if (appbarData.uEdge == (int)AppBarEdge.ABE_TOP)
                {
                    appbarData.rc.top = 0;
                    appbarData.rc.bottom = Size.Height;
                }
                else
                {
                    appbarData.rc.bottom = SystemInformation.PrimaryMonitorSize.Height;
                    appbarData.rc.top = appbarData.rc.bottom - Size.Height;
                }
            }

            SHAppBarMessage((int)AppBarMsg.ABM_QUERYPOS, ref appbarData);

            switch (appbarData.uEdge)
            {
                case (int)AppBarEdge.ABE_LEFT:
                    appbarData.rc.right = appbarData.rc.left + Size.Width;
                    break;
                case (int)AppBarEdge.ABE_RIGHT:
                    appbarData.rc.left = appbarData.rc.right - Size.Width;
                    break;
                case (int)AppBarEdge.ABE_TOP:
                    appbarData.rc.bottom = appbarData.rc.top + Size.Height;
                    break;
                case (int)AppBarEdge.ABE_BOTTOM:
                    appbarData.rc.top = appbarData.rc.bottom - Size.Height;
                    break;
            }

            SHAppBarMessage((int)AppBarMsg.ABM_SETPOS, ref appbarData);
            //this.Location = new Point(appbarData.rc.left, appbarData.rc.top);
            MoveWindow(appbarData.hWnd, appbarData.rc.left, appbarData.rc.top, appbarData.rc.right - appbarData.rc.left, appbarData.rc.bottom - appbarData.rc.top, true);
        }
        protected override System.Windows.Forms.CreateParams CreateParams
        {
            get
            {
                CreateParams cp = base.CreateParams;
                cp.ExStyle = 0x00000080; // WS_EX_TOOLWINDOW 
                return cp;
            }
        }
#endregion AppBar

        private void _exitMenuItem_Click(object sender, EventArgs e)
        {
            _timer.Enabled = false;
            RegisterBar(false);
            this.Close();
        }



    }
}