using System;
using System.Reflection;

[assembly: AssemblyTitle("NUnit")]
[assembly: AssemblyDescription("")]